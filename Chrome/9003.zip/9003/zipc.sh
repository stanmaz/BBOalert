#!/bin/bash
version='9003'
browser='Chrome'
echo $version$browser
cat ./manifest$browser/manifest.json > src/manifest.json
cd ./src
zip bboalert$browser$version.zip *.* iframe/*.* -x *.zip -x test*.* -x *.sh -x workspace.*
mv *.zip ..
cd ..


