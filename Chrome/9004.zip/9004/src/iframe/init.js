
initGlobals();
DEBUG = false;

