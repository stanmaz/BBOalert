
initGlobals();


