
initGlobals();
