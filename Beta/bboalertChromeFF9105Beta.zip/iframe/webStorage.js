function loadJS(url) {
	var url1 = makeDirectLink(url);
	fetch(url1)
		.then(x => x.text())
		.then(y => {
			eval(y);
		})
		.catch(error => console.log("Error : " + error));
}

function makeDirectLink(s) {
	var url = s;
	if (url.indexOf(".blogspot.com") != -1) {
		return getBlogPostURL(url);
	}
	if (url.indexOf("www.dropbox.com") != -1) {
		return url.replace("www.dropbox.com", "dl.dropbox.com");
	}
	if (url.indexOf("https://github.com") != -1) {
		return url.replace("blob/", "").replace("https://github.com", "https://raw.githubusercontent.com");
	}
	if (url.startsWith("https://drive.google.com/file/d/")) {
		var idx = url.indexOf("/view");
		if (idx != -1) {
			return url.substring(0, idx) + "/preview";
		}
	}
	if (url.startsWith("https://1drv.ms/")) {
		var idx1 = url.indexOf("s!");
		var idx2 = url.indexOf("?e=");
		if ((idx1 != -1) && (idx2 != -1)) {
			return "https://api.onedrive.com/v1.0/shares/s!" + url.substring(idx1 + 2, idx2) + "/root/content";
		}
	}
	return url;
}

function HTMLpage2text(html, url, urlOriginal) {
	if (html.startsWith("#")) {
		return parseMarkdown(html);
	}
	if (url.startsWith("https://www.googleapis.com/blogger/v3/blogs/byurl?url=")) {
		return registerBlogId(html, url, urlOriginal);
	}
	if (url.startsWith("https://blogger.googleapis.com/v3/blogs/")) {
		return bloggerPostData(html, url, urlOriginal);
	}
	if (url.startsWith("https://docs.google.com/document/")) {
		var i1 = html.indexOf("<body");
		var i2 = html.indexOf("</body>");
		if ((i2 == -1) || (i2 == -1)) return html;
		var d = document.createElement("div");
		d.innerHTML = html;
		addInfoOption(d.querySelector("title").textContent, url);
		html = html.slice(i1 + 6, i2);
		d.innerHTML = html;
		var p = d.querySelectorAll("p,ul,li");
		var txt = "";
		var lvl = 0;
		var recList = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];
		for (i = 0; i < p.length; i++) {
			if (p[i].tagName.toLowerCase() == "p") {
				lvl = 0;
				recList[lvl] = elimine2Spaces(p[i].textContent.replace(/\u00A0/g, ' ')).trim() + ",,";
				txt = txt + p[i].textContent + "\n";
			} else if (p[i].tagName.toLowerCase() == "ul") {
				lvl = parseInt(p[i].classList[1].split("-")[2]) + 1;
			} else if (p[i].tagName.toLowerCase() == "li") {
				var t = elimine2Spaces(p[i].textContent.replace(/\u00A0/g, ' ')).trim();
				var i0 = t.indexOf(" ");
				t0 = t.substr(0, i0);
				t1 = t.substr(i0 + 1);
				var oppsBid = "--";
				if (t0.split(",").length > 1) {
					oppsBid = t0.split(",")[0];
					t = t0.split(",")[1] + "," + t1;
				} else {
					t = t0 + "," + t1;
				}
				t = elimineSpaces(recList[lvl - 1].split(",")[0] + recList[lvl - 1].split(",")[1] + oppsBid + ",") + t;
				recList[lvl] = t;
				txt = txt + t + "\n";
			}
		}
		txt = txt.replace(/\u00A0/g, ' ');
		var tr = txt.split("\n");
		for (let i = 0; i < tr.length; i++) {
			tr[i] = replaceSuitSymbolsInRecord(tr[i]);
		}
		return tr.join("\n");
	} else {
		var i1 = html.indexOf("<body");
		var i2 = html.indexOf("</body>");
		if ((i2 != -1) && (i2 != -1)) {
			var d = document.createElement("div");
			d.innerHTML = html;
			addInfoOption(d.querySelector("title").textContent, url);
			html = html.slice(i1 + 6, i2);
			return parseHTML(html);
		}
		if (html.startsWith("\\")) {
			return parseLatex(html);
		}
		return html;
	}
}

function parseLatex(html) {
	const CR = "\r";
	const LF = "\n";
	const allBidsRegex = /([1234567][!][CDHSN]|--|Db|Rd|>|enchbox)/g;
	var prefix = "";
	var out = [];
	var txt = "";

	function decodeSuits(t) {
		t = t
			.replaceAll("\\\Pass", "--")
			.replaceAll("\\\Double", "Db")
			.replaceAll("\\\Redouble", "Rd")
			.replaceAll("\\\T", "!C")
			.replaceAll("\\\K", "!D")
			.replaceAll("\\\C", "!H")
			.replaceAll("\\\P", "!S")
			.replaceAll("\\\NT", "!N");
		return t;
	}

	let d = html.replaceAll(CR, "").split(LF);

	for (let i = 0; i < d.length; i++) {
		txt = d[i].replaceAll("\\VoirChat", "Voir chat#");
		if (DEBUG) console.log("xxxx 00 " + txt);
		if (txt.startsWith("%_")) {
			out.push(txt.slice(2));
			if (DEBUG) console.log("xxxx 01 " + out[out.length - 1]);
			continue;
		}
		if (txt.startsWith("\\include")) {
			txt = elimineSpaces(txt);
			txt = txt.replace("\\\include", "Import,"); 0
			out.push(txt);
			if (DEBUG) console.log("xxxx 02 " + out[out.length - 1]);
			continue;
		}
		if (txt.trim().startsWith("\\enchbox")) {
			out.push(txt);
			if (DEBUG) console.log("xxxx 03 " + out[out.length - 1]);
			txt = elimineSpaces(txt);
			if (DEBUG) console.log("xxxx 03a " + txt);
			txt = decodeSuits(txt);
			if (DEBUG) console.log("xxxx 03b " + txt);
			if (DEBUG) console.log("xxxx 03c " + txt.match(allBidsRegex).join(" ").replace("enchbox", ""));
			txt = txt.match(allBidsRegex).join("").replace("enchbox", "");
			prefix = "- ";
			if (txt == "") prefix = ",";
			txt = txt.trim().replaceAll("!", "");
			if (DEBUG) console.log("xxxx 03d " + txt);
			if (txt.endsWith(">")) {
				prefix += txt.slice(-3, -1) + ",";
				txt = txt.replaceAll(">", " ");
				out.push(txt.slice(0, txt.length - 3));
			} else {
				out.push(txt);
			}
			if (DEBUG) console.log("xxxx 03e " + prefix + ":" + txt);
			continue;
		}
		if (txt.trim() == "}") {
			prefix = "";
			continue;
		}
		if (txt.trim() == "{") {
			continue;
		}
		if (txt.trim() == "") {
			continue;
		}
		if (prefix != "") {
			if (DEBUG) console.log("xxxx e " + prefix + txt);
			txt = decodeSuits(txt);
			txt = txt.replaceAll(",", ";");
			if (prefix == ",") txt = txt.replace("&", ",");
			txt = txt.replaceAll("\\ieme", "ième");
			txt = txt.replaceAll("\\rb", "");
			txt = txt.replaceAll("\\ra", "");
			txt = txt.replaceAll("\\rw", "");
			txt = txt.replaceAll("\\", "");
			txt = txt.trim();
			let indent = "";
			if (txt.startsWith("&")) {
				txt = txt.replaceAll("&", " ");
				out[out.length - 1] += txt;
				continue;
			} else {
				while (txt.startsWith("->")) {
					indent += "    ";
					txt = txt.slice(2);
				}
				txt = txt.replaceAll("&", " ");
				if (txt.endsWith(">")) {
					prefix += txtslice(-3, -1) + ",";
					txt = txt.slice(0, txt.length - 3);
					txt = txt.replaceAll(">", " ");
				}
				out.push(indent + prefix + txt);
			}
			if (DEBUG) console.log("xxxx e " + prefix + txt);
			continue;
		}
	}
	window.outLatex = out;
	return (out.join("\n") + "\n");
}


function getGoogleDriveFile(gdURL, success, failure) {
	const controller = new AbortController();
	function getData(event) {
		if (event.data.url != gdURL) return;
		clearTimeout(tmr);
		if (event.data.text.length > 0) {
			if (event.data.text.length == 262122) {
				failure("File too large");
			} else {
				success(event.data.text);
			}
		} else {
			failure("Error no data loaded");
		}
		gdifrm.remove();
		controller.abort();
	}
	var gdifrm = document.createElement("iframe");
	gdifrm.allow = "clipboard-read; clipboard-write";
	gdifrm.sandbox = 'allow-scripts allow-same-origin allow-modals';
	gdifrm.id = 'googledrive-iframe';
	gdifrm.width = "100%";
	gdifrm.height = "100%";
	gdifrm.src = gdURL;
	document.body.appendChild(gdifrm);
	window.addEventListener("message", getData, { signal: controller.signal });
	var tmr = setTimeout(function () {
		failure(gdURL + "\n time out error");
		gdifrm.remove();
		controller.abort();
	}, 5000);
}

function fetchWebData(url, success, failure) {
	if (url.startsWith("https://drive.google.com/file/d/")) {
		getGoogleDriveFile(url, success, failure);
	} else {
		fetch(url, {
			cache: "no-store"
		})
			.then(x => x.text())
			.then(data => { success(data); })
			.catch(error => { failure(error) });
	}

}
