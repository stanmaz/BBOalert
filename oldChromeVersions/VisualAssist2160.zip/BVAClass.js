"use strict"

const SuitRank = {"NT": 4, "♠": 3, "♥": 2, "♦": 1, "♣": 0};

//a bid made by a players
class Bid{

    //level: the bid level or 0 if a non-suit bid (Pass, X or XX)
    //suit: the suit or non-suit bid
    //alerted: true if the bid was alerted
    //explanation: empty text if no explanation otherwise the explanation
    //jump: set to jump if at least 1 jump
    //jumps: the number of levels jumped compared to previous bid; initialised to 0
    //rank: a number that indicates the rank from 0 (1C), 4 (1NT) up to 34 (7NT). Undefined if not a suit bid


    constructor(bidText){
        var text = bidText.trim();
        if (text.charAt(0) >= "1" && text.charAt(0) <= "7" ){
            this.level = text.charAt(0);
            this.suit = text.substr(1);
        }
        else{
            this.level = 0;
            this.suit = text;
        }
        this.text = text;
        this.jumps = 0;
        this.jump = false;
        this.alerted = false;
        this.explanation = "";
        if (this.level > 0) this.rank = (this.level - 1) * 5 + SuitRank[this.suit];
    }

    isLevelBid(){return this.level > 0;}

    //compare the bid with a previous one and set the jump variables
    setJump(prevSuitBid){
        //can only compare bids that have ranks
        if (prevSuitBid && prevSuitBid.rank && this.rank){
            this.jumps = parseInt((this.rank - prevSuitBid.rank - 1) / 5);
            this.jump = (this.jumps > 0);
        }
    }
}
