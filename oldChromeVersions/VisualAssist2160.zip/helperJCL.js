'use strict';

let daysOfWeeks = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
let shortDaysOfWeeks = ["Sun", "Mon", "Tue", "Wed", "Thur", "Fri", "Sat"];

//check the element has the specified tag in its ancestry
function checkAncestorClass(element, ancestor, generations){
    var el = element;
    var cnt = 0;
    ancestor = ancestor.toUpperCase();
    generations = (generations ? generations : 1000);  //0 for yourself, 1 for parents, etc
    while (el && cnt <= generations){
        if (el.className && el.className.toUpperCase().includes(ancestor)) return el;
        el = el.parentElement;
        cnt++;
    }
    return null;
}

//check the element has the specified tag in its ancestry or is that tag
function checkAncestorTag(element, ancestor, generations){
    var el = element;
    var cnt = 0;
    generations = (generations ? generations : 1000);  //0 for yourself, 1 for parents, etc
    while (el && cnt <= generations){
        if (el.tagName && el.tagName.includes(ancestor)) return el;
        el = el.parentElement;
        cnt++;
    }
    return null;
}


//check the element has the specified tag/class in its ancestry
function checkForAncestor(element, ancestors){
    var el = element;
    var cnt = 0;
    var generations = 0;  //first time through the list will update the max generations
    while (el && cnt <= generations){
        for (let i = 0; i < ancestors.length; i++) {
            const p = ancestors[i];
            if (p.gens >= cnt){
                if (p.type == "tag" && el.tagName.includes(p.name)) return {node: el, id: p.id, index: i};
                if (p.type == "class" && el.className.includes(p.name)) return { node: el, id: p.id, index: i };
                if (p.type == "id" && el.id.includes(p.name)) return { node: el, id: p.id, index: i };
                if (p.gens > generations) generations = p.gens;   
            }
        }
        el = el.parentElement;
        cnt++;
    }
    return null;
}

//Convert local date string to ISO format
function dateStrLocaleToISO(str){
    function format(yy, mm, dd) {return yy + "-" + mm + "-" + dd;}; 
    return parseLocalDate(str, format);
};

//Convert date object to ddd dd mmmm yyyy hh:mm:ss
function dateToDateTime(dte){
    return dte.toDateString() + " " + dateToTime(dte);
};

//Convert date object to ISO date format
function dateToISO(dte){
    return formatInt(dte.getFullYear()) + "-" + formatInt(dte.getMonth() + 1, 2) + "-" + formatInt(dte.getDate(), 2);
};

//Convert date object to ISO date format
function dateToISODateTime(dte){
    return dateToISO(dte) + " " + dateToTime(dte);
};

//Convert date object to time hh:mm:ss
function dateToTime(dte){
    return formatInt(formatInt(dte.getHours(), 2) + ":" + formatInt(dte.getMinutes(), 2) + ":" + formatInt(dte.getSeconds(), 2));
};

//takes a string that is valid input to a date object and return uk format dd-mm-yyyy
function dateStrToUKDate(str){
    var dte = new Date(str);
    return formatUKDate(dte, "-");
}

//insert a node after it's sibling
function DOMInsertAfter(newNode, sibling) {
    sibling.parentNode.insertBefore(newNode, sibling.nextSibling);
}



function findDayOfWeek(str){
    var index = -1;
    for (let i = 0; i < daysOfWeeks.length; i++) {
        index = str.indexOf(daysOfWeeks[i]);
        if (index != -1) break;
    };
    return index;
};

//find the array item that contains the specified string
function findStrMatch(match, list){
    for (let i = 0; i < list.length; i++) {
        if (list[i].indexOf(match) != -1) return i;
    }
    return -1;
}

//returns an integer with a minimum number of digits (pre-fixed with zeros if required)
function formatInt(int, minDigits){
    var str = (int ? int.toString() : "");
    return (str.length >= minDigits ? str : str.padStart(minDigits, "0"));
};

//takes an input time as hh:mm:ss and return the string with 2 digits for the hours, mins and secs
function formatTime(str, sep){
    var parts = str.split(":");
    var hh, mm, ss;
    hh = formatInt(parts[0], 2);
    mm = formatInt(parts[1], 2);
    ss = formatInt(parts[2], 2);
    return hh + sep + mm + sep + ss; 
};

//takes a Date object and returns the date as a string "DD-MM-YYYY"
function formatUKDate(dte, sep){
    return formatInt(dte.getDate(), 2) + sep + formatInt(dte.getMonth() + 1, 2) + sep + dte.getFullYear();
};

function getDayTh(dte) {
    var day = dte.getDate();
    switch (day){
        case 1:
        case 21:
        case 31:
            return day.toString() + "st";
            break;

        case 3:
        case 23:
            return day.toString() + "rd";
            break;

        case 2:
        case 22:
            return day.toString() + "nd";
            break;
            
        default:   
            return day.toString() + "th";
    }
};

function getShortDay(dte) {return shortDaysOfWeeks[dte.getDay()];};

//takes a UK dd/mm/yy or dd-mm-yy format and convert to "DD-MM-YYYY" (assuming "-" is the sep)
function localeDateClean(str, sep){
    function format(yy, mm, dd) {return dd + sep + mm + sep + yy;}; 
    return parseLocalDate(str, format);
};

//convert a local date dd-mm-yy or dd/mm/yy to a format specified by function formatFn(yy, mm, dd)
function parseLocalDate(dateStr, formatFn){
    var parts;
    if (dateStr == undefined || dateStr == "") return "";
    parts = dateStr.split("-");
    if (parts.length == 1) parts = dateStr.split("/");

    var yy;
    if (parts[2] != undefined){
        yy = parseInt(parts[2]);
        if (yy < 100) yy = 2000 + yy;    
    }
    else{
        var today = new Date();
        yy = today.getFullYear();
    };
    return formatFn(yy.toString(), formatInt(parts[1], 2), formatInt(parts[0], 2)); 
}

//return an object with an property for each parameter in the url and the full fileref prior to params
function parseURL(url){
    var result = {};
    var index = url.indexOf("?");
    if (index == -1) return {fullFileRef: url}; //no parameters

    var parts = url.split("?");
    result.fullFileRef = parts[0];
    
    var params = parts[1].split("&");
    for (let i = 0; i < params.length; i++) {
        const element = params[i];
        var parts = element.split("=");
        result[parts[0]] = (parts.length == 2 ? parts[1] : "");
    }
    return result;
}

//convert a price string to a float number. Returns InvalidPrice if invalid format
function priceParse(txt){
    //first character should be a current
    var index = txt.indexOf("£");
    if (index == -1) return InvalidPrice;
    var priceStr = txt.substring(index + 1);
    var parts = priceStr.split(".");
    if (parts.length == 1)
        return parseInt(parts[0]) * 100;
    else
        return parseInt(parts[0]) * 100 + parseInt(parts[1]);
}

function priceToString(value){
    var pounds = parseInt(value / 100);
    var pence = value - pounds * 100;
    if (pence < 0) pence = -pence;      //negative value which will be displayed before the number of pounds
    return (pounds + "." + formatInt(pence, 2));

}

function sortAlpha(a, b, item) {
    var textA = a[item].toUpperCase();
    var textB = b[item].toUpperCase();
    return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
};

//splits a string into an array of words where words are alphanumer characters
//Returns an array of the words AND separators split out from each other.
function splitWords(text) {
    var len = text.length;
    var words = [];
    var strStart = 0;
    var wordCnt = 0;
    var wordMode = true;    //assume first text is an alphanumeric word
    for (let i = 0; i < len; i++) {
        const cc = text[i];
        if ((cc >= "0" && cc <= "9") || (cc >= "A" && cc <= "Z") || (cc >= "a" && cc <= "z")) {
            //alphanumer character so made terminate one or more separators
            if (!wordMode) {
                words[wordCnt] = text.substring(strStart, i);
                wordCnt++;
                wordMode = true;
                strStart = i;
            }
        }
        else {
            //non-alphanumeric so terminates a word or part of a separator/
            if (wordMode) {
                words[wordCnt] = text.substring(strStart, i);
                wordCnt++;
                wordMode = false;
                strStart = i;
            }
        }
    }
    words[wordCnt] = text.substring(strStart);

    return words;
}
