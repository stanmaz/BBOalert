'use strict';

const BBO_URL = "https://www.bridgebase.com/v3/*";

//persisted variables
var g_describeBoard = true;
var g_shape = true;
var g_hcp = true;
var g_ltc = true;
var g_shapeDummy = true;
var g_hcpDummy = true;
var g_ltcDummy = true;
var g_sayPlayedCard = true;
var g_sayOwnCard = false;
var g_sayOtherBids = true;
var g_sayNonSuit = true;
var g_saySuitBids = true;
var g_sayCardCnt = true;
var g_sayOK = true;
var g_autoAcceptBids = false;
var g_sayMouseOver = true;
var g_sayChat = true;
var g_sayChatSender = true;
var g_sayBroadcasts = true;
var g_sayAlertedBids = true;
var g_sayBidExpReq = true;
var g_sayRequests = true;
var g_alertAssist = true;
var g_autoSaySpeech = true;
var g_selfAlert = false;

//self alert has a maximum of 39 characters
var g_selfAlertBids = [];
var g_selfAlertOrdered = [
    {level: '', bid: '', group: '1', brief: 'Natural', desc: 'Natural'}
    ,{level: '', bid: '', group: '1', brief: 'Pre-emptive', desc: 'Weak pre-emptive'}
    ,{level: '', bid: 'Dbl', group: '2', brief: 'Penalty double', desc: 'Penalty double'}
    ,{level: '', bid: 'Dbl', group: '2', brief: 'Take out double', desc: 'Take out double'}
    ,{level: '', bid: 'Pass', group: '2', brief: 'Helvic Pass', desc: 'Helvic. partner to re-double'}
    ,{level: '', bid: 'Rdbl', group: '2', brief: 'Helvic as requested', desc: 'Helvic. As requested, partner to pass or bid lowest 4 card suit'}
    ,{level: '', bid: 'Rdbl', group: '2', brief: 'Re-double 10+ points', desc: '10+ points and two 4 card suits'}
    ,{level: '', bid: 'Rdbl', group: '2', brief: 'Helvic partner to bid 2C', desc: 'Helvic. ptrn bid 2C, I rebid 5 card suit'}
    ,{level: '1', bid: 'NT', group: '1', brief: '12-14', desc: '12-14 points'}
    ,{level: '1', bid: 'NT', group: '1', brief: 'Checkback', desc: 'Checkback: 15-18 points'}
    ,{level: '2', bid: 'C', group: '1', brief: 'Benji open', desc: 'Benji 23-24 pts or 8+ tricks'}
    ,{level: '2', bid: 'C', group: '2', brief: 'Checkback', desc: 'Checkback. 8+ points forcing'}
    ,{level: '2', bid: 'C', group: '2', brief: 'FSF', desc: 'Fourth suit forcing'}
    ,{level: '2', bid: 'C', group: '2', brief: 'Helvic 4C & 4D', desc: 'Helvic 4C & 4D'}
    ,{level: '2', bid: 'C', group: '2', brief: 'Helvic 4C & 4H or 4S', desc: 'Helvic 4C & 4H or 4S'}
    ,{level: '2', bid: 'C', group: '2', brief: 'Inverted minor', desc: 'Inverted minor, support to the 3 level'}
    ,{level: '2', bid: 'C', group: '2', brief: 'Stayman', desc: 'Stayman'}
    ,{level: '2', bid: 'C', group: '3', brief: 'Escape double by partner', desc: 'No card suit,  partner to bid best suit'}
    ,{level: '2', bid: 'C', group: '3', brief: 'Landy', desc: '5/4 majors'}
    ,{level: '2', bid: 'C', group: '3', brief: 'Michaels', desc: '5/5 majors'}
    ,{level: '2', bid: 'D', group: '1', brief: 'Benji open', desc: 'Benji 25+ points or game force'}
    ,{level: '2', bid: 'D', group: '2', brief: 'Benji re-lay', desc: 'Benji Waiting, denies strong 5 card suit'}
    ,{level: '2', bid: 'D', group: '2', brief: 'Cue bid 10+ points', desc: 'Support and 10+ points'}
    ,{level: '2', bid: 'D', group: '2', brief: 'Cue bid stopper', desc: 'Cue bid Asking for stopper'}
    ,{level: '2', bid: 'D', group: '2', brief: 'FSF', desc: 'Fourth suit forcing'}
    ,{level: '2', bid: 'D', group: '2', brief: 'Helvic 4D & 4H', desc: 'Helvic 4 4 diamonds hearts'}
    ,{level: '2', bid: 'D', group: '2', brief: 'Helvic 4D & 4S', desc: 'Helvic 4 diamonds & 4 spades'}
    ,{level: '2', bid: 'D', group: '2', brief: 'Helvic 4D & another', desc: 'Helvic lowest of two 4 card suits'}
    ,{level: '2', bid: 'D', group: '2', brief: 'Inverted minor', desc: 'Inverted minor. support to the 3 level'}
    ,{level: '2', bid: 'D', group: '2', brief: 'Transfer', desc: 'Transfer to hearts'}
    ,{level: '2', bid: 'D', group: '3', brief: 'Michaels', desc: '5/5 majors'}
    ,{level: '2', bid: 'D', group: '3', brief: 'Multi-Landy Major', desc: '6 card major'}
    ,{level: '2', bid: 'D', group: '3', brief: 'Multi-Landy Pick Major', desc: 'Partner to bid best major'}
    ,{level: '2', bid: 'D', group: '3', brief: 'Weak overcall', desc: 'weak 6 cards'}
    ,{level: '2', bid: 'H', group: '1', brief: 'Weak open', desc: 'weak 6 cards'}
    ,{level: '2', bid: 'H', group: '2', brief: 'Benji re-lay', desc: 'Benji relay denies strong 5 card suit'}
    ,{level: '2', bid: 'H', group: '2', brief: 'Cue bid 10+ points', desc: 'Support and 10+ points'}
    ,{level: '2', bid: 'H', group: '2', brief: 'Cue bid stopper', desc: 'Cue bid Asking for stopper'}
    ,{level: '2', bid: 'H', group: '2', brief: 'FSF', desc: 'Fourth suit forcing'}
    ,{level: '2', bid: 'H', group: '2', brief: 'Helvic 4H 4S', desc: 'Helvic 4 hearts 4 spades'}
    ,{level: '2', bid: 'H', group: '2', brief: 'Transfer', desc: 'Transfer to spades'}
    ,{level: '2', bid: 'H', group: '3', brief: 'Michaels', desc: '5 spades & 5 card minor'}
    ,{level: '2', bid: 'H', group: '3', brief: 'Multi-Landy', desc: '5 hearts & 4 card minor'}
    ,{level: '2', bid: 'H', group: '3', brief: 'Weak overcall', desc: 'weak 6 cards'}
    ,{level: '2', bid: 'NT', group: '1', brief: '20-22', desc: '20-22 points'}
    ,{level: '2', bid: 'NT', group: '1', brief: 'Benji 23-24', desc: '23-24 points'}
    ,{level: '2', bid: 'NT', group: '1', brief: 'Benji 25+', desc: '25+ points'}
    ,{level: '2', bid: 'NT', group: '2', brief: 'Jacoby', desc: 'Jacoby. 4 cards game force'}
    ,{level: '2', bid: 'NT', group: '2', brief: 'Lebensohl relay to 2C', desc: 'Lebensohl relay to 2C'}
    ,{level: '2', bid: 'NT', group: '2', brief: 'Ogust info request', desc: 'Ogust partner to describe suit'}
    ,{level: '2', bid: 'NT', group: '2', brief: 'Re-lay minors', desc: 'Relay to clubs'}
    ,{level: '2', bid: 'NT', group: '2', brief: 'Support & 10+ points', desc: '4 card support 10+ points'}
    ,{level: '2', bid: 'NT', group: '3', brief: 'Lebensohl relay to 2C', desc: 'Lebensohl relay to 2C'}
    ,{level: '2', bid: 'NT', group: '3', brief: 'Unusual other minor', desc: '5 cards in other minor and another suit'}
    ,{level: '2', bid: 'NT', group: '3', brief: 'Unusual, both minors', desc: '5 cards in both minors'}
    ,{level: '2', bid: 'S', group: '1', brief: 'Weak open', desc: 'weak 6 cards'}
    ,{level: '2', bid: 'S', group: '2', brief: '11-12 or 18+ points', desc: '11-12 or 18+ points'}
    ,{level: '2', bid: 'S', group: '2', brief: 'Cue bid 10+ points', desc: 'Support and 10+ points'}
    ,{level: '2', bid: 'S', group: '2', brief: 'Cue bid stopper', desc: 'Cue bid Asking for stopper'}
    ,{level: '2', bid: 'S', group: '2', brief: 'FSF', desc: 'Fourth suit forcing'}
    ,{level: '2', bid: 'S', group: '3', brief: 'Michaels', desc: '5 hearts & 5 card minor'}
    ,{level: '2', bid: 'S', group: '3', brief: 'Multi-Landy', desc: '5 spades & 4 card minor'}
    ,{level: '2', bid: 'S', group: '3', brief: 'Weak overcall', desc: 'weak 6 cards'}
    ,{level: '3', bid: 'C', group: '1', brief: 'Ogust response', desc: 'Ogust 1 hons weak'}
    ,{level: '3', bid: 'C', group: '1', brief: 'Pre-empt open', desc: 'Pre-emptive'}
    ,{level: '3', bid: 'C', group: '2', brief: 'Cue bid 10+ points', desc: 'Support and 10+ points'}
    ,{level: '3', bid: 'C', group: '2', brief: 'Cue bid stopper', desc: 'Cue bid Asking for stopper'}
    ,{level: '3', bid: 'C', group: '2', brief: 'Inverted minor', desc: 'Inverted minor. support 5-10 pts'}
    ,{level: '3', bid: 'C', group: '2', brief: 'Puppet stayman', desc: 'Puppet stayman for 5 card mjr'}
    ,{level: '3', bid: 'C', group: '3', brief: 'Pre-empt overcall', desc: 'Pre-emptive'}
    ,{level: '3', bid: 'D', group: '1', brief: 'Ogust response', desc: 'Ogust 2 hons weak'}
    ,{level: '3', bid: 'D', group: '1', brief: 'Pre-empt', desc: 'Pre-emptive'}
    ,{level: '3', bid: 'D', group: '1', brief: 'Puppet 4 card major', desc: 'Puppet shows 4 card major (denies 5)'}
    ,{level: '3', bid: 'D', group: '1', brief: 'Puppet no 5 card mjr', desc: 'Puppet denies 5 card mjr '}
    ,{level: '3', bid: 'D', group: '2', brief: 'Cue bid 10+ points', desc: 'Support and 10+ points'}
    ,{level: '3', bid: 'D', group: '2', brief: 'Cue bid stopper', desc: 'Cue bid Asking for stopper'}
    ,{level: '3', bid: 'D', group: '2', brief: 'Inverted minor', desc: 'Inverted minor. support 5-10 pts'}
    ,{level: '3', bid: 'D', group: '2', brief: 'Transfer', desc: 'Transfer to hearts'}
    ,{level: '3', bid: 'D', group: '3', brief: 'Pre-empt overcall', desc: 'Pre-emptive'}
    ,{level: '3', bid: 'H', group: '1', brief: 'Ogust response', desc: 'Ogust 1 honour 8+ pts'}
    ,{level: '3', bid: 'H', group: '1', brief: 'Pre-empt open', desc: 'Pre-emptive'}
    ,{level: '3', bid: 'H', group: '1', brief: 'Pre-empt overcall', desc: 'Pre-emptive'}
    ,{level: '3', bid: 'H', group: '2', brief: 'Cue bid 10+ points', desc: 'Support and 10+ points'}
    ,{level: '3', bid: 'H', group: '2', brief: 'Cue bid stopper', desc: 'Cue bid Asking for stopper'}
    ,{level: '3', bid: 'H', group: '2', brief: 'Transfer', desc: 'Transfer to spades'}
    ,{level: '3', bid: 'NT', group: '1', brief: 'Gambling 3NT', desc: 'Long minor suit, may not be balanced'}
    ,{level: '3', bid: 'NT', group: '1', brief: 'Ogust response', desc: 'Ogust Top 3 honours 8+ points'}
    ,{level: '3', bid: 'S', group: '1', brief: 'Ogust response', desc: 'Ogust 2 honours 8+ pts'}
    ,{level: '3', bid: 'S', group: '1', brief: 'Pre-empt open', desc: 'Pre-emptive'}
    ,{level: '3', bid: 'S', group: '2', brief: 'Cue bid 10+ points', desc: 'Support and 10+ points'}
    ,{level: '3', bid: 'S', group: '2', brief: 'First round control', desc: 'Ace or void in suit'}
    ,{level: '3', bid: 'S', group: '2', brief: 'Cue bid stopper', desc: 'Cue bid Asking for stopper'}
    ,{level: '3', bid: 'S', group: '2', brief: 'Splinter', desc: 'Splinter void or singleton'}
    ,{level: '3', bid: 'S', group: '3', brief: 'Pre-empt overcall', desc: 'Pre-emptive'}
    ,{level: '4', bid: 'C', group: '1', brief: 'Pre-empt open', desc: 'Pre-emptive'}
    ,{level: '4', bid: 'C', group: '2', brief: 'First round control', desc: 'Ace or void in suit'}
    ,{level: '4', bid: 'C', group: '2', brief: 'Pre-empt overcall', desc: 'Pre-emptive'}
    ,{level: '4', bid: 'C', group: '2', brief: 'Splinter', desc: 'Splinter void or singleton'}
    ,{level: '4', bid: 'D', group: '1', brief: 'Pre-empt open', desc: 'Pre-emptive'}
    ,{level: '4', bid: 'D', group: '2', brief: 'First round control', desc: 'Ace or void in suit'}
    ,{level: '4', bid: 'D', group: '2', brief: 'Pre-empt overcall', desc: 'Pre-emptive'}
    ,{level: '4', bid: 'D', group: '2', brief: 'Splinter', desc: 'Splinter void or singleton'}
    ,{level: '4', bid: 'H', group: '1', brief: 'Pre-empt open', desc: 'Pre-emptive'}
    ,{level: '4', bid: 'H', group: '2', brief: 'First round control', desc: 'Ace or void in suit'}
    ,{level: '4', bid: 'H', group: '2', brief: 'Pre-empt overcall', desc: 'Pre-emptive'}
    ,{level: '4', bid: 'H', group: '2', brief: 'Splinter', desc: 'Splinter void or singleton'}
    ,{level: '4', bid: 'NT', group: '2', brief: 'Quant', desc: 'Partner to bid 6NT with max else pass'}
    ,{level: '4', bid: 'NT', group: '2', brief: 'RKCB', desc: 'RKCB 13 04'}
    ,{level: '4', bid: 'S', group: '1', brief: 'Pre-empt open', desc: 'Pre-emptive'}
    ,{level: '4', bid: 'S', group: '2', brief: 'Second round control', desc: 'King or void in suit'}
    ,{level: '4', bid: 'S', group: '2', brief: 'Pre-empt overcall', desc: 'Pre-emptive'}
    ,{level: '5', bid: 'C', group: '2', brief: '1 or 4 key cards', desc: '1 or 4 key cards'}
    ,{level: '5', bid: 'C', group: '2', brief: 'Second round control', desc: 'King or void in suit'}
    ,{level: '5', bid: 'D', group: '2', brief: '0 or 3 key cards', desc: '0 or 3 key cards'}
    ,{level: '5', bid: 'D', group: '2', brief: 'Second round control', desc: 'King or void in suit'}
    ,{level: '5', bid: 'H', group: '2', brief: '2 key cards no queen', desc: '2 key cards missing Q of trumps'}
    ,{level: '5', bid: 'H', group: '2', brief: 'Second round control', desc: 'King or void in suit'}
    ,{level: '5', bid: 'NT', group: '2', brief: 'Asking for non-trump kings', desc: 'Asking for non-trump kings'}
    ,{level: '5', bid: 'S', group: '2', brief: '2 key cards and queen', desc: '2 key cards and queen of trumps'}
    ,{level: '6', bid: 'C', group: '2', brief: 'No kings', desc: 'No side suit kings'}
    ,{level: '6', bid: 'D', group: '2', brief: '1 king', desc: '1 king'}
    ,{level: '6', bid: 'H', group: '2', brief: '2 kings', desc: '2 kings'}
    ,{level: '6', bid: 'S', group: '2', brief: '3 kings', desc: '3 kings'}
    ];

const AbbreviationChars = 4;  //max number of characters in an abbreviation
const Abbreviations = {
    "A": "ace"
   ,"K": "king"
   ,"Q": "queen"
   ,"J": "jack"
   ,"T": "ten"
   ,"♣": "Club"
   ,"♦": "Diamond"
   ,"♥": "Heart"
   ,"♠": "Spade"
   ,"NT": "No Trump"
   ,"N": "north"
   ,"S": "south"
   ,"E": "east"
   ,"W": "west"
   ,"Dbl": "double"
   ,"Rdbl": "re-double"
   ,"Mic": "mike"
};



function getParams(callback){
    chrome.storage.local.get(null, function(store){
        if (store.sayNonSuit == null || store.sayNonSuit == undefined){
            setParams();
        }
        else{
            g_describeBoard = store.describeBoard;
            g_shape = store.shape;
            g_hcp = store.hcp;
            g_ltc = store.ltc;
            g_shapeDummy = store.shapeDummy;
            g_hcpDummy = store.hcpDummy;
            g_ltcDummy = store.ltcDummy;
            g_sayPlayedCard = store.sayPlayedCard;
            g_sayOwnCard = store.sayOwnCard;
            g_sayOtherBids = store.sayOtherBids;
            g_sayNonSuit = store.sayNonSuit;
            g_saySuitBids = store.saySuits;
            g_sayCardCnt = store.sayCardCnt;
            g_sayOK = store.sayOK;
            g_autoAcceptBids = store.autoAcceptBids;
            g_sayMouseOver = store.sayMouseOver;
            g_sayChat = (store.sayChat == undefined) ? g_sayChat : store.sayChat;
            g_sayChatSender = (store.sayChatSender == undefined) ? g_sayChatSender : store.sayChatSender;
            g_sayBroadcasts = (store.sayBroadcasts == undefined) ? g_sayBroadcasts : store.sayBroadcasts;
            g_sayAlertedBids = store.sayAlertedBids;
            g_sayBidExpReq = store.sayBidExpReq;
            g_sayRequests = store.sayRequests;
            g_autoSaySpeech = (store.autoSaySpeech == undefined ? g_autoSaySpeech : store.autoSaySpeech);
        };
        if (callback) callback(store);
    });
}


function paramsPack(){
    var params = {
        alertAssist: g_alertAssist,
        autoAcceptBids: g_autoAcceptBids,
        autoSaySpeech: g_autoSaySpeech,
        describeBoard: g_describeBoard,
        hcp: g_hcp,
        ltc: g_ltc,
        shape: g_shape,
        hcpDummy: g_hcpDummy,
        ltcDummy: g_ltcDummy,
        shapeDummy: g_shapeDummy,
        sayAlertedBids: g_sayAlertedBids,
        sayBidExpReq: g_sayBidExpReq,
        sayCardCnt: g_sayCardCnt,
        sayMouseOver: g_sayMouseOver,
        sayChat: g_sayChat,
        sayChatSender: g_sayChatSender,
        sayBroadcasts: g_sayBroadcasts,
        sayNonSuit: g_sayNonSuit,
        sayOK: g_sayOK,
        sayOtherBids: g_sayOtherBids,
        sayOwnCard: g_sayOwnCard,
        sayPlayedCard: g_sayPlayedCard,
        sayRequests: g_sayRequests,
        saySuitBids: g_saySuitBids
    };
    return params;
}

function paramsUnpack(params){
    g_alertAssist = params.alertAssist;
    g_autoAcceptBids = params.autoAcceptBids;
    g_autoSaySpeech = params.autoSaySpeech;
    g_describeBoard = params.describeBoard;
    g_hcp = params.hcp;
    g_ltc = params.ltc;
    g_shape = params.shape;
    g_hcpDummy = params.hcpDummy;
    g_ltcDummy = params.ltcDummy;
    g_shapeDummy = params.shapeDummy;
    g_sayAlertedBids = params.sayAlertedBids;
    g_sayBidExpReq = params.sayBidExpReq;
    g_sayCardCnt = params.sayCardCnt;
    g_sayMouseOver = params.sayMouseOver;
    g_sayChat = params.sayChat;
    g_sayChatSender = params.sayChatSender;
    g_sayBroadcasts = params.sayBroadcasts;
    g_sayNonSuit = params.sayNonSuit;
    g_sayOK = params.sayOK;
    g_sayOtherBids = params.sayOtherBids;
    g_sayOwnCard = params.sayOwnCard;
    g_sayPlayedCard = params.sayPlayedCard;
    g_sayRequests = params.sayRequests;
    g_saySuitBids = params.saySuitBids;
}


function setParams(callback){
    chrome.storage.local.set({"sayNonSuit": g_sayNonSuit, "saySuits": g_saySuitBids, "sayCardCnt": g_sayCardCnt, 
            "autoAcceptBids": g_autoAcceptBids, "sayOK": g_sayOK, "describeBoard": g_describeBoard,
            "shapeDummy": g_shapeDummy, "hcpDummy": g_hcpDummy, "ltcDummy": g_ltcDummy, 
            "shape": g_shape, "hcp": g_hcp, "ltc": g_ltc, "sayPlayedCard": g_sayPlayedCard, "sayOwnCard": g_sayOwnCard, 
            "sayOtherBids": g_sayOtherBids, 
            "sayMouseOver": g_sayMouseOver, "sayChat": g_sayChat, "sayChatSender": g_sayChatSender, "sayBroadcasts": g_sayBroadcasts, 
            "sayAlertedBids": g_sayAlertedBids,
            "sayBidExpReq": g_sayBidExpReq, "sayRequests": g_sayRequests,
            "autoSaySpeech": g_autoSaySpeech, 
            }, function(){
        if (callback) callback();
    });
}

