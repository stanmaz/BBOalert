'use strict';

$(function(){
    const sep = ";";

    $('#autoAcceptBids').click(function(){
        g_autoAcceptBids = document.getElementById("autoAcceptBids").checked;
        if (g_autoAcceptBids){
            document.getElementById("sayNonSuit").checked = false;
            g_sayNonSuit = false;
            document.getElementById("saySuits").checked = false;
            g_saySuitBids = false;
            document.getElementById("sayCardCnt").checked = false;
            g_sayCardCnt = false;
        }
        updateParams();
    });

    $('#autoSaySpeech').click(function () {
        g_autoSaySpeech = document.getElementById("autoSaySpeech").checked;
        updateParams();
    });

    $('#describeBoard').click(function(){
        g_describeBoard = document.getElementById("describeBoard").checked;
        updateParams();
    });
    
    $('#hcp').click(function(){
        g_hcp = document.getElementById("hcp").checked;
        updateParams();
    });

    $('#hcpDummy').click(function(){
        g_hcpDummy = document.getElementById("hcpDummy").checked;
        updateParams();
    });

    $('#help').click(function () {
        var url = chrome.runtime.getURL("BBOAssistHelp.htm");
        chrome.tabs.query({ url: url }, function (tabs) {
            if (tabs.length == 0) {
                chrome.windows.create({ url: url, type: "popup" }, function(window){
                    //chrome.tabs.executeScript(window.tabs[0].id, {file: "mouseReader.js"});
                    //chrome.tabs.executeScript({file: "constants.js"});
                    //chrome.tabs.executeScript({file: "mouseReaderInc.js"});
                });
            }
            else {
                chrome.windows.update(tabs[0].windowId, { focused: true });
            }
        });
    });


    $('#ltc').click(function (){
        g_ltc = document.getElementById("ltc").checked;
        updateParams();
    });
    
    $('#ltcDummy').click(function (){
        g_ltcDummy = document.getElementById("ltcDummy").checked;
        updateParams();
    });
    

    $('#mic').click(function () {
        var url = chrome.runtime.getURL("mic.html");
        chrome.tabs.query({url: url}, function (tabs) {
            if(tabs.length == 0){
                chrome.storage.local.get(["micDocDims"], function (store) {
                    if(store.micDocDims){
                        const d = store.micDocDims;
                        chrome.windows.create({url: url, top: d.top, left: d.left, width: d.width, height: d.height, type: "popup"});
                    }
                    else
                        chrome.windows.create({ url: url, type: "popup" });
                });
            }
            else{
                chrome.windows.update(tabs[0].windowId, {focused: true});
            }
        });

    });

    $('#close').click(function () {
        window.close();
    });

    $('#sayAlertedBids').click(function(){
        g_sayAlertedBids = document.getElementById("sayAlertedBids").checked;
        updateParams();
    });

    $('#sayBidExpReq').click(function(){
        g_sayBidExpReq = document.getElementById("sayBidExpReq").checked;
        updateParams();
    });

    $('#sayBroadcasts').click(function(){
        g_sayBroadcasts = document.getElementById("sayBroadcasts").checked;
        if (g_sayBroadcasts) {
            g_sayChat = true;
            document.getElementById("sayChat").checked = true;
        }
        updateParams();
    });

    $('#sayChat').click(function(){
        g_sayChat = document.getElementById("sayChat").checked;
        updateParams();
    });

    $('#sayChatSender').click(function(){
        g_sayChatSender = document.getElementById("sayChatSender").checked;
        updateParams();
    });

    $('#sayMouseOver').click(function(){
        g_sayMouseOver = document.getElementById("sayMouseOver").checked;
        g_mouseReader.enable(g_sayMouseOver);
        updateParams();
    });

    $('#sayNonSuit').click(function(){
        g_sayNonSuit = document.getElementById("sayNonSuit").checked;
        if (g_sayNonSuit){
            document.getElementById("autoAcceptBids").checked = false;
            g_autoAcceptBids = false;
        }
        updateParams();
    });

    $('#sayOtherBids').click(function(){
        g_sayOtherBids = document.getElementById("sayOtherBids").checked;
        updateParams();
    });
    
    $('#sayOwnCard').click(function(){
        g_sayOwnCard = document.getElementById("sayOwnCard").checked;
        updateParams();
    });
    
    $('#sayPlayedCard').click(function(){
        g_sayPlayedCard = document.getElementById("sayPlayedCard").checked;
        updateParams();
    });
    
    $('#sayRequests').click(function(){
        g_sayRequests = document.getElementById("sayRequests").checked;
        updateParams();
    });

    $('#saySuits').click(function(){
        g_saySuitBids = document.getElementById("saySuits").checked;
        if (g_saySuitBids){
            document.getElementById("autoAcceptBids").checked = false;
            g_autoAcceptBids = false;
        }
        updateParams();
    });

    $('#sayCardCnt').click(function(){
        g_sayCardCnt = document.getElementById("sayCardCnt").checked;
        if (g_sayCardCnt){
            document.getElementById("autoAcceptBids").checked = false;
            g_autoAcceptBids = false;
        }
        updateParams();
    });

    $('#sayOK').click(function(){
        g_sayOK = document.getElementById("sayOK").checked;
        updateParams();
    });

    $('#shape').click(function(){
        g_shape = document.getElementById("shape").checked;
        updateParams();
    });
    
    $('#shapeDummy').click(function(){
        g_shapeDummy = document.getElementById("shapeDummy").checked;
        updateParams();
    });
        
    function updateParams(callBack){
        setParams(function(){
            var params = paramsPack();
            chrome.runtime.sendMessage({op: MsgParamUpdate, params: params});
            if (callBack) callBack();
        });
    }
   

    getParams(function(){
        document.getElementById("sayNonSuit").checked = g_sayNonSuit;
        document.getElementById("saySuits").checked =  g_saySuitBids;
        document.getElementById("sayCardCnt").checked =  g_sayCardCnt;
        document.getElementById("sayOK").checked =  g_sayOK;
        document.getElementById("autoAcceptBids").checked =  g_autoAcceptBids;
        document.getElementById("describeBoard").checked =  g_describeBoard;
        document.getElementById("shape").checked =  g_shape;
        document.getElementById("hcp").checked =  g_hcp;
        document.getElementById("ltc").checked =  g_ltc;
        document.getElementById("shapeDummy").checked =  g_shapeDummy;
        document.getElementById("hcpDummy").checked =  g_hcpDummy;
        document.getElementById("ltcDummy").checked =  g_ltcDummy;
        document.getElementById("sayPlayedCard").checked =  g_sayPlayedCard;
        document.getElementById("sayOwnCard").checked =  g_sayOwnCard;
        document.getElementById("sayOtherBids").checked =  g_sayOtherBids;
        document.getElementById("sayMouseOver").checked =  g_sayMouseOver;
        document.getElementById("sayChat").checked =  g_sayChat;
        document.getElementById("sayChatSender").checked =  g_sayChatSender;
        document.getElementById("sayBroadcasts").checked =  g_sayBroadcasts;
        document.getElementById("sayAlertedBids").checked =  g_sayAlertedBids;
        document.getElementById("sayBidExpReq").checked =  g_sayBidExpReq;
        document.getElementById("sayRequests").checked =  g_sayRequests;
        document.getElementById("autoSaySpeech").checked = g_autoSaySpeech;

        g_mouseReader.init(g_sayMouseOver);
    });

    
    $('#test').click(function(){

        var msg = document.body;
        var cr = "<br />";
        var event_list = ["onaudioend", "onaudiostart", "onend", "onerror", "onnomatch", "onresult", "onsoundend", "onsoundstart", "onspeechend", "onspeechstart", "onstart"];
        var sr = window.SpeechRecognition || window.webkitSpeechRecognition || false;

        if (sr) {
            var recognition = new sr();
            event_list.forEach(function(e) {
                recognition[e] = function() { 
                    console.log(event); 
                    var txt = event.type + ": ";
                    if (event.results) txt += event.results[0][0].transcript;
                    if (event.error) txt += event.error; // "not-allowed" usually is because of not using secure https protocol
                    if (event.type == "end") 
                        recognition.start(); // Start Recognition again
                    msg.innerHTML += txt + cr;
                };  
            });
            recognition.start();
        }
        else {
            msg.innerHTML += "This browser does not support SpeechRecognition or webkitSpeechRecognition." + cr;
        }
    });




});

