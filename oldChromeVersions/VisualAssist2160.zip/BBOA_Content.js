'use strict';

/*DOM Element changes for a board in the middle of playing a hand (played cards displayed called in the following sequence after restart
    DOMTableRootChanges
    DOMRootNotificationChange
    CheckBoardNumberCreated (it was but not populated)
    DOMBiddingBoxChange (not visible)
    DOMExplainBidChange (not visible)
    DOMPlayingSurfaceChange
    DOMHandDiagramChange
    DOMAuctionBoxChange
    DOMSideTabChange
*/

let m_debug = false;

//The 4 seat elements are listed within the DOM in the following order.
const SeatOrder = ["S", "W", "N", "E"];
const SeatIndex = {"S": 0, "W": 1, "N": 2, "E": 3};
const SuitSymbolIndex = {"♣": 0, "♦": 1, "♥": 2, "♠": 3};


const BiddingBoxClass = "biddingBoxClass";
const BiddingBtnClass = "biddingBoxButtonClass";
const BoardNumberClass = "vulPanelInnerPanelClass";

const AlertIdStr = "bboa-salist";

//players who can use the self alerting and other checks (Donald's illness)
const m_specialPlayers = ["johnlambe", "Dreidd", "katelambe"];

//array that defines the query selectors for a playing table rather than a history table.
//The following is the standard playing table. Need one for solitaire games.
const TableEls = [
    {TableRoot: "div.navDivClass", table : "BRIDGE-SCREEN", boardNumber: "div.vulPanelInnerPanelClass",
    seats: ".nameBarDivClass", hands: "div.handDiagramPanelClass",
    tableCloth: "cardSurfaceClass"}
];


let debug = false;
let m_lastMouseX = -1;
let m_lastMouseY = -1;

//params shared with the extension
let m_params = {
    sayNonSuit: false,
    saySuitBids: false,
    sayCardCnt: true,
    sayOK: true,
    sayPlayedCard: true,
    sayOwnCard: false,
    sayOtherBids: true,
    sayMouseOver: true,
    sayChat: true,
    autoSaySpeech: true,
    sayAlertedBids: true,
    sayBidExpReq: true,
    sayRequests: true,
    alertAssist: true           //display the self alert tab when alert button clicked
};

let m_boardsLog = [];   //an array with an entry for each board. Stores the bids and tricks for each board
let m_boardDetails = []; //board data set when the hand is first displayed
let m_cardPack = [];    //one entry for each card ordered by suit and from ace to 2.
let m_trick = [];       //the current trick (4 cards) in the sequence the cards were played
let m_orderedCards = [];  //current trick in SWNE sequence
let m_boardTrick = [];  //records the data for each trick

let m_tricks = [];      //all the played tricks for a board in sequence
let m_ourTrickCount = 0;   //number of tricks won by the partnership on the current board
let m_oppsTrickCount = 0;   //number of tricks won by opponents
let m_cardsPlayedCnt = 0;   //number of cards played in the current board

let msgCounter = 0;
let clickCnt = 0;
let errorCnt = 0;
let m_logCnt = 0;

let m_prevBtnId = -1;
let m_currentTable;
let m_boardNumberCreated = false;       //the playing board number is available so is the table
let m_hand = {};
let m_board = 0;
const AuctionPhase = 1, PlayingPhase = 2;
let m_boardPhase = 0;

let m_prevClickEl;      //button last clicked
let m_clickEl;          //button just clicked
let m_prevTextNode = null;
let m_biddingBoxDisplayTime = 0;  //time when the bidding box was last displayed

let m_biddingBoxVisisble = false;  //bidding box not displayed
let m_alertBtnState = false;     //alert bid not slected
let m_bidLevelBtnId = null;      //currently selected bidding level
let m_bidSuitBtnId = null;       //currently selected suit/nt bid
let m_ownLastBid = "";
let m_lastExplainedBid = "";        //the last bid alerted 
let m_lastExplainedBidText = "";    //text of last bid alerted so it can be read out when bid displayed
let m_pendingBidExplanation = false;//true if a bid explanation has not yet been read
let m_lastAuctionBidClicked = "";   //bid clicked in the auction so may get an explanation for it
let m_ownSeat = "";             //position of the table at which this player is sitting (e.g. "S")
let m_ownName = "";
let m_userName;                 //set username to null until element has been created
let m_playersSeat = {};         //translates each player's name to seat position
let m_partnerSeat = "";
let m_partnerName = "";
let m_currentContract = "";     //current contract
let m_trickFirstCard;           //first trick played in a trick (required just in case lose track of cards played)

//variables to delay the sending of mouseOver text msgs to ensure mouse is stationary
let m_mouseOverText = "";
let m_mouseOverTimer = 0;
let m_mouseOverTimeMS = 100;
let m_mouseOverTime = 0;

//self alert variable
let m_prevSideTabEl = null;
let m_monitorSideTabWidth = null;  //width for the current side tab
let m_prevSideTabDisplay = "";
let m_selfAlertEl = null;
let m_selfAlertCard = {title: "No Card Defined", bids: []};
let m_alertTabSource = "";  //whether the "current" bid or a previous "explain" one
let m_bidExplainRequest = false;
let m_bidExplainLevel = "";
let m_bidExplainSuit;
let m_lastBoardNotification = "";        //last notification text (reject/accepted)
let m_lastBoardNotificationTime = 0;     //time of last notification text (reject/accepted)
let m_lastPlayedCard = {};
let m_currentTrick = 0;

let m_tableRootEl;          //root container element for the table - table is added and removed from this root
let m_tableEl;              //the table containing the other elements - main root for a displayed board.
let m_playingSurfaceEl;     //cards playing surface (green cloth)
let m_biddingBoxEl;         //container for the bidding box
let m_boardNumberEl;        //element that displays the board number; used to detect new boards
let m_bidExplanationEl;     //displays an explanation of another player's bid
let m_explainBidEl;         //pop-up asking you to explain a bid
let m_monitorSideTabEl;     //one of the side tabs in order to monitor size changes
let m_handDiagramEls = [];  //container for the handDiagrams (4; one for each card in the current trick)
let m_tricksPanelEl;        //containing display node for the contract and trick counters
let m_ourTrickCntEl;       //number of tricks won by our side
let m_oppsTrickCntEl;       //number of tricks won by the opponents
let m_declarerSeatEl;       //seat that has the contract (e.g. West)
let m_declarerContractEl;   //the contract declared for the current board.
let m_auctionBoxEl;           //the node that displays the auction box (seat headers and bids made)
let m_auctionBoxBidsEl;       //contains a child for each bid made
let m_everythingEl;         //bbo everything node
let m_chatMessagesEl;       //chat message list
let m_boardEndPanelEl;       //displays the result of the played board
let m_autoBridgeSolver = 0;   //history review board - automatically display the bridge solver after the board has finished if non-zeor


let m_chatMic;            //speech to text object for the chat input
let m_alertMic;            //speech to text object for the self alert input
let m_explainMic;            //speech to text object for the bid explanation pop-up input
let m_lastMic;              //last mic used to send text

let m_playingSurface = {X: -1, Y: -1};       //dimensions of the playing surface

let m_nextAuctionSlotToSpeak = 0;  //index to the next auction node that will be process when the node is populated
let m_auctionBids = [];         //list of the bids for the current board
let m_lastSuitBidIx = -1;     //index into m_auctionBid of the last suit bid (a level and suit or NT)

let m_myFirstBid = true;       //is this my first bid on the board?
let m_specialPlayer = false;    //extra features

let m_tableRootObs = new MutationObserver(DOMTableRootChanges);
let m_boardNumberObs = new MutationObserver(DOMBoardNumberChange);
let m_biddinBoxObs = new MutationObserver(DOMBiddingBoxChange);
let m_bidExplanationObs = new MutationObserver(DOMBidExplanationChange);
let m_explainBidObs = new MutationObserver(DOMExplainBidChange);
let m_boardNotificationMsgObs = new MutationObserver(DOMBoardNotificationChange);
let m_announcementObs = new MutationObserver(DOMAnnouncementChange);
let m_rootNotificationMsgObs = new MutationObserver(DOMRootNotificationChange);
let m_monitorSideTabObs = new MutationObserver(DOMSideTabChange);
let m_playingSurfaceObs = new MutationObserver(DOMPlayingSurfaceChange);
let m_handDiagramObs = new MutationObserver(DOMHandDiagramChange);
let m_auctionBoxObs = new MutationObserver(DOMAuctionBoxChange);
let m_auctionBoxBidsObs = new MutationObserver(DOMAuctionBoxBidsChange);
let m_auctionBoxNewBidObs = new MutationObserver(DOMAuctionBoxNewBidChange);
let m_auctionContractPanelObs = new MutationObserver(DOMAuctionContractPanel);
let m_chatMessagesObs = new MutationObserver(DOMChatMessages);
let m_boardEndPanelObs = new MutationObserver(DOMBoardEndPanelChange);

let m_deck = [];    //one entry for each card in a deck - populated by initDeck

m_monitorSideTabObs

let m_announcementText = "";  //text displayed in the announcement pop-up


//find the seat that has the specified co-ordinate
function auctionBoxGetSeat(left){
    var seats = m_auctionBoxEl.querySelectorAll(".auctionBoxHeaderCellClass");
    var el;
    for (let i = 0; i < seats.length; i++) {
        el = seats[i];
        if (el.offsetLeft == left) return el.innerText;
    };
    return null;
}


//find the alert button
function BiddingBoxAlertBtn(root) {
    var btns = root.querySelector("input");

    return btns.nextSibling;
}

function BiddingBoxAlertBtn1(root) {
    var btns = root.querySelectorAll(".biddingBoxButtonClass");
    for (let i = 0; i < btns.length; i++) {
        const el = btns[i];
        if (el.innerText == "Alert") {
            return el;
        }
    }
    return null;
}


function boardInit(board) {
    m_board = board;
    m_hand = readHandDetails();
    m_specialPlayer = specialPlayer(m_hand.yourName);
    var myHand = "S" + m_hand.suits[0] + "H" + m_hand.suits[1] + "D" + m_hand.suits[2] + "C" + m_hand.suits[3];
    m_boardDetails[board - 1] = {ownName: m_hand.yourName, ownHand: myHand, ownSeat: m_hand.yourSeat};
    return;
}

//start of a board has been detected - empty auction box displayed
function boardNew() {
    var board = parseInt(m_boardNumberEl.innerText);
    if (board > 0) {
        if (board == 1){
            //first board so reset table
            m_boardsLog.length = 0;
        }
        else{
            //previous board finished or a restart
            var prevBoard = board - 1;
            if (!m_boardsLog[prevBoard - 1]){
                var cloneBids = JSON.parse(JSON.stringify(m_auctionBids));
                var cloneTricks = JSON.parse(JSON.stringify(m_boardTrick));
                m_boardsLog[prevBoard - 1] = {bids: cloneBids, tricks: cloneTricks, ptrTricks: 0,  oppTricks: 0, 
                    contractTricks: 0, score: 0};   
                if(m_specialPlayer) speakText("End of board " + prevBoard + " not detected", SpeakInfo);
            }
        };

        m_nextAuctionSlotToSpeak = 0;
        resetAuctionBids();
        m_myFirstBid = true;
        m_lastAuctionBidClicked = "";
        m_ownLastBid = "";
        m_currentContract = "";
        m_currentTrick = 0;

        trickBoardInit();
        consolelog("::::boardNew boardInit");
        boardInit(board);
        chrome.runtime.sendMessage({ op: MsgNewBoard, board: board, hand: m_hand });
    }
}


//see if the node contains the DOM for a table
function CheckBoardNumberCreated(container){
    m_tableEl = container.querySelector(m_currentTable.table);
    if (m_tableEl){
        var boardPanel = m_tableEl.querySelector(m_currentTable.boardNumber);
        if (boardPanel){
                //board exists so create the other elements used
                m_tricksPanelEl = m_tableEl.querySelector(".tricksPanelClass");
                var trickPanels = m_tricksPanelEl.querySelectorAll(".tricksPanelTricksLabelClass");
                m_declarerSeatEl = trickPanels[0];
                m_ourTrickCntEl = trickPanels[1];
                m_oppsTrickCntEl = trickPanels[2];
                m_declarerContractEl= m_tricksPanelEl.querySelector("auction-box-cell");
                
                var board = parseInt(boardPanel.innerText);
                m_boardNumberEl = boardPanel;
                monitorBoard(boardPanel);
            return true;
        }
    }
    return false;
}

function checkForTextNode(node, maxDepth, depth, id){
    var text ;
    if(node.firstChild == null){
        if (node.nodeName == "INPUT"){
            text = (node.type == "password" ? "Enter password" : node.value);
        }
        else text = node.data;
        if (text && text.length > 0)
            return {node: node, text: text};
        else return null;
    }

    depth = (depth ? depth : 0);
    if (depth >= maxDepth) 
        return null; //too nested
 
    var textNode = null;
    var result;
    //loop through the children for a text child node
    for (let i = 0; i < node.childNodes.length; i++) {
        const el = node.childNodes[i];
        result = checkForTextNode(el, maxDepth, depth + 1, i);
        if (result != null){
            //text node found but can only be one
            if (textNode != null) return null;   //already found one so too many
            textNode = result;
        }
    }
    return textNode;
}

//see if the table has been removed
function CheckTableRemoved(parent){
    var container = parent.querySelector(m_currentTable.boardNumber);
    return (container == null || container == undefined );
}


//simulate the OK button being clicked
function clickBiddingBoxOKBtn(){
    //now find all the bidding buttons and the OK button
    var okBtn = biddingBoxOKBtnGet();
    if (okBtn) okBtn.click();
}

function compareCards(a, b){
    if (!a || !b) return false;
    return (a.suit == b.suit && a.card == b.card);
}


function consolelog(text){
    //m_debug = true;
    if (m_debug) console.log(text);
}

function biddingBoxOKBtnGet(){
    //now find all the bidding buttons and the OK button
    var bidBtns = m_biddingBoxEl.getElementsByClassName(BiddingBtnClass);
    for (let i = 0; i < bidBtns.length; i++) {
        const element = bidBtns[i];
        if (element.innerText.trim() == OKBtnText) {
            return element;
        }
    }
    return null;
}


//simulate the OK button being clicked on the explaination request popup
function clickExplainRequestOKBtn(){
    //Only one explain button
    var bidBtns = m_explainBidEl.querySelector("button");
    m_ownLastBid = m_bidExplainLevel + m_bidExplainSuit;
    if (bidBtns) bidBtns.click();

}

//use Bridge Solver to display the board
function displayBridgeSolver(root, board, checkSrcHand){
    var url = "https://mirgo2.co.uk/bridgesolver/invoke_bsol2.php";
    var str = buildLinStr(root, board, checkSrcHand);
    consolelog("BBO:" + str);
    chrome.runtime.sendMessage({op: "MsgPost", url: url, params: str, ext: "lin"});
}


//The pop-up that displays claim and undo announcements.
function DOMAnnouncementChange(mutations) {
    if (!m_params.sayRequests) return;

    var node = mutations[0].target;
    var boxVisible = (node.style.display != "none");
    //var text = node.innerText;;
    var text = node.querySelector(".messageClass").innerText;;
    if (boxVisible && text != "" ){  //&& text != m_announcementText
        speakText("Pop-up, " + text, SpeakClaimUndoRequest);
    };
    m_announcementText = node.innerText;
}

//called when a new bid has been displayed in the auction box
function DOMAuctionBoxNewBidChange(mutations) {
    var node = mutations[0].target;
    if (node.offsetLeft && node.innerText != ""){
        //looks like the bid is now visible so list all the new ones.
        var bids = m_auctionBoxBidsEl.querySelectorAll(".auctionBoxCellClass");

        DOMAuctionBoxNewBids(bids);
        //stop monitoring this node
        m_auctionBoxNewBidObs.disconnect();
    }
}

//called when a new bid has been added or deleted to/from the auction box
//When a new bid node is added it is not yet usually populated with the bid details so may have to monitor that bid for updates.
//More than one bid can be added at a time typically when playing with Robots so need to handle these.
//Nodes are deleted when bidding has finished or when an undo has been accepted.
function DOMAuctionBoxBidsChange(){
    let options = {
        attributes: true,
        attributeFilter: ['style']
    };

    var display = m_auctionBoxEl.style.display;
    if (display == "" || display == "none") return;

    var bids = m_auctionBoxBidsEl.querySelectorAll(".auctionBoxCellClass");
    if (m_nextAuctionSlotToSpeak > bids.length){
        //looks like bids have been removed (an undo accepted)
        m_nextAuctionSlotToSpeak = bids.length;
        resetAuctionBids(m_nextAuctionSlotToSpeak)
        //no bids could be a redeal or an undo - treat as a reset of the board
        if (m_nextAuctionSlotToSpeak == 0) boardNew();  

    }
    else {
        //speak any missed bids and monitor the last bid node not populated
        DOMAuctionBoxNewBids(bids);
        if (m_nextAuctionSlotToSpeak < bids.length){
            //still bid(s) not yet populated so wait for the display.
            m_auctionBoxNewBidObs.disconnect();
            m_auctionBoxNewBidObs.observe(bids[m_nextAuctionSlotToSpeak], options);
        }
    };
    playingSurfaceResized();
}


//called when the auction box is displayed or removed
function DOMAuctionBoxChange(){
    //save the table's dims every so often so can detect a change later
    playingSurfaceResized();

    var board = parseInt(m_boardNumberEl.innerText);
    if (board > 0 && board < 99){
        var display = m_auctionBoxEl.style.display;
        if (display == "" || display == "none"){
            //auction box not visiable so first cards has been played
            if (m_boardPhase != PlayingPhase){
                //auction completed so started play
                m_boardPhase = PlayingPhase;
            }
        }
        else {
            //auction box is visible so could be start of new board or a non-event
            //save the time the box was displayed so an attempted clicked on the tablecloth will not be treated
            //as a bid by mistake
            m_biddingBoxDisplayTime = Date.now();

            //if (m_boardPhase != AuctionPhase){
                var bids = m_auctionBoxEl.querySelectorAll(".auctionBoxCellClass");
                m_boardPhase = AuctionPhase;
                if (bids.length == 0 || bids[0].innerText == ""){
                    boardNew();
                }
            //};
            //make sure the microphone has been created
            if (m_biddingBoxEl){
                var node = m_biddingBoxEl.querySelector("#alertMicrophone");
                if (!node) {
                    node = BiddingBoxAlertBtn(m_biddingBoxEl);
                    var inputEl = m_biddingBoxEl.querySelector("input");
                    var micEl = micInputCreate("alertMicrophone", inputEl);
                    m_alertMic = new SpeechToText(inputEl, micEl, chrome.runtime.getURL('images/micOff.png'),
                        chrome.runtime.getURL('images/micPulse.gif'), chrome.runtime.getURL('images/micError.png'), speechEntryCallback,
                        biddingBoxOKBtnGet(), clickBiddingBoxOKBtn);
                }
            }
        }
    }
}

//process a new bid displayed in the auction box and speak it if required
//bids: all the bid elements
//bidIndex: index to the bids to be processed
//firstSpeak: 
function DOMAuctionBoxNewBid(bids, bidIndex, yourLastBidIndex){
    var node = bids[bidIndex];
    var bidText = node.innerText;
    var text = "";
    var alerted = false;
    var explanation = "";
    var bidObj = new Bid(bidText);

    var seat = auctionBoxGetSeat(node.offsetLeft);
    if (seat){  //something gone wrong if can't find the seat
        //determine if a jump bid
        if (m_lastSuitBidIx > -1) bidObj.setJump(m_auctionBids[m_lastSuitBidIx]);

        text = saySeat(seat);
        if (bidObj.jump) text += " Stop jump";
        text += " " + sayBid(node.innerText);
        //if the bid was alerted say the alert rather than just the bid
        alerted = (node.style.border && node.style.border != "") ? true : false;
        if (alerted || (node.style.backgroundColor && node.style.backgroundColor != "")){
            consolelog("Self Alerted Bid:" + text + ", lastText:" + m_lastExplainedBid + ", text:" + m_lastExplainedBidText);
            text += " alerted";  
        };

        if (m_pendingBidExplanation && m_lastExplainedBid == bidText){
            explanation = m_lastExplainedBidText;
            m_pendingBidExplanation = false;
        }

        //Only speak the bid if not your own bid, as long as the contract hasn't already been announce and
        //if the bid isn't an old one
        if (m_params.sayOtherBids && seat != m_ownSeat && m_currentContract == "" && bidIndex >= yourLastBidIndex){
            speakText(text, SpeakOtherBid);
            if (explanation != "") speakText(explanation, SpeakBidExplanation);
        }
        else{
            //if own bid then terminate any prior bid announcements.
            if (seat == m_ownSeat && m_params.sayOtherBids){
                speakText("", SpeakOtherBid, true);
            };
        }

        bidObj.alerted = alerted;
        bidObj.explanation = explanation;
        m_auctionBids[bidIndex] = bidObj; 
        if (bidObj.isLevelBid()) m_lastSuitBidIx = bidIndex;
    }
}


//read any bids that have not been read. If playing against robots these could arrive in bulk but also
//don't want to read out all previous bids if just lost connection and restarted
//"bids" is an array of all the bid elements made so far
function DOMAuctionBoxNewBids(bids){
    var seat;
    var yourLastBid = 0;
    var cnt = bids.length - m_nextAuctionSlotToSpeak; 
    if (cnt > 1 && m_nextAuctionSlotToSpeak == 0){
        //more than 1 outstanding bid to speak so, just in case this is a restart, don't speak further back than own last bid
        //but still populate other bids for LIN format
        for (let i = 0; i < bids.length; i++) {
            const el = bids[i];
            if (el.offsetLeft && el.innerText != "") {
                seat = auctionBoxGetSeat(el.offsetLeft);
                if (seat && seat == m_ownSeat) yourLastBid = i;
            }
            //else break;
        }
    }

    for (let i = m_nextAuctionSlotToSpeak; i < bids.length; i++) {
        const el = bids[i];
        if (el.offsetLeft && el.innerText != ""){
             DOMAuctionBoxNewBid(bids, i, yourLastBid);
             m_nextAuctionSlotToSpeak++;
        }
        else break;
    }
}

//monitoring the element that displays the contract
function DOMAuctionContractPanel(mutations) {
    const contractLead = {"N": "E", "E": "S", "S": "W", "W": "N"};
    var display = m_tricksPanelEl.style.display;
    if (display != "" && display != "none") {
        var contract = m_declarerContractEl.innerText;
        if (contract != "" && contract != m_currentContract) {
            m_currentContract = contract;
            var declarer = m_declarerSeatEl.innerText.substr(0, 1);
            var parts = parseContract(contract);  //split contract into bid and double text
            var text = "Contract " + parts.bid;
            if (declarer == m_ownSeat){
                text += " " + parts.double + ". You are the declarer";
            }
            else if (declarer == m_partnerSeat){
                text += " by your partner" + ", " + parts.double;
            }
            else {
                text += " by " + saySeat(declarer) + ", " + parts.double;;
                var lead = contractLead[declarer];
                if (lead == m_ownSeat) text += ". It's your lead";
            }
            if (m_params.sayOtherBids) speakText(text, SpeakContract);
        }
    }
}


//Bidding box state change
function DOMBiddingBoxChange(mutations) {
    var node = mutations[0].target;
    var boxVisible = (node.style.display != "none");
    if (boxVisible != m_biddingBoxVisisble){
        //change of state - either was hidden and now visible or visible and now hidden
        m_biddingBoxVisisble = boxVisible;
        m_alertBtnState = false;
        m_bidLevelBtnId = -1;
        m_bidSuitBtnId = -1;
        m_prevBtnId = -1;
        if (!boxVisible){
            //bidding box has disappeared. make sure the self alert display is not visible unless bid explanation also active
            selfAlertClose(); 
        };           
    };
}

function DOMBidExplanationChange(mutations) {
    //popup explaining a player's bid including your own alerts (but ignore the latter)
    //The pop-up is either a new bid or the explanation of an old bid the user has click on.
    //If a new bid the explanation needs to be delayed until the bid has been displayed in the
    //auction box (explantation appears in the DOM first). However, if the explanation is for
    //a prior bid read it out. If the first bid by a robot was alerted then the explanation is 
    //populated even before the new board is displayed so can't reset the explanation variables 
    //at the start of a new board.

    //First target in the mutations is the bid and the others are the explanation
    var text = "";
    var alert = "";

    var bidNode = mutations[0].target;
    if (bidNode.style.display != "none"){
        if (bidNode.innerText != undefined && bidNode.innerText != ""){
            for (let i = 1; i < mutations.length; i++) {
                alert += " " +  mutations[i].target.innerText;  
            }

            consolelog("Alert Bid:" + bidNode.innerText + ", text:" + alert);
            //need to protect against repeating an explanation because the playing surface was resized or
            //the hand display format was changed
            if (alert != "" && (m_lastExplainedBid != bidNode.innerText || m_lastAuctionBidClicked == bidNode.innerText)){
                m_lastExplainedBid = bidNode.innerText;
                m_lastExplainedBidText = alert;
                //was this explanation requested by the user 
                if (m_lastAuctionBidClicked == bidNode.innerText){
                    text = sayBid(bidNode.innerText) + " alerted "; 
                    consolelog("DOMBidExplanationChange muts:" + mutations.length + ", text:" + text);
                    //don't read the bid if it was our last bid or if a bid explanation was required by opponents
                    //do read out a bid the user clicked on even if their own bid.
                    if ((bidNode.innerText != m_ownLastBid) || (m_lastAuctionBidClicked == bidNode.innerText)){
                        speakText(text, SpeakOtherBid);                       
                        speakText(alert, SpeakBidExplanation);   
                    }
                    m_lastAuctionBidClicked = "";
                    m_pendingBidExplanation = false;                    
                }
                else{
                    //just make sure you didn't just update a bid explanation request for your own bid
                    if (bidNode.innerText != m_ownLastBid && m_params.sayAlertedBids){
                        //delay the explanation until the bid is read out
                        m_pendingBidExplanation = true;                    
                        setTimeout(DOMBidExplanationTimer, 100);

                    }
                };
            };    
        };
    }
}

//delay for reading bid explanation so see if there is still one to read
function DOMBidExplanationTimer(){
    //explanation may have been read out when bid was displayed or the playing surface may have been changed which
    //could have triggered this event
    if (m_pendingBidExplanation && m_params.sayAlertedBids){
        var text = sayBid(m_lastExplainedBid) + " alerted"; 
        speakText(text, SpeakOtherBid);                       
        speakText(m_lastExplainedBidText, SpeakBidExplanation);                       
    }
    m_pendingBidExplanation = false;
}

function DOMBoardEndPanelChange(mutations) {
    //pop-up that indicates the result of the board
    var text = m_boardEndPanelEl.innerText.trim();
    if (text != ""){
        text = text.toLocaleLowerCase();
        var words = text.split(" ");
        var idx = findStrMatch("trick", words);
        var contractTricks = (idx >= 1 ? words[idx - 1] : "");
        var score = words[words.length - 1];    //last word is the score

        var board = parseInt(m_boardNumberEl.innerText);
        var ptrs = parseInt(m_ourTrickCntEl.innerText);
        var opps = parseInt(m_oppsTrickCntEl.innerText);
        var cloneBids = JSON.parse(JSON.stringify(m_auctionBids));
        var cloneTricks = JSON.parse(JSON.stringify(m_boardTrick));
        m_boardsLog[board - 1] = {bids: cloneBids, tricks: cloneTricks, ptrTricks: ptrs,  oppTricks: opps, 
            contractTricks: contractTricks, score: score};   
        if (m_params.sayOtherBids) speakText(text, SpeakOtherBid);
        if (m_autoBridgeSolver != 0) displayBridgeSolver(m_tableRootEl, board);
    };
}

function DOMBoardNotificationChange(mutations) {
    //pop-up that indicates if something was rejected or accepted
    if (!m_params.sayRequests) return;
    var node = mutations[0].target;
    var text = node.innerText;;
    if (text != ""){
        var now = Date.now();
        //ignore duplicates due to a fading effect
        if (m_lastBoardNotification != text || (now - m_lastBoardNotificationTime) > 200){
            speakText(text, SpeakRejectedAccepted);
            m_lastBoardNotification = text;
        }
        m_lastBoardNotificationTime = now; 
    };
}

//New board (board number has been changed)
function DOMBoardNumberChange(mutations) {
    var node = mutations[0].target;
    if (mutations[0].type == "characterData"){
        consolelog("::::DOMBoardNumberChange boardInit");

        boardInit(parseInt(m_boardNumberEl.innerText));
    };
}

//chat message added or maybe all chat messages removed
function DOMChatMessages(mutations) {
    function translateSender(name){
        //translate the name to a seat position or to director
        var seat = m_playersSeat[name];
        if (seat) return seat;
        if (name.startsWith("vEBU")) return "Director";
        if (name.startsWith("VACB")) return "Director";
        return name;
    };

    var msgs = m_chatMessagesEl.querySelectorAll("chat-list-item");
    var idx = msgs.length - 1;
    var sender;
    var dest;
    if (idx >= 0){
        var msg = msgs[idx].innerText;
        //new message so ignore if from yourself. Format of displayed line is: "[sender]->[dest]: [message]" for table and lobby messages
        //and is "[sender] (Private): [message]" for private messages.
        //[sender] is blank if you sent the message.
        //[dest] can be "Table", "Lobby" or, for messages from a director, "Tournament"

        //get the sender
        var sender = "";
        var broadcast = false;
        idx = msg.indexOf("→");
        if (idx >= 0){
            //format is "[sender]->[dest]: [message]"
            //if "Tournament" use "Director" as the sender
            sender = msg.substring(0, idx);
            var colon = msg.indexOf(":", idx);
            dest = msg.substring(idx + 1, colon);
            if (dest == "Tournament") {
                broadcast = true;
                sender = "Director";
            }
            else sender = translateSender(sender);
        }
        else{
            //format should be "[sender] (Private): [message]"
            idx = msg.indexOf(" (");
            if (idx > 0){
                sender = translateSender(msg.substring(0, idx));
            }
            else{
                //Assume format is "[sender]: [message]"
                idx = msg.indexOf(":");
                sender = msg.substring(0, idx);
            }                 
        };

        //ignore own messages
        if (sender != ""){
            if (m_params.sayChat){
                //only say broadcast messsages if table not displayed or if flag set to say broadcast msgs
                if (!broadcast || !m_boardNumberCreated || m_params.sayBroadcasts){
                    idx = msg.indexOf(":");
                    var text = msg.substr(idx + 1);
                    if(m_params.sayChatSender) speakText("Sender " + sender + " message " + text, SpeakChat);
                    else speakText("Message " + text, SpeakChat);   
                }
            }
        }
    }
}

function DOMExplainBidChange(mutations) {
    //popup asking you to explain one of your bids
    if (!m_params.sayBidExpReq) return;
    var node = mutations[0].target;
    if (node){
        var state = (node.style.display != "none");
        if (state){
            m_bidExplainRequest = true;
            var heading = node.querySelector("div.headingClass");
            var text = (heading ? heading.innerText : node.innerText);
            var bid = findBid(text);
            if(bid){
                m_bidExplainLevel = bid.level;
                m_bidExplainSuit = bid.suit;
                text = "Pop-up. Please explain your " + saySuitBid(m_bidExplainLevel, m_bidExplainSuit);
                consolelog("DOMExplainBidChange muts:" + mutations.length + ", text:" + text);
                speakText(text, SpeakExplainBid);
                //very unlikely that it's your turn to bid again and an explanation of a previous bid has
                //been requested but just need to check the alert assist tab not already active
                if (!m_alertBtnState){
                    selfAlertShow();
                    selfAlertUpdateDisplay("explain", m_bidExplainLevel, m_bidExplainSuit);
                }
            };    
        }
        else{
            //has the window just been closed?
            if (m_bidExplainRequest){
                m_bidExplainRequest = false;
                if (m_params.sayOK) speakText("OK", SpeakBidExplainedOK);
                selfAlertClose();
            };
        }
    }
}

function DOMHandDiagramChange(mutations) {
    //These elements are used to display the cards played in the current trick when the cards are displayed
    //in hand diagram mode rather than picture of cards.
    //An undo can change the cards played so far to the entent that you can keep going back one trick at a time.
    //The other problem to consider is that if you have to restart the browser during the play all state will have been lost 
    //so you need to pick up.
    
    var lastCard;
    var cardPlayed;
    var cardDisplayed = [];
    var playedCards = [];

    var blank = true;
    var el;
    var firstPlayedCardIdx = 0;
    var firstPlayedCard;

    //scan the played tricks to determine the state of play - there are 4 elements in the centre of the table for the
    //cards played in a trick
    //the seat elements are in the order S, W, N and E 

    //in order to determine the first card played find the first card after the slot that is blank (not played)
    //if all 4 cards have been played then a problem so get the first card played on the assumption that 4 have
    //been played just in case it is required (trick counters incremented on the 4th card so need to get the
    //card from the previous trick  
    var trick = trickIndexSet(4);     //determine trick if 4 cards played
    if (m_boardTrick[trick]) firstPlayedCard = m_boardTrick[trick][0];
    blank = true;  
    var cardsPlayed = 0;
    var card, prevFirstCardIdx;
    for (let i = 0; i < 4; i++) {
        el = m_handDiagramEls[i];
        if (el.style.display != "none" && el.innerText != ""){
            card = parseCard(el.innerText);
            cardDisplayed[i] = card;
            if (compareCards(card, firstPlayedCard)) prevFirstCardIdx = i;
            if (blank) firstPlayedCardIdx = i;
            blank = false;
            cardsPlayed++;
        }
        else blank = true;  //see if a subsequent card is not blank and therefore the first played in this trick
    };

    if (cardsPlayed == 4){
        firstPlayedCardIdx = (prevFirstCardIdx ? prevFirstCardIdx : 0);
    } 

    //copy into played sequence
    var id;
    for (let i = 0; i < cardsPlayed; i++) {
        id = (firstPlayedCardIdx + i) % 4;
        cardPlayed = cardDisplayed[id];
        lastCard = {seat: SeatOrder[id], card: cardPlayed.card, suit: cardPlayed.suit};
        playedCards[i] = lastCard;       
    }

    DOMProcessPlayedCards(playedCards);

}

function DOMPlayingSurfaceChangex(mutations) {
    //Table cloth on which cards are played. Only interested in played cards which have z-index from 90 (first played) to
    //93. There are more than one mutations triggers for the same card so only process the first.
    var text = "?";
    var cardPlayed;
    var cardPlayedIndex;
    if (typeof DOMPlayingSurfaceChange.count == "undefined") DOMPlayingSurfaceChange.count = 0; else DOMPlayingSurfaceChange.count++;

    var lastLog = -1;
    for (let i = 0; i < mutations.length; i++) {
        const el = mutations[i].target;
        //Only interested in the played cards and also get a few hits for the same card
        var zIndex = el.style.zIndex;
        if (zIndex >= 90 && zIndex <= 93 && el.style.display != "none" && lastLog != zIndex){
            lastLog = zIndex;
            cardPlayedIndex = zIndex - 90;
            text = el.innerText.substr(el.innerText.length / 2);
            text = text.replace(/\n/g, "");
            cardPlayed = parseCard(text);

            var ptrs = parseInt(m_ourTrickCntEl.innerText);
            var opps = parseInt(m_oppsTrickCntEl.innerText);
            var trick = (ptrs + opps + 1);
            consolelog("Call:" + DOMPlayingSurfaceChange.count + " Card:" + cardPlayed.card + cardPlayed.suit + ", Est Trick:" + 
                        trick + "-" + (cardPlayedIndex + 1));
        };
    }
};


function DOMPlayingSurfaceChange(mutations) {
    //Table cloth on which cards are played. Only interested in played cards which have z-index from 90 (first played) to
    //93. There are more than one mutations triggers for the same card so only process the first.
    //A played card has a z-index of 90 (1st card in the trick) to 93 (last card in the trick). The function is called
    //when a card is played but it is called multiple times for the same card (2 to 3 times).
    //The trick counters are incremented between the 1st call for the 3rd card and either a subsequent call for the 3rd card or
    //just prior to the 4th card being reported as played.
    //When there is an UNDO the current cards just disappear and there is a single call to this function for the rolled-back
    //cards to be displayed. If you undo the first card in a trick you'll see all 4 of the cards in the previous trick.
    //The rolled-back cards may be in any sequence so the z-index must be used to determine the sequence. 
    //The trick counters is wrong if the roll-back shows 4 cards (i.e. it is displaying the result after the cards
    //have been played. If rolled-back to fewer than 4 cards the trick counters are correct.

    var lastCard;
    var text = "?";
    var cardsPlayed = 0;
    var cardPlayed;
    var cardPlayedIndex;
    var seat;
    var index = 0;
    var playedCards = [];
    if (typeof DOMPlayingSurfaceChange.count == "undefined") DOMPlayingSurfaceChange.count = 0; else DOMPlayingSurfaceChange.count++;

    var lastLog = -1;
    for (let i = 0; i < mutations.length; i++) {
        const el = mutations[i].target;
        //Only interested in the played cards and also get a few hits for the same card
        var zIndex = el.style.zIndex;
        if (zIndex >= 90 && zIndex <= 93 && el.style.display != "none" && lastLog != zIndex){
            lastLog = zIndex;
            cardPlayedIndex = zIndex - 90;
            text = el.innerText.substr(el.innerText.length / 2);
            text = text.replace(/\n/g, "");
            cardPlayed = parseCard(text);
            //check if the card already played
            if (m_boardTrick[m_currentTrick] && compareCards(cardPlayed, m_boardTrick[m_currentTrick][cardPlayedIndex])) continue;  //skip this since previously processed
            if(cardPlayedIndex == 0) m_trickFirstCard = cardPlayed;  //required by hand diagram processing
            index = getCardindex(cardPlayed.card, cardPlayed.suit);
            //get seat based on centre co-ord of the card and your own seat
            var cX = el.offsetLeft + (el.offsetWidth / 2);
            var cY = el.offsetTop + (el.offsetHeight / 2);
            //seat = getPlayingCardSeat(cX, cY, m_ownSeat);
            if (m_cardPack[index] && m_cardPack[index].seat) seat = m_cardPack[index].seat;
            else{
                consolelog("Card undefined:" + text);
                seat = "S";
            };
            lastCard = {seat: seat, card: cardPlayed.card, suit: cardPlayed.suit};
            playedCards[cardPlayedIndex] = lastCard;
            cardsPlayed++;
            consolelog("Event:" + DOMPlayingSurfaceChange.count + ", i:" + i + ", Card:" + lastCard.seat + "=" + lastCard.card + lastCard.suit +
                "loc:" + cX + "-" + cY + ",trans:" + el.style.display.transition);
            //logCardLocation(i, el, lastCard);
        }
    };

    if (cardsPlayed == 0) return;
    DOMProcessPlayedCards(playedCards);

};

function checkTricks(trick){
    var length = m_boardTrick[trick].length;   
    var text;
    var cont = true;

    for (let i = 0; i <= trick && cont; i++) {
        const t = m_boardTrick[i];
        text = (i + 1) + " "; 
        if (t){
            for (let c = 0; c < 4 && cont; c++) {
                const card = t[c];
                if (i != trick || c < length){
                    if (card == undefined){
                        text += "ERROR";
                        cont = false;
                        debugger;
                        checkTricksReset(trick);            
                    }
                    else text += card.suit + card.card + " ";
                }
            }
        }
        else {
            text += "ERROR Trick";
            cont = false;
            debugger;
            checkTricksReset(trick);            
        }       
    }
    consolelog("Latest trick:" + text);

}

//error detected so tidy up so won't be detected again
function checkTricksReset(trick){
    var length = m_boardTrick[trick].length;   
    var text;
    var cont = true;

    for (let i = 0; i <= trick && cont; i++) {
        const t = m_boardTrick[i];
        text = (i + 1) + " "; 
        if (!t) {
            m_boardTrick[i] = [];
            for (let x = 0; x < 4; x++) {
                m_boardTrick[i][x] = {seat: "X", card: x, suit: "S"};
            }
        }
        else{
            for (let c = 0; c < 4 && cont; c++) {
                if (i != trick || c < length){
                    t[c] = {seat: "Y", card: 0, suit: "H"};
                }
            }
        }
    }
}

function logPlayedCards(playedCards){
    var ptrs = parseInt(m_ourTrickCntEl.innerText);
    var opps = parseInt(m_oppsTrickCntEl.innerText);
    var trickCalc = (ptrs + opps + 1);
    var text = "PlayedCards: ";
    for (let i = 0; i < playedCards.length; i++) {
        const c = playedCards[i];
        if (c) text += c.card + c.suit + " ";
        else text += "ND ";

    }
    if (playedCards.length >= 4)
        consolelog(text + ", Trick:" + trickCalc + ", CalcTrick:" + (m_currentTrick + 1));       
}


//trick is the current trick
//playedCards is an array with may just have the elements for the newly played cards populated or all played so far.
//The new cards will be in the index appropriated to the played sequence (e.g. [1] is the 2nd played card and [0]
//could be empty if previously processed)
//trick is the number of the trick still being processed 
//playedCards is a list of the card objects displayed so far in the current trick. Object has properties: seat, suit, card.
function DOMProcessPlayedCards(playedCards) {
    var cardsPlayed = playedCards.length;
    if (cardsPlayed == 0) return;

    var trick = trickIndexSet(cardsPlayed, playedCards);
    var firstNewCard = -1;
    //discard previously reported cards
    for (let i = 0; i < playedCards.length; i++) {
        const c = playedCards[i];
        if (c){
            if(m_boardTrick[trick] && compareCards(c, m_boardTrick[trick][i])) playedCards[i] = null;
            else {
                firstNewCard = i;
                break;
            } 
        };
    }

    if (firstNewCard == -1){
        //this should only happen when there has been an undo so reset the
        trickBoardReset(trick, cardsPlayed);
        return;
    };


    DOMProcessPlayedCardsFn(playedCards, firstNewCard, trick);
    //logPlayedCards(playedCards);
    //checkTricks(trick);
}

function DOMProcessPlayedCardsFn(playedCards, firstNewCard, trick) {
    var cardsPlayed = playedCards.length;

    if (m_boardTrick[trick] && firstNewCard <= m_boardTrick[trick].length) {
        //must have been an undo so deleted cards from the first new one 
        trickBoardReset(trick, firstNewCard);
    };


    //if got here copy the new cards (usually just one but more if lost comms or something) to the board
    if (!m_boardTrick[trick]) m_boardTrick[trick] = [];
    for (let i = firstNewCard; i < cardsPlayed; i++) {
        m_boardTrick[trick][i] = playedCards[i];
        speakPlayedCard(playedCards[i], m_boardTrick[trick][0], i == 0);
        m_lastPlayedCard = playedCards[i];
    }
}

function donaldIssue(level, suit) {
    //Donald can click on the wrong suit even though he thinks it's the correct suit due to ?????
    var suitIndex = SuitIndex[suit];
    if (suitIndex < 0) return false; //don't check no trump contracts
    var longSuit = m_hand.longestSuit;  //highest ranking longest suit
    if (longSuit == suitIndex) return false;

    var longLen = m_hand.suits[longSuit].length;
    var suitLen = m_hand.suits[suitIndex].length;

    //should open the longest suit unless it's spades and you have 4 spades and 4 hearts in which
    if (longLen == 4 && suitLen == longLen) return false;

    //user is bidding a short suit so might be a conventional bid (Benji) or not strong enough to bid a
    //lower ranking suit at a higher level. Could also be a cue bid of an opponent's suit.
    //Could also be a mistake
    return true;
}

//top level notifications such as an invitation to join a game
function DOMRootNotificationChange(mutations) {
    //pop-up that indicates if something was rejected or accepted
    var node;
    
    if (!m_params.sayRequests) return;

    var addedNodes = 0;
    var popupFnd = false;
    for (let mut = 0; mut < mutations.length && !popupFnd; mut++) {
        const list = mutations[mut].addedNodes;
        var newNodes = list.length;
        for (let i = 0; i < newNodes && !popupFnd; i++) {
            node = list[i];
            if (node.nodeType == 1){  
                if (node.className == "modal-container"){  
                    addedNodes++;
                    node = node.querySelector("div.headingClass");
                    if (node){
                        var text = node.innerText.trim();
                        consolelog("Notification Fnd, muts:" + mutations.length + ", addedNodes:" + newNodes + ", text:" + text);
                        if (text != ""){
                            speakText("Pop-up. " + text, SpeakTopLevelPopup);
                            popupFnd = true;
                        };    
                    }
                }
            }
        }
    }
    consolelog("RootNotification:" + mutations.length + ", Total Added:" + addedNodes);

}


//the style for a side tab has change. Update it's width
function DOMSideTabChange(mutations) {
    var width = m_monitorSideTabEl.style.width;
    if (width != m_monitorSideTabWidth){
        m_monitorSideTabWidth = width;
        if (m_monitorSideTabWidth && m_selfAlertEl) m_selfAlertEl.style.width = m_monitorSideTabWidth;
    };
}


//detect if a playing table is displayed or has been removed
//also detect if the CHAT nodes have been created
function DOMTableRootChanges(mutations) {
    //must always be a childlist but just be safe
    var mutation = mutations[0];
    if (mutation.type == "childList"){
        //should only be either adding or removing but handle both
        if ((mutation.removedNodes.length > 0) && m_boardNumberCreated){
            if (CheckTableRemoved(m_tableRootEl)){
                //table has been removed
                m_boardNumberCreated = false;
                monitorTableRoot(m_tableRootEl);
            };
        };
        if ((mutation.addedNodes.length > 0) && !m_boardNumberCreated ){
            //the card table may have been added so should monitor boards
            if (CheckBoardNumberCreated(m_tableRootEl)){
                //change monitoring to just removal
                monitorTableRemoval(m_tableRootEl);    
            };
        }
    };
    //check if the chat and microphone are already displayed; otherwise create
    var chatRoot = document.querySelector(".chatDivClass");
    var node = chatRoot.querySelector(".chatRowClass");
    if (node && !node.querySelector("#chatMicrophone")) {
        var btnEl = node.querySelector("button.sendButtonClass");
        var inputEl = node.querySelector("input");
        if (btnEl && inputEl) {
            node = micButtonCreate("chatMicrophone", btnEl, btnEl.style.height, btnEl.style.top);
            if (node){
                m_chatMic = new SpeechToText(inputEl, node, chrome.runtime.getURL('images/micOff.png'),
                    chrome.runtime.getURL('images/micPulse.gif'), chrome.runtime.getURL('images/micError.png'), 
                    speechEntryCallback, btnEl);
            }
        }
        //also monitor for chat messages
        monitorChat(chatRoot);
    }
}


function getBtnId(btn){
    for (let i = 0; i < biddingBtns.length; i++) {
        if (btn == biddingBtns[i].text) return i;        
    };
    return -1;
}


function getNodeDetails(el){
    var id;
    var cls;
    var type;
    id = el.id;
    cls = el.className;
    type = el.nodeName;
    return "(" + id + ")" + type + "." + cls;
}

//determine the seat base on which is the seat at the bottom of the screen and the centre co-ords of the card
function getPlayingCardSeat(x, y, bottomSeat){
    const SeatId = {S: 0, W: 1, N: 2, E: 3};
    const SeatBase = ["S", "W", "N", "E", "S", "W", "N"];
    var base = SeatId[bottomSeat];
    if (base == undefined) return "S";

    var sX = m_playingSurfaceEl.offsetWidth / 2;
    var sY = m_playingSurfaceEl.offsetHeight * 0.547;
    if (x >= sX){
        return (y >= sY ? SeatBase[base] : SeatBase[base + 3]);
    }
    else return (y >= sY ? SeatBase[base + 1] : SeatBase[base + 2]);
}

//return the number of remaining cards in the specified suit
function getRemainingCards(handDiagram, suit){
    let cnt = 0;
    let cardsText = "";
    let suitPanels = handDiagram.querySelectorAll(".suitPanelClass");
    let suitCards = suitPanels[SuitSymbolIndex[suit]];
    let cards = suitCards.querySelectorAll(".handDiagramCardClass");
    for (let i = 0; i < cards.length; i++) {
        const el = cards[i];
        cnt++;
        cardsText += " " + CardText[el.innerText];
    }
    return {cards: cnt, cardsText: cardsText};
}

function initDeck(){
    //initialise the prarameters for recording each trick on the board
    var cnt = 0;
    for (let s = 0; s < Suits.length; s++) {
        const suit = Suits[s];
        for (let i = 0; i < 13; i++) {
            m_deck[cnt] = {card: Cards[i] + Suits[s], display: "", left: "", top: "", zIndex: 0};
            cnt++;
        }       
    }

    trickBoardClear();
    //for (let i = 0; i < 13; i++) {
    //    m_boardTrick[i] = []];
    //}
}

//determine if the latest bid is a jump
function isJumpBid(thisBid, prevbid){
}

function lctSuitCnt(suit) {
    const hons = ["A", "K", "Q"];
    var losers = 0;
    var cards = Math.min(suit.length, 3);
    var j = 0;
    for (let i = 0; i < cards; i++) {
        const hon = hons[i];
        if (suit[j] == hon) j++;
        else losers++;
    }
    //special case of an unsupport queen
    if (losers == 2 && cards == 3 && suit[0] == "Q" && suit[1] != "J") losers += 0.5;
    return losers;
}

function logCardLocation(i, el, lastCard){
    var sX = m_playingSurfaceEl.offsetWidth / 2;
    var sY = m_playingSurfaceEl.offsetHeight * 0.547;
    var cT = el.offsetTop;
    var cL = el.offsetLeft;
    var cW = el.offsetWidth;
    var cH = el.offsetHeight;
    var cB = cT + cH;
    var cR = cL + cW;
    var cX = cL + (cW / 2);
    var cY = cT + (cH / 2);

    consolelog("Surface Centre x:" + sX + ", y:" + sY + ", width:" + m_playingSurfaceEl.offsetWidth + ",height:" + m_playingSurfaceEl.offsetHeight);
    consolelog("i:" + i + ", Card:" + lastCard.seat + "=" + lastCard.card + lastCard.suit + 
        ",cX:" + cX + ",cY:" + cY +
        ", top:" + cT + ", bottom:" + cB +", left:" + cL + ", right:" + cR + ", width:" + cW + ",height:" + cH);
    consolelog("Seat:" + getPlayingCardSeat(cX, cY, m_ownSeat) + ", diff: pX:" + (cX - sX) + ", pY:" + (sY - cY) + ", top:" + (sY - cT) + ", bottom:" + (cB - sY) + ", left:" + (sX - cL) + ", right:" + (cR - sX));
}


//create the microphone just before the specified button
function micButtonCreate(id, btnEl){
    var height = btnEl.style.height || "28px";;
    var x = document.createElement("IMG");
    var img = chrome.runtime.getURL("images/micOff.png");
    x.setAttribute("id", id);
    x.setAttribute("src", img);
    x.setAttribute("alt", "Mic");
    x.style.height = height;
    x.style.width = height;
    x.style.marginTop = btnEl.style.top;
    btnEl.parentElement.insertBefore(x, btnEl);
    return x;
}

function micInputCreate(id, input) {
    var height = input.offsetHeight;
    if (height < 28) height = 28;
    var img = document.createElement("IMG");
    var src = chrome.runtime.getURL("images/micOff.png");
    img.setAttribute("id", id);
    img.setAttribute("src", src);
    img.setAttribute("alt", "Mic");
    img.style.height = height + "px";
    img.style.width = height + "px";

    DOMInsertAfter(img, input);
    input.style.width = "85%";
    return img;
}


function monitorAnnouncement(root){
    //monitor the board number
    let options = {
        attributes: true,
        attributeFilter: ['style']
    };

    var el = root.querySelector("div.announcementPanelClass");
    m_announcementObs.disconnect();
    m_announcementObs.observe(el, options);
}

//monitor a new bid being displayed in the auction box
function monitorAuctionBox(root){
    let options = {
        attributes: true,
        attributeFilter: ['style']
    };

    //the node for the auction box that contains the headers and bids.
    //This is displayed at the start of a new board 
    m_auctionBoxEl = root.querySelector(".auctionBoxClass");
    m_auctionBoxObs.observe(m_auctionBoxEl, options);

    //the node in which new bid nodes are created
    m_auctionBoxBidsEl = m_auctionBoxEl.querySelector(".auctionClass");
    m_auctionBoxBidsObs.disconnect();
    options = {childList: true};    
    m_auctionBoxBidsObs.observe(m_auctionBoxBidsEl, options);
}

function monitorAuctionContractPanel(){
    let options = {
        attributes: true,
        attributeFilter: ['style']
    };

    m_auctionContractPanelObs.observe(m_tricksPanelEl, options);
};

function monitorBiddingBox(root){
    //monitor the board number
    let options = {
        attributes: true,
        attributeFilter: ['style']
    };

    m_biddingBoxEl = root.querySelector(".biddingBoxClass");
    //monitor biddingBoxDiv.style.display = "none" when hidden or "inline-block" when displayed
    m_biddinBoxObs.disconnect();
    m_biddinBoxObs.observe(m_biddingBoxEl, options);
}

function monitorBidExplanation(root){
    //monitor the pop-up that explains another player's bid
    let options = {
        //attributes: true,
        //attributeFilter: ['style'],
        childList: true,
        characterData: true,
        subtree: true
    };

    m_bidExplanationEl = root.querySelector(".callExplanationClass");
    m_bidExplanationObs.disconnect();
    m_bidExplanationObs.observe(m_bidExplanationEl, options);
}

function monitorBoard(boardNumberEl){
    //monitor the various elements for the board/table
    monitorSideTab();
    monitorBoardNumber(boardNumberEl);
    monitorBoardEndPanel(m_tableRootEl);
    monitorAuctionBox(m_tableRootEl);
    monitorAuctionContractPanel();
    monitorPlayingSurface(m_tableRootEl);
    monitorBiddingBox(m_tableRootEl);
    monitorBidExplanation(m_tableRootEl);
    monitorExplainBid(m_tableRootEl);
    monitorAnnouncement(m_tableRootEl);
    monitorBoardNotifications(m_tableRootEl);
    selfAlertCreate();      //create the self alert tab/display
}

//monitor the panel that displays the result of the board
function monitorBoardEndPanel(root){
    let options = {
        characterData: true,
        subtree: true,
        characterDataOldValue: false
    };

    m_boardEndPanelEl = root.querySelector(".dealEndPanelClass");
    m_boardEndPanelObs.observe(m_boardEndPanelEl, options);
}

//monitor the various pop-ups within the game: 
//The pop-up that tells you if claims or undos have been accepted/rejected
//the element is a div that has no children when it is not displayed
function monitorBoardNotifications(root){
    let options = {
        childList: true
    };

    var el = root.querySelector("div.notificationDivClass");
    m_boardNotificationMsgObs.disconnect();
    m_boardNotificationMsgObs.observe(el, options);
}

function monitorBoardNumber(el){
    //monitor the board number
    let options = {
        childList: false,
        attributes: false,
        characterData: true,
        subtree: true,
        //attributeFilter: ['one', 'two'],
        attributeOldValue: false,
        characterDataOldValue: false
    };
    
    m_boardNumberObs.disconnect();
    m_boardNumberObs.observe(el, options);
    m_boardNumberCreated = true;
}

function monitorChat(el){
    //monitor the chat message area
    let options = {
        childList: true,
        subtree: true
    };
    
    m_chatMessagesEl = el.querySelector(".chatOutputClass");
    m_chatMessagesObs.observe(m_chatMessagesEl, options);
}

function monitorExplainBid(root){
    //monitor the request to explain one of your bids
    let options = {
        childList: true,
        attributes: true,
        characterData: true,
        subtree: true,
        attributeFilter: ['style'],
        attributeOldValue: false,
        characterDataOldValue: false
    };

    m_explainBidEl = root.querySelector(".explainCallClass");
    var node = m_explainBidEl.querySelector("#explainMicrophone");
    if (!node) {
        var inputEl = m_explainBidEl.querySelector("input");
        var btnEl = m_explainBidEl.querySelector("button");
        var micEl = micButtonCreate("explainMicrophone", btnEl);
        m_explainMic = new SpeechToText(inputEl, micEl, chrome.runtime.getURL('images/micOff.png'),
            chrome.runtime.getURL('images/micPulse.gif'), chrome.runtime.getURL('images/micError.png'), speechEntryCallback, btnEl,
            clickExplainRequestOKBtn);
    }

    m_explainBidObs.disconnect();
    m_explainBidObs.observe(m_explainBidEl, options);
}


//monitor the cards as they are played during a board
function monitorPlayingSurface(root){
    let cardOptions = {
        childList: true,
        attributes: true,
        subtree: true,
        attributeOldValue: true,
        attributeFilter: ['style']
    };

    //need character data since the first card in the next trick just replaces the card that was
    //played by the winner of the previous trick. Problem then is that you get mutations at a lower level
    let trickOptions = {
        //childList: true,
        //characterData: true,
        attributes: true,
        subtree: true,
        //attributeOldValue: true,
        attributeFilter: ['style']
    };

    m_playingSurfaceEl = root.querySelector("div.cardSurfaceClass");
    m_playingSurfaceObs.observe(m_playingSurfaceEl, cardOptions);

    m_handDiagramEls = root.querySelectorAll("div.handDiagramCurrentTrickClass");
    for (let i = 0; i < 4; i++) {
        m_handDiagramObs.observe(m_handDiagramEls[i], trickOptions);        
    }
}

//top level pop-ups such as an invitation to join a game
function monitorRootNotifications(root){
    let options = {
        //subtree: true,
        childList: true
    };

    m_everythingEl = root.querySelector("#bbo_everything");
    //monitor this node for pop-up messages
    m_rootNotificationMsgObs.observe(m_everythingEl, options);
}

//Monitor one of the side tabs in order to detect if it changes size in which case the size of the
//self alert tab will need to be changed
function monitorSideTab(){
    let options = {
        attributes: true,
        attributeFilter: ["style"]
    };

    var screenParent = document.querySelector(".mainDivClass");
    var screens = screenParent.querySelectorAll("screen");
    m_monitorSideTabEl = screens[0];
    m_monitorSideTabWidth = m_monitorSideTabEl.style.width;

    m_monitorSideTabObs.disconnect();
    m_monitorSideTabObs.observe(m_monitorSideTabEl, options);
}



//Detect when a bridge table is added or removed from its parent element
function monitorTableRoot(el){
    let options = {
        childList: true,
        subtree: true
    };
    m_boardNumberObs.disconnect();
    m_tableRootObs.disconnect();
    m_tableRootObs.observe(el, options);
}

function monitorTableRemoval(el){
    //just monitor the node and not the sub-nodes
    let options = {
        childList: true
    };
    m_tableRootObs.disconnect();
    m_tableRootObs.observe(el, options);
}

//has the playing surface dims changed?
function playingSurfaceResized(){
    if (m_tableRootEl){
        var sX = m_tableRootEl.offsetWidth;
        var sY = m_tableRootEl.offsetHeight;
        if (m_playingSurface.X == sX && m_playingSurface.Y == sY) return false;
        m_playingSurface = {X: sX, Y: sY};
        return true;
    }
}


function buildLinStr(boardEl, boardNum, checkHand){

    //The dealer pattern based on board number; index by [(board-1) % 4]
    var dealerPattern = "NESW";
    var dealerPatternId = "3412";
    //Defines the vulnerability based on the board number; index by [(board-1) % 16]
    var vulnerabilityPattern = ["None", "NS", "EW", "All", "NS", "EW", "All", "None","EW", "All", "None", "NS", "All", "None", "NS", "EW"];
    var vulnerabilityId = ["0", "n", "e", "b", "n", "e", "b", "0","e", "b", "0", "n", "b", "0", "n", "e"];

    var seatInfo = getSeats(boardEl);
    var names = seatInfo.players;
    var pn = "pn|" + names[0] + "," + names[1] + "," + names[2] + "," + names[3] + "|";

    var md = "md|" + dealerPatternId[(boardNum - 1) % 4];
    md += getSeatsHandLIN(boardEl) + "|";

    var ah = "ah|Board " + boardNum + "|";
    var sv = "sv|" + vulnerabilityId[(boardNum - 1) % 16] + "|";
    //is the board the one we have details for?
    var bidTricks = "";
    if (boardNum <= m_boardsLog.length && m_boardsLog[boardNum - 1]){
        //only check that the src and stored hands match if from a different source
        if(checkHand){
            if (m_boardDetails[boardNum - 1]){
                var srcHand = getSeatHandLINBySeat(boardEl, m_boardDetails[boardNum - 1].ownSeat);
                if(m_boardDetails[boardNum - 1].ownHand == srcHand){
                    bidTricks = getBidsLIN(boardNum) + getTricksLIN(boardNum);               
                }
            } 
        }
        else bidTricks = getBidsLIN(boardNum) + getTricksLIN(boardNum); 
    };

    return pn + "st||" + md + "rh||" + ah + sv + bidTricks;
}

function getBidsLIN(boardNum){
    const convert = {
        "Pass": "p",
        "Dbl": "d",
        "Rdbl": "r",
        "♠": "S", 
        "♥": "H", 
        "♦": "D", 
        "♣": "C", 
        "NT": "N"
    };
        
    var str = "";
    var bidText;
    var lin, level, suit;
    var boardInfo = m_boardsLog[boardNum - 1];
    if (boardInfo){
        var bids = boardInfo.bids;
        for (let i = 0; i < bids.length; i++) {
            const bid = bids[i];
            bidText = bid.text;
            lin = convert[bidText];
            if (!lin){
                level = bidText.substr(0, 1);
                suit = bidText.substr(1);
                lin = level + convert[suit];

            }
            str += "mb|" + lin + (bid.alerted ? "!" : "") + (bid.explanation ? "|an|" + bid.explanation : "") + "|";
        }
    }
    return str;
}

//return a string for the hand in the specified seat
function getSeatHandLINBySeat(boardEl, seat){
    var seats = boardEl.querySelectorAll(".handDiagramPanelClass");
    return getSeatHandLIN(seats[SeatIndex[seat]]);
}

function getSeatHandLIN(seatEl){
    //each seat has 4 suitPanels (one for each suit) and each suit panel has a handDiagramCardClass for each card is the suit
    //the suits are listed in the order clubs, diamonds, hearts and then spades.
    const suitName = ["C", "D", "H", "S"];
    var suitPanels = seatEl.querySelectorAll(".suitPanelClass");
    var hand = "";
    for (let s = 3; s >= 0; s--)
    {
        var suitCards = suitPanels[s].querySelectorAll("div.handDiagramCardClass");
        hand += suitName[s];
        var card;        
        for (let j = 0; j < suitCards.length; j++)
        {
            card = suitCards[j].innerText.trim();
            card = card.replace("10","T");
            hand += card;
        }
    }
    return hand;
};

//returns an array of the seats in the sequence S, W, N and E, also indicates the index of the player
//at the top and bottom of the board
//A robot is named "Robot <S>" where <s> is it's seat position
function getSeats(container){
    var seat, name;
    var bottomIdx, topIdx;  //top and bottome seats
    var lowest = -1;        //top the screen is 0
    var highest = 100000;   //bottom of the screen is a high offset
    var playerNames = [];
    var playerSeat = {};
    var seats = container.querySelectorAll(".nameBarDivClass");      
    for (let i = 0; i < 4; i++) {
        const el = seats[i];
        seat = seats[i].querySelector("div.directionClass").innerText;
        name = seats[i].querySelector("div.nameDisplayClass").innerText;
        if (name == "Robot") name = "Robot " + seat;    //need to make robot a unique name
        playerNames[i] = name;
        playerSeat[name] = Seats[seat];

        //if playing the board your hand is at the bottom and partner is at the top
        //the top of the screen is 0 and increases as you move down the screen
        if (el.offsetTop){
            if (el.offsetTop > lowest){
                lowest = el.offsetTop;
                bottomIdx = i;
            };
            if (el.offsetTop < highest){
                highest = el.offsetTop;
                topIdx = i;
            };
        };           
    }
    return {players: playerNames, bottomIdx: bottomIdx, topIdx: topIdx, playerSeat: playerSeat};
}

function getSeatsHandLIN(boardEl){
    var seats = boardEl.querySelectorAll(".handDiagramPanelClass");
    var md = "";
    for (let s = 0; s < 3; s++) {
        const el = seats[s];
        md += getSeatHandLIN(el) + ","       
    }
    return md;
}

function getTricksLIN(boardNum){
    const convert = {
        "♠": "S", 
        "♥": "H", 
        "♦": "D", 
        "♣": "C" 
    };
    
    
    var str = "";
    var cardCnt = 0;
    var boardInfo =  m_boardsLog[boardNum - 1];
    if (boardInfo){
        var tricks = boardInfo.tricks;
        for (let i = 0; i < tricks.length && tricks[i].length != 0; i++) {
            str += "pg||";
            const trick = tricks[i];
            if (trick){
                for (let j = 0; j < trick.length; j++) {
                    const t = trick[j];
                    if (t){
                        var card = trick[j].card;
                        if (card == 10) card = "T";
                        str += "pc|" + convert[trick[j].suit] + card + "|";      //check format of cards and the "ten"
                        cardCnt++;    
                    }
                    else{
                        consolelog("Missed played card, trickIdx:" + i + ", cardIdx:" + j);
                        break;
                    }
                }
            }
        }

        if (cardCnt % 4 == 0){
            //full tricks completed so need to start the final trick
            str += "pg||";
        }
        //add a claim if board not played out and the claim was captured 
        if (cardCnt != 52 && boardInfo.contractTricks > 0) str += "mc|" + boardInfo.contractTricks + "|";
    }
    return str;
}

//Examples of contract bid "5D", "7NT", "7NTx", 7Nxx"
function parseContract(text){
    var suitText;
    var dbl = "";
    text = text.trim();
    var len = text.length;
    //was the contract
    if (text.charAt(len - 1) == "x"){
        if (text.charAt(len - 2) == "x"){
            dbl = " re doubled";
            text = text.substr(0, len - 2);
        }
        else{
            dbl = " doubled";
            text = text.substr(0, len - 1);
        }
        
    };
    var bid = saySuitBid(text.charAt(0), text.substr(1));
    return {bid: bid, double: dbl};
}


function readHandDetails()
{
    //the order in which the suitPanelClass elements are created. The order is S-C (south-clubs), S-D, S-H, S-S and the
    //same seq for West, north and then East. The order array sorts the results by N-S, N-H, N-D, N-C followed by West, east and south.
    var order = [11,10,9,8,7,6,5,4,15,14,13,12,3,2,1,0];
    const SuitOrder = [
        {seat: "S", suit: "♣"}, {seat: "S", suit: "♦"}, {seat: "S", suit: "♥"}, {seat: "S", suit: "♠"}, 
        {seat: "W", suit: "♣"}, {seat: "W", suit: "♦"}, {seat: "W", suit: "♥"}, {seat: "W", suit: "♠"}, 
        {seat: "N", suit: "♣"}, {seat: "N", suit: "♦"}, {seat: "N", suit: "♥"}, {seat: "N", suit: "♠"}, 
        {seat: "E", suit: "♣"}, {seat: "E", suit: "♦"}, {seat: "E", suit: "♥"}, {seat: "E", suit: "♠"} 
    ];
    var suitPanels;
    var suitString = new Array();
    var loadedCards = 0;
    var loadedCard = [];

    var container = document.getElementsByTagName(m_currentTable.table)[0];
    //one seat per player
    var seats = container.querySelectorAll(m_currentTable.seats);      
    var text;
    //allocate the cards to the seats
    suitPanels = container.querySelectorAll(".suitPanelClass");
    for (let s = 0; s < suitPanels.length; s++){
        //each suitPanels has a handDiagramCardClass for each card in that suit
        var cards = suitPanels[s].querySelectorAll("div.handDiagramCardClass");
        var card, index;
        var seat = SuitOrder[s].seat;
        var suit = SuitOrder[s].suit; 
        text = "Seat/Suit:" + seat + suit + " ";
        for (let j = 0; j < cards.length; j++){
            card = cards[j].innerText.replace(/\n| /g, "");
            if (card != ""){
                text += card.replace("10", "T");
                index = getCardindex(card, suit);
                loadedCard[index] = {card: card, suit: suit, seat: seat};
                loadedCards++;
            }
            else text += "?";
        }
    };

    consolelog("Board:" + m_board + ", Loaded cards:" + loadedCards);
    if (loadedCards == 52 || m_cardPack.length == 0) m_cardPack = loadedCard;

    //find the hand at the bottom of the screen and the top (top pixel is 0 and bottom is the screen height)
    var yourHandId = -1;
    var partnerHandId = -1;
    var seat, name;

    var seatResult = getSeats(container);
    m_playersSeat = seatResult.playerSeat;
    yourHandId = seatResult.bottomIdx;
    partnerHandId = seatResult.topIdx;
    m_ownName = seats[yourHandId].querySelector("div.nameDisplayClass").innerText;
    //check you're playing rather than observing a game
    if (m_ownName == m_userName){
        m_ownSeat = seats[yourHandId].querySelector("div.directionClass").innerText;
        m_partnerSeat = seats[partnerHandId].querySelector("div.directionClass").innerText;
        m_partnerName = seats[partnerHandId].querySelector("div.nameDisplayClass").innerText;   
    }
    else{
        m_ownName = "";
        m_ownSeat = "";
        m_partnerSeat = "";
        m_partnerName = "";
    }

    //one hand panel per player contains the player's cards by suit
    var hdPanels = container.querySelectorAll(m_currentTable.hands);
    suitPanels = hdPanels[yourHandId].querySelectorAll(".suitPanelClass");

    //panels are in the sequence Clubs, Diamonds, hearts, Spade so reverse it so spades is first
    //also count the number of points (HCP) in the hand
    var suitId = 0;
    var points = {A: 4, K: 3, Q:2, J: 1};
    var pts = 0;
    var suitCards = 0;
    var shortSuits = 0;
    var longestSuit = 0;        //id of the longest highest ranking suit
    var longestSuitCards = 0;   //number of cards in the longest suit
    var minLen = 13;
    var losers = 0;
    var aces = 0;
    var shape = "";

    for (let s = 3; s >= 0; s--)
    {
        var suitCards = suitPanels[s].querySelectorAll("div.handDiagramCardClass");
        var str2 = "";
        var card;        
        for (let j = 0; j < suitCards.length; j++)
        {
            card = suitCards[j].innerText;
            card = card.replace("10","T");
            card = (card.charAt(0) == " " ? card.charAt(1) : card.charAt(0));
            pts += (points[card] ? points[card] : 0);
            str2 = str2 + card;
        }
        suitString[suitId] = str2;
        suitCards = str2.length;

        if (suitCards > longestSuitCards){
            longestSuit = suitId;
            longestSuitCards = suitCards;
        } 
        if (suitCards <= 2) shortSuits++;
        if (suitCards < minLen) minLen = suitCards;
        shape += suitCards + " ";
        losers += lctSuitCnt(suitString[suitId]);
        if (suitString[suitId][0] == "A") aces++;
        
        suitId++;
    }

    var balanced = (shortSuits <= 1 && minLen >= 2);
    var whole = parseInt(losers);
    var ltc = whole + (losers > whole ? " and a half" : "") + " losers" + (aces == 0 ? ", no aces" : "");
    return {suits: suitString, hcp: pts, yourName: m_ownName, yourSeat: m_ownSeat, ptrName: m_partnerName, ptrSeat: m_partnerSeat,
        longestSuit: longestSuit, shape: shape, ltc: ltc, balanced: balanced};
}

//clear the auction list for the current trick to the specified size (empty if size not specified)
function resetAuctionBids(entries){
    entries = entries || 0;
    m_auctionBids.length = entries;
    m_lastSuitBidIx = -1;
    for (let i = m_auctionBids.length - 1; i >= 0; i--) {
        if (m_auctionBids[i].isLevelBid()) {
            m_lastSuitBidIx = i;
            break;
        }
    }
}


//read out a bid explanation. Node is a callExplanationClass
function sayBidExplanation(node){
    var parts = node.querySelectorAll("div");
    if (parts.length >= 2){
        //first element is the bid and the second is the explanation
        return sayBid(parts[0].innerText) + " explained. " + parts[1].innerText;
    }
    return "";
}

//number of cards in the suit or the shape
function sayCardConfirm(bidBtnId) {
    var suit = bidBtnId.abbrev;
    if (suit == "NT") return sayHandShape(m_hand);

    var suitId = SuitIndex[suit];
    var cards = m_hand.suits[suitId].length;

    if (cards == 0) return "void";
    if (cards == 1) return "singleton";
    return cards + " cards";
}


function selfAlertCreate(){
    //create the parent node for the self alert display
    var screenParent = document.querySelector(".mainDivClass");
    var selfAlert = screenParent.querySelector("BBOAalert");
    if (selfAlert == null){
        selfAlert = document.createElement('BBOAalert');
        selfAlert.style.display = "none";
        //selfAlert.style.minwidth = "600px";
        //selfAlert.style.height = "100%";
        screenParent.appendChild(selfAlert)   
    }
    m_selfAlertEl = selfAlert;
}

//hide the self alert tab and display the previous vertical tab if the alert button not enabled
//and no request for an explaination
function selfAlertClose(){
    if (!m_alertBtnState && !m_bidExplainRequest){
        selfAlertHide();
    }
    else{
        //still one active so display data for it
        if(m_alertBtnState) selfAlertUpdate("current", m_bidLevelBtnId, m_bidSuitBtnId);
        else selfAlertUpdateDisplay("explain", m_bidExplainLevel, m_bidExplainSuit);
    }
}

function selfAlertHide(){
    m_selfAlertEl.style.display = "none";
    if (m_prevSideTabEl != null){
        m_prevSideTabEl.style.display = m_prevSideTabDisplay;
        m_prevSideTabEl = null;
    };
}

function selfAlertShow(){
    if(m_params.alertAssist && m_specialPlayer){
        //hide the current side tab and display the self alert tab ()
        //A side bar may not be visible if it has already been displayed or they are minimised
        var screenParent = document.querySelector(".mainDivClass");
        var screens = screenParent.querySelectorAll("screen");
        for (let i = 0; i < screens.length; i++) {
            const el = screens[i];
            if (el.style.display != "none"){
                m_prevSideTabEl = el;
                m_monitorSideTabWidth = el.style.width;
                m_prevSideTabDisplay = el.style.display;
                el.style.display = "none";
            }
        }
        if (m_monitorSideTabWidth) m_selfAlertEl.style.width = m_monitorSideTabWidth;
        m_selfAlertEl.style.display = "flex";
    };
}

function selfAlertUpdate(source, levelBtnId, suitBtnId){
    //convert bidding box button Ids to a bid
    var level = (levelBtnId >= 0 ? biddingBtns[levelBtnId].text : "");
    var suit = (suitBtnId >= 0 ? biddingBtns[suitBtnId].text : "");
    selfAlertUpdateDisplay(source, level, suit);
}

//populate the self alert data
function selfAlertUpdateDisplay(source, bidlevel, bidSuit){
    if(m_params.alertAssist && (m_alertBtnState || m_bidExplainRequest)){
        if (m_selfAlertEl.style.display == "none") selfAlertShow();

        m_alertTabSource = source;  //either the current bid or an explanation
        var title = (m_alertTabSource == "current" ? "Self Alert" : "Bid Explanation");
        var table = "";
        var style = '<style>table, th, td {padding-left: 10px; padding-right: 10px; border: 1px solid black; ' +
                'border-collapse: collapse; rowspan: 1; font-size: 22px;}'+
                'td:first-child {text-align: center;} tr:hover td{background-color: #ffff99;}​</style>';
        var header = '<h2 style="text-align:center;">' + title + ' (' + m_selfAlertCard.title + ')</h2>';

        if (bidSuit == ""){
            //no filter so user needs to select a bid
            header += '<br><br><br><br><h2 style="text-align:center; width:100%">Select a Bid to View Explanations</h2>';
        }
        else{
            var generic = selfAlertUpdateRows("", "");
            var specific = selfAlertUpdateRows(bidlevel, bidSuit);

            if (generic != ""){
                table = '<table style="width:100%;">' + 
                    '<tr><th>' + 'Generic' + '</th><th>Explanation</th></tr>' +
                    generic + '</table><br>';
            };
            var suitStyle = (bidSuit == "♥" || bidSuit == "♦" ? "style='color:rgb(203, 0, 0);'" : "")
            table += '<table style="width:100%;">' + 
                '<tr><th class="bboaBid"><span>' + bidlevel + '</span><span ' + suitStyle + '>' + bidSuit + '</span>' + 
                '</th><th>Explanation</th></tr>' + specific + '</table>';
                //'<tr><th style="width:15%;">Bid</th><th style="text-align:left; width:85%;">Explanation</th></tr>';
        };
        m_selfAlertEl.innerHTML = '<div style="overflow-y: auto; overflow-x: hidden">' + 
                                style + header + '<div style="overflow-y: auto;">' + table + '</div>' + '</div>';
    };
}

function selfAlertUpdateRows(bidlevel, bidSuit){
    //get the rows for the specified level and suit. 
    var level, bid, brief;
    var data = m_selfAlertCard.bids;
    var html = "";
    var bidFound = false;      //abort when found all bids at specified level (bids are in order)
    for (let i = 0; i < data.length; i++) {
        level = data[i].level;
        bid = data[i].bid;
        brief = data[i].brief;
        if ((level == bidlevel && bid == bidSuit)){
            bidFound = true;
            if (brief == ""){
                //blank spacer
                html += "<tr><th></th><th></th></tr>" + 
                    "<tr><th><br></th><th><br></th></tr>" + 
                    "<tr><th></th><th></th></tr>" 
            }
            else{
                html += "<tr><td id='" + AlertIdStr + "A" + i + "' class='selfAlertBid'>" + brief + 
                "</td><td id='" + AlertIdStr + "B" + i + "' class='selfAlertDesc'>" + data[i].desc + "</td></tr>"     
            }
        }
        else if (bidFound) break; 
    }
    return html;
}

//Enter text into the specified input tag element - this version doesn't enable the OK button associated with the input?
function setInputBoxText1(input, text) {
    input.value = "";
    var ev = new KeyboardEvent("keypress", {
        bubbles: true
    });
    for (let i = 0; i < text.length; i++) {
        input.value += text.charAt(i);
        input.dispatchEvent(ev);
    }
}

//Enter text into the specified input tag element
function setInputBoxText(input, text) {
    input.value = "";
    var ev = new Event('input');
    for (let i = 0; i < text.length; i++) {
        input.value += text.charAt(i);
        input.dispatchEvent(ev);
    }
}

//Send the enter key to the input control
function setInputBoxEnter(input) {
    var keyboardEvent = new Event('keypress', {
        code: 'Enter',
        key: 'Enter',
        charCode: 13,
        keyCode: 13,
        view: window
    });
    //input.dispatchEvent(keyboardEvent);

    var keyEvent = document.createEvent("KeyboardEvent");
    //keyEvent.initKeyEvent("keypress", true, true, null, false, false, false, false, 8, 0);

    //input.dispatchEvent(keyEvent);

}

//Send the enter key to the input control
function setInputBoxEnter1(input) {
    var keyboardEvent = new Event('keypress', {
        code: 'Enter',
        key: 'Enter',
        charCode: 13,
        keyCode: 13,
        view: window
    });
    //input.dispatchEvent(keyboardEvent);

    var keyEvent = document.createEvent("KeyboardEvent");
    //keyEvent.initKeyEvent("keypress", true, true, null, false, false, false, false, 8, 0);

    //input.dispatchEvent(keyEvent);

}

//Enter text into the specified input tag element
function setInputContainerText(container, text) {
    //now find all the bidding buttons and the OK button
    var input = container.querySelector("input");
    if (input) setInputBoxText(input, text);
}

//say the played card if appropriate.
//lastCard is the card just played and firstCard if the first played this trick
//trickStart is true if this is the first card in the trick.
function speakPlayedCard(lastCard, firstCard, trickStart){
    //read out the last card added but might ignore own
    var text;
    if (m_params.sayPlayedCard && lastCard){
        var declarer = m_declarerSeatEl.innerText.charAt(0);
        //speak the card if speak all cards OR your partner is the declarer OR it's not your card or your partner OR
        //it's your partner's card but you're not the declarer
        if (m_params.sayOwnCard || declarer == m_partnerSeat || (lastCard.seat != m_ownSeat && lastCard.seat != m_partnerSeat) ||
                (lastCard.seat == m_partnerSeat && declarer != m_ownSeat)){
            if (trickStart){
                speakText(sayCard(lastCard.card, lastCard.suit), SpeakCardPlayed);
            }
            else {
                //only say the suit if not the one led
                if (firstCard && lastCard.suit == firstCard.suit) text = lastCard.card;
                else text = sayCard(lastCard.card, lastCard.suit);
                speakText(text, SpeakCardPlayed);
            }
        }    
    }
}


//pause or resume speech
function speakPause(state) {
    //chrome.runtime.sendMessage({ op: MsgPauseSpeech, pause: state, time: Date.now()});
}


//report an error
function speakError(text, priority, single) {
    if (m_specialPlayer){
        chrome.runtime.sendMessage({op: MsgSayText, text: text, priority: SpeakInfo, single: false});
    }
}

//read the specified text
//single is true if there should only ever be one of the specified priority at any one time, i.e. cancel any others
function speakText(text, priority, single) {
    if (priority == undefined){
        priority = SpeakLow;
        single = true;
    }
    else{
        single = (single == undefined ? false : single);
    }
    chrome.runtime.sendMessage({op: MsgSayText, text: text, priority: priority, single: single});
}

//tempt function until self alerting editor developed so restrict users
function specialPlayer(player) {
    for (let i = 0; i < m_specialPlayers.length; i++) {
        const element = m_specialPlayers[i];
        if (element == player) return true;
    }
    return false;
}


function speechEntryCallback(micObj, text) {
    setInputBoxText(micObj.inputEl, text);
    if (text != "" && m_params.autoSaySpeech) {
        speakText(text, SpeakRecognitionReadback);
    }
    speakPause(false);
    m_lastMic = micObj;
}

//prepare mic for speech recognition
function speechEntryInit(micObj) {
    setInputBoxText(micObj.inputEl, "");
}


function trickBoardClear() {
    for (let i = 0; i < 13; i++) {
        if (m_boardTrick[i]) m_boardTrick[i].length = 0;
    }
}

//call this function at the start of a board to initialise the trick counter
function trickBoardInit(){
    //may have restarted during a session so counters may not be zero
    var ptrs = parseInt(m_ourTrickCntEl.innerText);
    var opps = parseInt(m_oppsTrickCntEl.innerText);
    m_ourTrickCount = ptrs;
    m_oppsTrickCount = opps;
    trickBoardClear();
    m_tricks.length = 0;
    m_trick.length = 0;
    m_orderedCards.length = 0;
}

function trickBoardReset(trickId, cardsPlayed){
    m_boardTrick[trickId].length = cardsPlayed;

    for (let i = trickId + 1; i < 13; i++) {
        if (m_boardTrick[i]) m_boardTrick[i].length = 0;
    }
}

//the trick won element counters are updated before the 4th played card is displayed to the user (added to DOM) so those elements
//cannot be monitored for changes. Therefore, call this function after every played card to check for an update.
function trickCardPlayed() {
    var ptrs = parseInt(m_ourTrickCntEl.innerText);
    var opps = parseInt(m_oppsTrickCntEl.innerText);

    if (m_ourTrickCount != ptrs || m_oppsTrickCount != opps) {
        //trick counter has changed so must have just displayed the last card in the trick
        m_ourTrickCount = ptrs;
        m_oppsTrickCount = opps;
        trickSave(ptrs + opps - 1);
    }
}

//returns the trick being played in the range 0 to 12
//cardsPlayed is the number of cards played in the current trick (0 - 4)
function trickIndexSet(cardsPlayed, playedCards) {
    var ptrs = parseInt(m_ourTrickCntEl.innerText);
    var opps = parseInt(m_oppsTrickCntEl.innerText);
    var tricksPlayed = ptrs + opps;
    //trickPlayed is OK on the 1st and 2nd played card. On the 4th the trick counter will have been
    //incremented to show the result of the trick so needs to be decrement.
    //On the 3rd card they are OK when the 3rd card is initially displayed but, in picture card display,
    //the counters get incremented on a subsequent display before the 4th card is displayed
    if (cardsPlayed == 4){
        //Trick counters will be wrong
        tricksPlayed--;
    }
    else if (cardsPlayed == 3){
        //trick counter should be OK for the 3rd card as long as processed when 3rd card first displayed
        //(not on duplicates displays when using picture cards)
        //just ensure the 2nd card previously played
        if (!m_boardTrick[tricksPlayed] || !m_boardTrick[tricksPlayed][1]){
            //looks like a jump
            if(tricksPlayed == 0){
                console.log("3rd card counter reset on first trick. Cards:" + JSON.stringify(playedCards))
                speakError("Warning 3rd card counter reset on first trick");
                //debugger;
            }
            else{
                tricksPlayed--;
            }
        };
    }
    return tricksPlayed;   
}


//A trick has just finished
function trickSave(index){
    m_tricks[index] = [];
    var dest = m_tricks[index];
    //need to copy tricks otherwise by assignment
    for (let i = 0; i < 4; i++) {
        dest[i] = m_trick[i];       
    }; 
    m_trick.length = 0;
    m_orderedCards.length = 0;
    //(debug){
        var text = "Trick:" + (index + 1);
        var trick = m_tricks[index];
        for (let i = 0; i < 4; i++) {
            const el = trick[i];
            text += " " + (el ? (el.seat + ":" + el.card + el.suit) : "Null");
        }
        consolelog(text);    
    //}   
}


////////////////////events/////////////////////////

function onKeyDown(ev) {
    if (ev.code == "Enter") {
        //route the enter to the last input field used by the speech to text
        if (m_lastMic && m_lastMic.okBtnEl && !m_lastMic.okBtnEl.disabled && 
            !(m_lastMic.okBtnEl.style.display == "none")){
            if (m_lastMic.okFn)
                m_lastMic.okFn(m_lastMic.okBtnEl);
            else {
                m_lastMic.okBtnEl.click();
                speakText("Sent", SpeakChatEnterPressed); 
            }
        }
    }
    else if (ev.code == "Escape" && !ev.repeat) {
        if (m_lastMic && !m_lastMic.active()) {
            m_lastMic.inputEl.value = "";
            var text = "\n";
            setInputBoxText(m_lastMic.inputEl, text);
        }
    }
}

function onMouseClick(ev){
    var speech = "";
    var clickElFnd = false;
    //record the current playing surface dims just in case they change
    
    playingSurfaceResized();
    clickCnt++;
    m_clickEl = ev.path[0];  
    var parentClass = ev.path[1].className;
    var level, suit;

    consolelog("MouseClick screenX:" + ev.screenX + ", screenY:" + ev.screenY + ", offsetX:" + ev.offsetX + 
            ", offsetY:" + ev.offsetY + ", pageX:" + ev.pageX + ", pageY:" + ev.pageY + ", clientX:" + ev.clientX + 
            ", clientY:" + ev.clientY );

    if (typeof(m_clickEl.className) != "string"){
        //console.log("Click Error:" + m_clickEl.className.toString());
        return;
    }

    if (m_clickEl.className.includes(BiddingBtnClass) || (parentClass && parentClass.includes(BiddingBtnClass))){
        //a bidding box button was clicked
        var btnId = getBtnId(m_clickEl.innerText);
        if (btnId == -1) return;

        //protect against clicking within the bidding box by mistake
        var now = Date.now();
        if ((now - m_biddingBoxDisplayTime) < 1000){
            //assume the user intended to click on the tablecloth
            chrome.runtime.sendMessage({op: MsgBoardNumberClicked, board: m_board, hand: m_hand});
            return;
        }

        var btn = {shiftKey: ev.shiftKey, altKey: ev.altKey, ctrlKey: ev.ctrlKey, button: ev.button, buttons: ev.buttons};
        btn.className = m_clickEl.className;
        btn.id = btnId;
        msgCounter += 1;
        var biddingBtn = biddingBtns[btnId];

        if (biddingBtn.type == BtnOK){
            //the OK button was clicked
            if (m_params.sayOK) speakText("OK", SpeakBidOK);
            m_myFirstBid = false;
            m_prevBtnId = -1;
            m_prevClickEl = m_clickEl;   //save last button clicked
            return;
        }

        //bidding box will stay open (unless the BBO Confirm bid isn't enabled but don't worry about that)
        if (biddingBtn.type == BtnAlert){
            //clicked on the alert button to set or clear it
            let state = "off";
            m_alertBtnState = !m_alertBtnState;
            if (m_params.alertAssist){
                //alert assistance enabled so make sure the alert tab is displayed or not.
                if (m_alertBtnState){
                    selfAlertUpdate("current", m_bidLevelBtnId, m_bidSuitBtnId);
                    state = "on";
                }
                else selfAlertClose();
            };
            if (m_params.sayNonSuit) speakText("Alert " + state, SpeakNonSuitNTBidClick);
            clickElFnd = true;
        }
        else{
            //Was a bid button pressed for the 2nd time, or just the first time and auto accept set in which case it's a confirmation?
            if (biddingBtn.type == BtnSubmit || biddingBtn.type == BtnSuit){
                if (m_prevBtnId == btnId || (m_params.autoAcceptBids && !m_alertBtnState)){
                    //echo the OK request via the background in order to give time for the OK button to be displayed
                    chrome.runtime.sendMessage({op: MsgEcho, msg: {op: MsgSubmitBid}});
                    m_myFirstBid = false;
                    m_bidSuitBtnId = btnId;
                    if (biddingBtn.type == BtnSubmit) m_ownLastBid = biddingBtns[m_bidSuitBtnId].text;
                    else m_ownLastBid = biddingBtns[m_bidLevelBtnId].text + biddingBtns[m_bidSuitBtnId].text;
                    m_prevBtnId = -1;
                    m_prevClickEl = m_clickEl;   //save last button clicked
                    return;
                };
            };       

            if (biddingBtn.type == BtnSuit){
                //a suit or NT button was clicked so may need to update the list of self-alerts
                //Make sure Donald has not selected the wrong suit
                if (m_prevClickEl != m_clickEl && m_specialPlayer && m_myFirstBid && 
                    donaldIssue(biddingBtns[m_bidLevelBtnId].text, biddingBtn.abbrev)){
                    //looks like there could be a problem so highlight the issue and ignore this first click
                    speech = "Only " + sayCardConfirm(biddingBtn);
                    speakText(speech, SpeakWarnDonaldSuitLength);  //treat as high priorty msg
                    btnId = -1;
                }
                else{
                    m_bidSuitBtnId = btnId;
                    m_ownLastBid = biddingBtns[m_bidLevelBtnId].text + biddingBtns[m_bidSuitBtnId].text;
                    selfAlertUpdate("current", m_bidLevelBtnId, m_bidSuitBtnId);
                    if (m_params.saySuitBids) {
                        var bidObj = new Bid(m_ownLastBid);
                        if (m_lastSuitBidIx > -1) bidObj.setJump(m_auctionBids[m_lastSuitBidIx]);
                        if (bidObj.jump) speech = "Stop jump ";
                        speech += saySuitBid(biddingBtns[m_bidLevelBtnId].speak, biddingBtn.abbrev) + " ";
                    }
                    if (m_params.sayCardCnt) speech += sayCardConfirm(biddingBtn);
                    if (speech != "") speakText(speech, SpeakSuitNTBidClick);
                }
            }
            else{
                //level, pass, dbl or rdbl button clicked
                if (m_params.sayNonSuit) speakText(biddingBtn.speak, SpeakNonSuitNTBidClick);
                
                if (biddingBtn.type == BtnLevel) {
                    //just a level button preseed so may need to reduce list of alerts
                    m_bidLevelBtnId = btnId;
                    m_bidSuitBtnId = -1;
                    m_ownLastBid = "";
                    selfAlertUpdate("current", m_bidLevelBtnId, m_bidSuitBtnId);
                }
                else {
                    //Pass, DBL or RDBL
                    m_bidLevelBtnId = -1;
                    m_bidSuitBtnId = btnId;
                    m_ownLastBid = biddingBtns[m_bidSuitBtnId].text;
                    selfAlertUpdate("current", m_bidLevelBtnId, m_bidSuitBtnId);
                }
            } 
        };
        clickElFnd = true;
    }
    else if (checkAncestorTag(m_clickEl, m_currentTable.table)){
        if (m_clickEl.className.includes(BoardNumberClass)){
            //board number clicked?
            if (m_boardNumberEl == m_clickEl && m_boardPhase == AuctionPhase){    //make sure it's the correct board (not a history board)
                //re-read the hand and send msg to background
                chrome.runtime.sendMessage({op: MsgBoardNumberClicked, board: m_board, hand: m_hand});
                clickElFnd = true;
            }
        }
        else if (m_clickEl.className.includes(m_currentTable.tableCloth)){
            //background tablecloth clicked
            if (m_boardNumberCreated  && m_boardPhase == AuctionPhase){
                chrome.runtime.sendMessage({op: MsgTableClicked, board: m_board, hand: m_hand});
                clickElFnd = true;
            }
        }
    }
    else if (m_clickEl.id.includes(AlertIdStr)){
        //clicked on a self alert row in the self-alert assist side tab
        let desc = "";
        if (m_clickEl.className.includes("selfAlertDesc")) desc = m_clickEl.innerText;
        else desc = m_clickEl.nextElementSibling.innerText;
        //populate the alert or the explanation request input
        if (m_alertTabSource == "current"){
            level = (m_bidLevelBtnId >= 0 ? biddingBtns[m_bidLevelBtnId].text : "");
            suit = (m_bidSuitBtnId >= 0 ? biddingBtns[m_bidSuitBtnId].text : "");
            setInputContainerText(m_biddingBoxEl, desc);
        }
        else{
            level = m_bidExplainLevel;
            suit = m_bidExplainSuit
            setInputContainerText(m_explainBidEl, desc);
        };

        //auto click the OK button unless still need to read out the text
        if (m_clickEl == m_prevClickEl || !m_params.sayAlertedBids){
            //when one pop-up disappears it will ensure that the self alerts switch to the other
            //if the other was also active
            if (m_alertTabSource == "current") clickBiddingBoxOKBtn();
            else clickExplainRequestOKBtn();
            m_myFirstBid = false; ""
        }
        else{
            let index = parseInt(m_clickEl.id.substr(AlertIdStr.length + 1));
            let sa = m_selfAlertCard.bids[index];
            speakText(sayBid(level + suit) + " is " + sa.desc, SpeakSelfAlert);
        }
        clickElFnd = true;
    }
    if(!clickElFnd) onMouseClickExtra(m_clickEl, ev);

    m_prevClickEl = m_clickEl;   //save last button clicked
    m_prevBtnId = btnId;
};

//click element to check for as an ancestor. Go up so many gens (generations)


function onMouseClickExtra(element, ev){
    const SpecialClickedElements = [
        {id: 0, type: "class", name: "explainCallClass", gens: 7}
        ,{id: 1, type: "tag", name: "BIDDING-BOX", gens: 6}
        ,{id: 2, type: "tag", name: "TAB-BAR-BUTTON", gens: 1}
        ,{id: 3, type: "class", name: "auctionBoxCellClass", gens: 2}
        ,{id: 4, type: "class", name: "cardArea", gens: 2}
        ,{id: 5, type: "class", name: "handDiagramCardClass", gens: 2}
        ,{id: 6, type: "class", name: "vulPanelInnerPanelClass", gens: 0}
        ,{id: 7, type: "class", name: "buttonLogin", gens: 1}
        ,{id: 10, type: "id", name: "chatMicrophone", gens: 0}
        ,{id: 11, type: "id", name: "alertMicrophone", gens: 0}
        ,{id: 12, type: "id", name: "explainMicrophone", gens: 0}
    ];

    var text = "";
    var suit;
    var number;
    var obj = checkForAncestor(element, SpecialClickedElements);
    if (obj == null) return null;

    var node = obj.node;
    switch (obj.id) {
        case 0: 
            //the bid explanation request box clicked so show the alerts for it 
            selfAlertShow();
            selfAlertUpdateDisplay("explain", m_bidExplainLevel, m_bidExplainSuit);
            m_ownLastBid = m_bidExplainLevel + m_bidExplainSuit;
            break;

        case 1:
            //the main bidding box was click so ensure the self alert assist is correctly displayed
            selfAlertUpdate("current", m_bidLevelBtnId, m_bidSuitBtnId);
            break;

        case 2: 
            //a side bar tab was click so ensure the self alert box is hidden (if created)
            m_prevSideTabEl = null;
            if (m_selfAlertEl) selfAlertHide();
            break;

        case 3:
            //clicked an old bid so there may be an explanation that needs to be read out if one pops up
            m_lastAuctionBidClicked = node.innerText;
            break;

        case 4: 
            //picture of a card click. Contains two images of the card (top left and bottom right)
            /*
            text = node.innerText;
            var len = text.length / 2;
            text = text.substr(text, len);  //the 10 has a length of 3 chars inc suit and a \n between the num and suit
            suit = text.substr(len - 1);
            number = text.substr(0, len - 2);
            text = sayCard(number, suit);
            */
            break;

        case 5:
            //hand diagram card clicked so decide to read it
            //number = node.innerText;
            break;

        case 6:
            //board number (other the main playing table) was click. Should be the history board asking for Bridge Solver
            if (m_specialPlayer){
                var root = checkAncestorTag(node, "DEAL-REVIEW-SCREEN");
                if (root){
                    if(ev.ctrlKey){
                        //toggle the auto display of Bridge Solver
                        if (m_autoBridgeSolver != 0){
                            node.style.backgroundColor = m_autoBridgeSolver;
                            m_autoBridgeSolver = 0;
                            //speakText("Disable auto display of Bridge Solver ", SpeakInfo);
                        }
                        else{
                            m_autoBridgeSolver = node.style.backgroundColor;
                            node.style.backgroundColor = "#FFFFFF";
                            //speakText("Enable auto display of Bridge Solver ", SpeakInfo);
                            displayBridgeSolver(root, node.innerText, true);
                        }
                    }
                    else displayBridgeSolver(root, node.innerText, true);
                }
            } 
            break;
    
        case 7:
            //login button - get the login container
            node = checkAncestorClass(node, "loginClass", 3);
            if(node){
                //get the userName
                var inputs = node.getElementsByTagName("input");
                m_userName = inputs[0].value;
                m_specialPlayer = specialPlayer(m_userName);
                consolelog("userName:" + m_userName + ", Special:" + m_specialPlayer);
            }
            break;
    
        case 10:
            //chat microphone
            if (!m_chatMic.active()){
                //clear the input field if mic is to be switched on
                speechEntryInit(m_chatMic);           
            };
            speakPause(!m_chatMic.active());
            m_chatMic.toggleState();  //change fron inactive to active or vice versa
            break;

        case 11:
            //self alert entry microphone
            if (!m_alertMic.active()) {
                speechEntryInit(m_alertMic);
            };
            speakPause(!m_alertMic.active());
            m_alertMic.toggleState();
            break;

        case 12:
            //bid explanation microphone
            if (!m_explainMic.active()) {
                speechEntryInit(m_explainMic);
            };
            speakPause(!m_explainMic.active());
            m_explainMic.toggleState();
            break;
    }
};

//scans to see if the element is part of larger node tree which should be
//grouped as a single phase
function mouseOverTextNodes(element) {
    //element to check for as an ancestor. Go up so many gens (generations)
    const SpecialElements = [
          {id: 0, type: "tag", name: "AUCTION-BOX-CELL", gens: 2 }
        , { id: -1, type: "class", name: "tricksPanelTricksLabelClass", gens: 0 }
        , { id: 1, type: "class", name: "bboaBid", gens: 2 }
        , { id: 2, type: "class", name: "handDiagramCurrentTrickClass", gens: 2 }
        , { id: 3, type: "class", name: "cardArea", gens: 2 }
        , { id: 4, type: "class", name: "callExplanationClass", gens: 2 }
        , { id: 5, type: "class", name: "nameBarClass", gens: 2 }
        , { id: 6, type: "class", name: "scorePanelClass", gens: 6 }
        , { id: 7, type: "class", name: "suitSymbolClass", gens: 0 }
        , { id: 8, type: "class", name: "logoBBO", gens: 0 }
    ];

    function formContract(bid, seat){
        var tmp = bid.toUpperCase();
        var idx = tmp.indexOf("X");
        if (idx >= 0) text = tmp.substr(0, idx) + seat + tmp.substr(idx);
        else text = tmp + seat;
        return text;
    };

    var text = "";
    var tmp;
    var suit;
    var number;
    var parent;
    var seat;
    var idx;
    var subNode;
    var obj = checkForAncestor(element, SpecialElements);
    if (obj == null) return null;

    var node = obj.node;
    switch (obj.id) {

        case -1: //Might be the seat element for the declared contract
            //Merge it with the actual contract if it is.
            subNode = node.nextElementSibling;
            if (subNode && subNode.tagName &&  subNode.tagName == "AUCTION-BOX-CELL"){
                text = formContract(subNode.innerText, node.innerText[0]);
                node = subNode; //treat it as if contract had been selected
            }
            else text = node.innerText;
            break;

        case 0: //The declared contract either current or history or maybe some other auction
            //Need to merge contract with seat if the correct node
            parent = node.parentElement;
            subNode = parent.querySelector(".tricksPanelTricksLabelClass");
            if (subNode && Seats[subNode.innerText[0]]){
                //need to insert the seat between the suit and any doubles
                text = formContract(node.innerText, subNode.innerText[0]);
            }
            else text = node.innerText;
            break;


        case 2: //simple image of card as suit followed by number)
            text = node.innerText;
            suit = text.substr(0, 1);
            number = text.substr(1);
            text = sayCard(number, suit);
            break;

        case 3: //picture of a card contains two images of the card (top left and bottom right)
            text = node.innerText;
            var len = text.length / 2;
            text = text.substr(text, len);  //the 10 has a length of 3 chars inc suit and a \n between the num and suit
            suit = text.substr(len - 1);
            number = text.substr(0, len - 2);
            text = sayCard(number, suit);
            break;

        case 4: //a bid explanation
            text = sayBidExplanation(node);
            break;

        case 5: //symbol for a seat position
            text = saySeat(node.innerText.substr(0, 1)) + node.innerText.substr(1);
            text = text.replace(/\n/g, "");
            break;

        case 6: //symbol displaying the score
            var header = node.querySelector(".headingClass");
            var list = node.querySelectorAll(".dataClass");
            var you = 0;
            var opps = 1;
            if (m_ownSeat == "E" || m_ownSeat == "W"){
                you = 1;
                opps = 0;
            }
            text = header.innerText;
            if (text == "MPs" || text == "IMPs"){
                text = list[you].innerText + " " + text;
            }
            else{
                text = list[you].innerText + " versus " + list[opps].innerText;
            }
            break;

        case 7: //the suit symbol in the simple grid card layout
            suit = node.innerText;
            //determine the number of cards in the suit
            parent = node.parentElement;
            var result = getRemainingCards(parent, suit);
            text = saySuitBid(result.cards, suit) + result.cardsText;
            break;

        case 8: //BBO Logo
            text = "Bridge Base Online";
            break;


        default:
            //text can be expanded using the standards abbreviations so just send it to the background
            text = node.innerText;
            break;
    }
    return { node: node, text: text };

}

//messages from the background event handlers
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse){
    consolelog("BBOA_Content Msg:" + request.op);
    switch (request.op) {
        case MsgContextParams:
            //update the the parameters
            m_params = request.params;
            m_selfAlertCard.bids = request.selfAlerts;
            g_mouseReader.enable(m_params.sayMouseOver);
            break;

        case "MsgSpeechConversions":
            //update to the conversion parameters
            consolelog("Speech Init");
            SpeechToText.setConversions(request.params.translations);
            break;

        case MsgSubmitBid:
            //bid is to be accepted
            clickBiddingBoxOKBtn();
            break;

        case MsgSelfAlertCard:
            //provides the convention card to be used for self-alerts
            m_selfAlertCard = request.card;
            break;            
    
        case MsgEchoTest:
            //test if echoing provides the required delay 
            break;            
    
        case "chgDisplay":
            //change the displayed screen - test msg
            var screens = document.querySelectorAll(request.query);
            var active = -1;
            for (let i = 0; i < screens.length; i++) {
                const el = screens[i];
                if (el.style.display && el.style.display != "none"){
                    active = i;
                    break;
                }
            }
            if (active != -1){
                var state = screens[active].style.display
                screens[active].style.display = "none";
                active++;
                if (active == screens.length) active = 0;
                screens[active].style.display = state;
            }
            break;
        
        case "alert":
            //display an alert window
            alert(request.text);
            break;

            
    };
});

//window.addEventListener('DOMContentLoaded', function(){
chrome.runtime.sendMessage({ op: MsgRequestParams });

initDeck();

//parent node for the <bridge-sceen> tag is to be monitored
//Currently only support the normal table (not the solitaire so only one element in the array.)
document.addEventListener("click", onMouseClick, true);
document.addEventListener("keydown", onKeyDown);

m_currentTable = TableEls[0];
m_tableRootEl = document.querySelector("div.navDivClass"); //the root for the playing table.
if(m_tableRootEl == null) {
    consolelog("Failed to find element table parent:" + m_currentTable.TableRoot);
    speakText("BBO didn't initialise so please retry.", SpeakInfo);
    alert("BBO didn't initialise so please retry");
}
else {
    monitorTableRoot(m_tableRootEl);
    monitorRootNotifications(document);
}
setInterval(function(){chrome.runtime.sendMessage({op: MsgKeepAlive});}, 3000);
SpeechToText.speechInit();
g_mouseReader.init(m_params.sayMouseOver, mouseOverTextNodes);


//});
