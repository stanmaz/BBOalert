"use strict"

//accessor to exported functions
var g_mouseReader = {};   

{//hide all other variables and functions

    //initialise the accessor
    g_mouseReader.init = mouseReaderInit;
    g_mouseReader.enable = mouseReaderEnable;

    let m_debug = false;        //displays console logs
    let m_readerExtensionFn;    //function that is called to extend the processing of mouse over
    let m_readText = false;     //whether or not to read text
    let m_lastMouseX;
    let m_lastMouseY;
    let m_mouseOverTimer = 0;
    let m_mouseOverTime = 0;
    let m_mouseOverText = "";
    let m_messageSent = false;      //sppech sent to background
    let m_prevTextNode;
    let m_mouseOverTimeMS = 50;
    let m_lastRightClick = 0;   //last time the right hand mouse button clicked

    function consolelog(text) {
        if (m_debug) console.log(text);
    }

    function checkForText(rootText, node, depth, id) {
        var text;
        var check;

        //check sub-node to see which contains the text
        for (let i = 0; i < node.children.length; i++) {
            const el = node.children[i];
            text = el.innerText;
            if (text == undefined || text.trim() == "") continue;
            if (text != rootText && getComputedStyle(el, null).getPropertyValue("display") != "inline") return null;          //only part of the text in this branch so text is split across nodes 
            return checkForText(rootText, el, depth + 1, i);
        }
        return { node: node };
    }


    //Either a new textNode has been detected or the mouse is not over a textNode. In the latter case abort a queued mouse over reading
    //If a new textNode queue it and send it for reading after a small delay (if the mouse has not moved and reset the queued item)
    function mouseOverQueue(textNode, text) {
        var now = Date.now();
        var gap = now - m_mouseOverTime;
        m_mouseOverTime = now;
        if (textNode) {
            var node = "(" + textNode.tagName + ")." + textNode.className;
            consolelog("mouseOverQueue gap:" + gap + ", newText:" + text + ", timer:" + m_mouseOverTimer + ", oldText:" + m_mouseOverText + ", node:" + node);
        }

        //main code
        if (m_mouseOverTimer != 0) clearTimeout(m_mouseOverTimer);
        m_mouseOverTimer = 0;
        if (text) {
            m_mouseOverText = text;
            m_mouseOverTimer = setTimeout(mouseOverQTimeout, m_mouseOverTimeMS);
        }
        else speakAbort();
    }

    function speakAbort(){
        consolelog("mouse Abort Mouse Over");
        if (m_messageSent) chrome.runtime.sendMessage({ op: MsgSayText, text: "", priority: SpeakMouseOver, delete: true}); //aborts any read
        m_mouseOverText = "";
        m_messageSent = false;
    }

    function mouseOverQTimeout() {
        if (m_mouseOverTimer != 0) {
            consolelog("mouse MsgSayText:" + m_mouseOverText + ":");
            chrome.runtime.sendMessage({ op: MsgSayText, text: m_mouseOverText, priority: SpeakMouseOver, delete: true});
            m_mouseOverTimer = 0;
            m_mouseOverText = "";
            m_messageSent = true;
        }
    }


    function onContextMenuHandler(ev) {
        ev.preventDefault();    //disable context menu since right mouse click used to abort text being read
    };


    //pressing the escape key abort the text being read
    function onKeyDown(ev) {
        if (ev.code == "Escape" && !ev.repeat) {
            let now = Date.now();
            chrome.runtime.sendMessage({ op: MsgAbortSpeech, all: false, time: now});
        }
    }


    function onMouseClick(ev) {
        //mouse movements within the same node do not trigger mouseOver events so the X/Y co-ords of the mouse 
        //may be out of date when the mouse is deleted. Need to avoid the reading of the clicked event being aborted
        //by the text under the mouse.
        m_lastMouseX = ev.screenX;
        m_lastMouseY = ev.screenY;
    }


    //abort the text currently being read when the right mouse button is pressed down
    function onMouseDown(ev) {
        //abort speech if right mouse button clicked
        let now = Date.now();
        if(ev.button == 2){
            let dblClick = (now - m_lastRightClick < 500);
            //console.log("Mouse Right Click:" + now + ", Dbl:" + dblClick);
            chrome.runtime.sendMessage({ op: MsgAbortSpeech, all: dblClick, time: now});   
            m_lastRightClick = now;
        }
        else {
            chrome.runtime.sendMessage({ op: MsgAbortSpeech, all: true, time: now});   
        }
    }

    //main function to detect the text under the mouse and to read it if the function is enabled
    //Need to avoid just using innerText since this could be a lot of text when the mouse is over
    //a high level element so only read when over block elements.
    function onMouseOver(ev) {
        //control key reverses the state of the parameter and mouse button 2 disables reading
        if (m_readText == ev.ctrlKey) return;
        if (ev.buttons >= 2) return;

        if (m_lastMouseX == ev.screenX && m_lastMouseY == ev.screenY) return;

        //need to ignore the mouse being over a new element when the current element disappearred due to a mouse click
        //otherwise could speak the mouseover thus aborting the mouse click text.
        consolelog("MouseOver screenX:" + ev.screenX + ", screenY:" + ev.screenY + ", offsetX:" + ev.offsetX +
                ", offsetY:" + ev.offsetY + ", pageX:" + ev.pageX + ", pageY:" + ev.pageY + ", clientX:" + ev.clientX +
                ", clientY:" + ev.clientY);

        m_lastMouseX = ev.screenX;
        m_lastMouseY = ev.screenY;

        var node = ev.target;
        var textNode = null;
        var text;

        if (node.nodeName == "INPUT") {
            text = (node.type == "password" ? "Enter password" : node.value);
            if (text && text.trim() != "") textNode = node;
            else node = node.parentElement;     //use the label for the input
        };

        if (node.nodeName == "IMG") {
            text = (node.title != "") ? node.title : node.alt;
            textNode = node;
        };

        //if not an input or image get the text to read
        if (textNode == null) {
            text = node.innerText;
            if (text && text.trim() != "") {
                //node contains text so first see if the node is special (if the function was set during initialisation)
                var root = (m_readerExtensionFn ? m_readerExtensionFn(node) : null);
                if (root) {
                    textNode = root.node;
                    text = root.text;
                }
                else {
                    //not a special node so only use the text if it isn't from a number of sub-nodes
                    var result = checkForText(node.innerText, node, 0);
                    if (result != null) textNode = result.node;
                }
            };
        };

        if (textNode) {
            if (textNode != m_prevTextNode) {
                //don't say "Explain" unless alert has been set
                if (text != "Explain" || m_alertBtnState)
                    mouseOverQueue(textNode, text);
            };
        }
        else mouseOverQueue();
        m_prevTextNode = textNode;
    };

    //external functions

    //enable - set to true (default) to enable reading the text under the mouse
    //extension - a function that is called to test for specific nodes that should be read as one. The fn must returm null
    //is the mouse is not within such a nested group so an object with textNode (outer node) and the text
    function mouseReaderInit(enable, extension) {
        m_readText = (enable == undefined ? true : enable);
        //console.log("mouseReaderInit:" + enable + " m_readText:" + m_readText);
        m_readerExtensionFn = extension;
        document.addEventListener("mouseover", onMouseOver);
        document.addEventListener("mousedown", onMouseDown, true);
        document.addEventListener("click", onMouseClick, true);
        document.addEventListener("keydown", onKeyDown);
        document.addEventListener("contextmenu", onContextMenuHandler);
        window.addEventListener('beforeunload', function(ev) {
            chrome.runtime.sendMessage({ op: MsgAbortSpeech, all: true});
        });
        document.addEventListener("mouseleave", function(event){ 
            speakAbort();
        });         
    }

    function mouseReaderEnable(enable) {
        m_readText = enable;
        consolelog("mouseReaderEnable:" + enable);
    }

}
