'use strict';
/*
This module needs to be included within the background's list of scripts in the manifest file. 
It should be listed before any file that calls any of its functions.

The following permissions are required in the manifest file: tabs, storage, contextmenus.

When the background or popup module is loaded it must call the function g_newTabdest.initialise(). After that any of the
other exported functions may be invoked.

New tabs will either be created in the current window (default) or in a detached window.
Two context menu items are defined. Selecting "NewWindow" will result in new tabs being created in a detached window; all
new tabs are created in the same detached window until "NewWindow" is select again or until "CurrentWindow" is selected.
"CurrentWindow" reverts back to new tabs being created in the current window whereas selecting "newWindow" will start another
detached window. 

The position and dimensions of the detached window are persisted in local storage. It is not possible to detect the 
resizing and movement of the detached window without a context script and, even if done, these updates could be too frequent. 
Consequently, the state of the detached window is only persisted whenever a new tab is created or a specific request is made
to persist the state.

Functions:

g_newTabDest.initialise(extensionName)
Must be called from a background script in order to load the context menu items. Must also be called from any other module
that uses any of the other exported functions.

g_newTabDest.tabs.create(createTabData, callback(tabs))
Create a tab in either the current window or the detached window creating the window if necessary. Parameters are identical
to those used by the function chrome.tabs.create() for a GET window. if you want to create a window using the POST request add a postParms
parameter to the createtabData; this parameter is an object which contains the parameters that the web server expects.

g_newTabDest.tabs.moveToWindow(tabId, callback(winObj))
Moves an existing tab to the detached window creating the window if necessary as long as the "Create Tabs in New Window" has been 
requested; otherwise the request is ignored.

g_newTabDest.storage.save(callback())
Function to persist the current position and dimensions of the detached window to local storage. The data is internally persisted
whenever a tab is added to the detached window which should be acceptable so this function need not be invoked. However, when a window
is closed any movement/resizing since the last tabs was added to the window will not be persisted. To detect all changes to the
window a context script would be required to report the changes and invoke this function.
*/

//accessor to exported functions and variable
var g_newTabDest = {};    

{//start of module

g_newTabDest.initialise = initialise;
g_newTabDest.storageId = "Module Not Initialised";

//Copy of the data saved in the local storage. To minimise load a copy is read from storage when required and persisted
//to storage as part of the module unload process.
let m_windowState = {};

//Parameters used to queue creation requests to avoid more than one window being created if a new create request is
//received before the window has been created.
let m_createBusy = false;
let m_createQueue = [];



let m_debugLog = false;
let debugCnt = 0;
let createCnt = 0;

let m_extensionName = "";
let m_storageId = "";

//Context menu items
let m_newWindowMenuItem = {
    id: "newWindow",
    title: "Create Tabs in New Window",
    type: "normal",
    contexts: ["all"]
};
let m_saveWindowMenuItem = {
  id: "saveWindow",
  title: "Save Window Position",
  contexts: ["all"]
};

let m_currentWindowMenuItem = {
    id: "currentWindow",
    title: "Revert to Current Window",
    type: "checkbox",
    contexts: ["all"]
};

//Must be called as part of the background scripts loading
function initialise(extensionName, context){
  if (context == undefined) conext = true; 
  m_extensionName = extensionName;
  m_storageId = extensionName + "NewTabDest";
  m_newWindowMenuItem.id = extensionName + "newWindow";
  m_saveWindowMenuItem.id = extensionName + "saveWindow"; 
  m_currentWindowMenuItem.id = extensionName + "currentWindow";

  //create the exported functions and variables
  g_newTabDest.storageId = m_storageId;

  g_newTabDest.tabs = {};
  g_newTabDest.tabs.create = createTab;
  g_newTabDest.tabs.moveToWindow = moveTabToNewWindow;  //tab moved to a window
  g_newTabDest.storage = {};
  g_newTabDest.storage.save = storageSave; //persist the state of the detached window

  if (context){
    chrome.contextMenus.onClicked.addListener(function(clickedData, selectedTab){
      var destWinState;
      switch (clickedData.menuItemId) {
        case m_newWindowMenuItem.id:
          //tabs to be created in a detached window
          destWinState = {windowId: chrome.windows.WINDOW_ID_NONE, dims: {top: 0, left: 0, width: 0, height: 0}};
          storageUpdate(destWinState);
          setSelectedMenu(chrome.windows.WINDOW_ID_NONE)
          break;
  
          case m_saveWindowMenuItem.id:
            //tabs to be save the position of the detached window
            storageSave();
            break;
    
          case m_currentWindowMenuItem.id:
          //reset the system so new tabs will be created in the current window (the window from which the new tab is created)
          destWinState = {windowId: chrome.windows.WINDOW_ID_CURRENT, dims: {top: 0, left: 0, width: 0, height: 0}};
          storageUpdate(destWinState);
          setSelectedMenu(chrome.windows.WINDOW_ID_CURRENT)
          break;
      }; 
    });
    //ignore an attempt to add the context menus more than once as the onInstalled function doesn't always get called.
    //try {addContextMenuItems();} catch (error) {};

    chrome.runtime.onInstalled.addListener(function(){
      //create the context menu items just once
      addContextMenuItems();
    });
  }


}; //end of initialise

//debug aid
function log(report) {
  if (m_debugLog) console.log(report);
};

//create the 2 context menu items - call only when extension is installed
function addContextMenuItems(){
  //determine the current context and then create the context options
  storageGet(function(state){
    chrome.contextMenus.create(m_newWindowMenuItem, function(){
      chrome.contextMenus.create(m_saveWindowMenuItem, function(){
        chrome.contextMenus.create(m_currentWindowMenuItem, function(){
        //Both created so now updated
          setSelectedMenu(state.windowId);
        });
      });
    });
  });
};

function setSelectedMenu(windowId){
  if (windowId == chrome.windows.WINDOW_ID_CURRENT){
    chrome.contextMenus.update(m_newWindowMenuItem.id, {checked: false, visible: true});
    chrome.contextMenus.update(m_saveWindowMenuItem.id, {visible: false});
    chrome.contextMenus.update(m_currentWindowMenuItem.id, {checked: false, visible: false});
  }
  else{
    chrome.contextMenus.update(m_newWindowMenuItem.id, {checked: false, visible: true});
    chrome.contextMenus.update(m_saveWindowMenuItem.id, {visible: true});
    chrome.contextMenus.update(m_currentWindowMenuItem.id, {checked: false, visible: true});
  };
};

//External function to handle the callback not being defined
function createTab(createTabData, callback){
  //Just in case a new window needs to be created queue multiple requests
  if (m_createBusy){
    //queue the request until the current tab has been created. In principle only need to queue the request if the
    //detached window needs to be created but that would be compex to implement and there is only a small delay
    //if there are multiple requests
    m_createQueue.push({params: createTabData, callbackFn: callback});
  }
  else{
    m_createBusy = true;
    createTabRun(createTabData, callback)
  };
};

//After a tab has been created there may be a queued one
function createTabCmpl(createTabData, callback){
  if (m_createQueue.length > 0){
    let oldRequest = m_createQueue.shift();
    createTabRun(oldRequest.params, oldRequest.callbackFn)
  }
  else m_createBusy = false;
};

//External function to handle the callback not being defined
function createTabRun(createTabData, callback){
  if (createTabData.url && createTabData.postParams){
    createTabPostFn(createTabData, function(newTab){
      if (callback != null) callback(newTab);
      createTabCmpl();
    });
  }
  else{
    createTabFn(createTabData, function(newTab){
      if (callback != null) callback(newTab);
      createTabCmpl();
    });
  };
};

//Create a new tab either in the current window or in another window which is created if it doesn't exist
function createTabFn(createTabData, newTabCallback){
  storageGet(function(destWinDesc){
    if (destWinDesc.windowId != chrome.windows.WINDOW_ID_CURRENT){
      getWindow(destWinDesc.windowId, function(winObj){
        if (winObj){
          //window still exists so add tab to it and save the current dims
          createTabData.windowId = destWinDesc.windowId;
          chrome.tabs.create(createTabData, function(newTab) {
            destWinDesc = {'windowId': winObj.id, dims: {'top': winObj.top, 'left': winObj.left, 'width': winObj.width, 'height': winObj.height}};
            storageUpdate(destWinDesc, function(){
              newTabCallback(newTab);
            });
          });
        } 
        else{
          //create a new window with the new tab
          let winParams = destWinDesc.dims;
          createWindowOption1(winParams, createTabData, function(newTab, newWin){
            let destWinDesc = {'windowId': newWin.id, dims: {'top': newWin.top, 'left': newWin.left, 'width': newWin.width, 'height': newWin.height}};
            storageUpdate(destWinDesc, function(){
               newTabCallback(newTab); 
            });
          });
        };
      });
    }    
    else {
      //just pass on the initial request to create the tab
      chrome.tabs.create(createTabData, function(newTab) {
            newTabCallback(newTab);
      });
    };
  });  
};

//Create a new tab either in the current window or in another window which is created if it doesn't exist.
//The tab is to be populated using the POST http method which the chrome create tab doesn't support.
//The tab is created with an initial document that is then sent a message to execute the POST instructions
function createTabPostFn(params, newTabCallback){
  //remove the postParams since the tab creation function doesn't support it and chnage the url to
  //the form that will perform the required POST request
  let createTabData = Object.assign({}, params);
  delete createTabData.postParams;
  createTabData.url = chrome.runtime.getURL("post.html"); 

  createTabFn(createTabData, function(tab) { 
      if (tab){
        //send the url and params message to the new page when it has loaded
        var handler = function(tabId, changeInfo) {
            if (tabId === tab.id && changeInfo.status === "complete"){
                chrome.tabs.onUpdated.removeListener(handler);
                chrome.tabs.sendMessage(tab.id, {op: "postInit", url: params.url, params: params.postParams});
              };
        };
        chrome.tabs.onUpdated.addListener(handler);

        //Just in case the new page was loaded before the listener could be set up send the message
        //It is more likely that the new page is slower to load so the following message will be missed and the page
        //will receive the one sent when the listener is triggered.
        chrome.tabs.sendMessage(tab.id, {op: "postInit", url: params.url, params: params.postParams});
      };
      newTabCallback(tab);
  }); 
};
    


//Create the tab in a new window. 
function createWindowOption1(winParams, createTabData, callback){
  winParams.url = createTabData.url;
  chrome.windows.create(winParams, function(newWin) {
    chrome.tabs.query({windowId: newWin.id}, function (tabs){
        callback(tabs[0], newWin)
    });
  });
};

//Create the tab in a new window. This variation of the code creates the tab in the current window and creates the
//new window by moving the created tab into it. This avoids a default tab being created in the new window 
//which then needs to be removed causing the window to flicker.
/*
function createWindowOption2(winParams, createTabData, callback){
  createTabData.active = false;
  chrome.tabs.create(createTabData, function(newTab) {
    //create the new window with the tab just created. 
    moveTabToDestWindowFn(winParams, newTab.id, function(newWin){ 
      newTab.windowId = newWin.id;   //need to update the windowId for the tab
      callback(newTab, newWin);
    });
  });
};*/

//Does the destinatation window still exist? Get an exception if just use the 'get' function.
function getWindow(windowId, callback){
  chrome.windows.get(windowId, {}, function(winObj) {
    //try-catch only catches synchronous exceptions. Testing for lastError is the way to catch asynchronous exceptions
    if (chrome.runtime.lastError) callback();
    else callback(winObj);
  });
};

//another way to determine if a window exists that does not use exceptions
/*
function getWindowOld(windowId, callback){
  chrome.windows.getAll({}, function(winList) {
    var winObj = null;
    for(let win of winList){
      if(win.id == windowId) { 
        winObj = win; 
        break; 
      };
    };
    callback(winObj);
  });
};*/

//External function to move a tab into the detached window or does nothing
function moveTabToNewWindow(tabId, callback){
  storageGet(function(destWinDesc){
    //ignore the request if tabs are being created in the current window
    if (destWinDesc.windowId != chrome.windows.WINDOW_ID_CURRENT){ 
      moveTabToDestWindowFn(destWinDesc, tabId, function(winObj){
        //bring the detached window to the front
        chrome.windows.update(winObj.id, {focused: true}, function(winObj){
          destWinDesc = {'windowId': winObj.id, dims: {'top': winObj.top, 'left': winObj.left, 'width': winObj.width, 'height': winObj.height}};
          storageUpdate(destWinDesc, function(){
            var updateProperties = { 'active': true };
            chrome.tabs.update(tabId, updateProperties, function(tab){
                if (callback != null) callback(winObj);
            });
          });
        });
      });
    };
  });
};

//Move an existing tab (tabId) into the destation window which is created if it doesn't exist
function moveTabToDestWindowFn(destWinDesc, tabId, callback){
  getWindow(destWinDesc.windowId, function(winObj){
    if (winObj){
      //window still exists so move tab into it and save the current dims
      chrome.tabs.move([tabId], {windowId: winObj.id, index: -1}, function(tab) {
          callback(winObj);
      });
    } 
    else{
      //create the window by moving the tab
      let createData = destWinDesc.dims;
      createData.tabId = tabId;
      chrome.windows.create(createData, function(newWin) {
          callback(newWin);
      });
    };
  });  
};

function storageGet(callback) {
  if (!m_windowState.storage){
    chrome.storage.sync.get(m_storageId, function(storedData){
      if (storedData[m_storageId])
        m_windowState.storage = storedData[m_storageId];
      else{
        m_windowState.storage = {windowId: chrome.windows.WINDOW_ID_NONE, dims: {top: 0, left: 0, width: 0, height: 0}};
      };
      m_windowState.changed = false;
      callback(m_windowState.storage);
    });
  }
  else callback(m_windowState.storage);
};

//Persist the destination windows data to local storage
function storagePersist(callback){
  if (m_windowState.changed){
    chrome.storage.sync.set({[m_storageId]: m_windowState.storage}, function(){
      m_windowState.changed = false;
      if (callback) callback();
    });
  };
};

//Read the window data and save it to local storage if it has changed
function storageSave(callback){
  storageGet(function(winDesc){
    if (winDesc.windowId != chrome.windows.WINDOW_ID_CURRENT){
      getWindow(winDesc.windowId, function(winObj){
        if (winObj){
          winDesc = {windowId: winObj.id, dims: {top: winObj.top, left: winObj.left, width: winObj.width, height: winObj.height}};
            storageUpdate(winDesc, function(){
            if (callback) callback(winObj);
          });
        };
      });
    };
  });
};

//Update the data that is to be persisted
function storageUpdate(winDesc, callback){
  var current = m_windowState.dims;
  var latest = winDesc.dims;
  if (m_windowState.windowId != winDesc.windowId || current.top != latest.top || current.left != latest.left ||
    current.width != latest.width || current.height != latest.height){
    m_windowState.storage = winDesc;
    m_windowState.changed = true;
    //Persist when updated at the moment rather than delay
    storagePersist(function(){
      if (callback) callback();
    });
  };
};


};//end of module
