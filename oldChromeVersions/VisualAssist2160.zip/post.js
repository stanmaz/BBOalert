/*
javascript file for post.html
When post.html is loaded this module waits for a message from the newTabDest.js module specifying the
url and the url params. The params are posted to the specified url with the results replacing the
contents of post.html
*/

var onMessageHandler = function(msg, sender){
  //Remove this handler now the expected message has been received.
  if (msg.op == "postInit"){
    let params = "";
    chrome.runtime.onMessage.removeListener(onMessageHandler);

    var form = document.createElement("form");
    form.setAttribute("method", "post");
    form.setAttribute("action", msg.url);
    form.setAttribute("target","_self");
    for(var key in msg.params) {
      var hiddenField = document.createElement("input");
      hiddenField.setAttribute("type", "hidden");
      hiddenField.setAttribute("name", key);
      hiddenField.setAttribute("value", msg.params[key]);
      form.appendChild(hiddenField);
      params += key + ": '" + msg.params[key] + "'<br>";
    };
    document.body.appendChild(form);

    //document.getElementById("status").innerHTML = "Message Received<br>url: '" + msg.url + "'<br>" + params;
    form.submit();
  };
};

//wait for the expected initialisation message
//document.getElementById("status").innerHTML = "Waiting for msg"

chrome.runtime.onMessage.addListener(onMessageHandler);