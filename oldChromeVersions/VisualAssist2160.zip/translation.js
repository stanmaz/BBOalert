"use strict"



class Translation{

    constructor() {
        this.firstWords = {};
    }


    
    //reset the tree and add the phrases
    initTranslations(translations) {
        this.firstWords = {};
        if (translations) this.addPhrases(translations);
    }

    //take the input phrase and return the expanded translation
    translate(input) {
        var result;
        var node;
        var output = [];
        var outIndex = 0;
        var words = input.trim().toLowerCase().split(" ");
        var wordCnt = words.length;

        for (var wordIndex = 0; wordIndex < wordCnt;) {
            //see if there is a translation starting with the current word
            node = this.firstWords[words[wordIndex]];
            if (node) {
                //a translation was found for one or more words
                result = this.lookupPhrase(words, wordIndex + 1, node);
                output[outIndex] = result.node.to;
                wordIndex = result.nextIndex; //skip to the first word not in the match
            }
            else {
                //no translation for the word so just copy it to the output stream
                output[outIndex] = words[wordIndex];
                wordIndex++;
            }
            outIndex++;
        }
        return output.join(" ");
    }

    
    //private classes below

    //tree node object
    //firstChild: null if no children otherwise an index to the first child's node
    //to: the translation if the search stops with this node (last node in the match)

    //add the first word to the tree root
    addNewRoot(firstWord, output){
        //add first word to the root
        var node = this.createNode(firstWord);
        node.to = output;
        this.firstWords[firstWord] = node;
        return node;
    }


    addPhrase(input, output) {
        var nextIndex;
        var newNode;
        var words = input.trim().toLowerCase().split(" ");
        var wordCnt = words.length;
        //see if there is a translation starting with the first word
        var node = this.firstWords[words[0]];
        if (node) {
            //follow the nodes for as many words as possible
            var result = this.lookupPhrase(words, 1, node);
            //lookup will have stoped at the first word that couldn't be found in the tree
            nextIndex = result.nextIndex;
            var lastCheckedNode = result.lastCheckedNode;        //the node just prior to where the unmatched word should be inserted
            var parent = result.node;    //the parent of the branch where comparisons stopped (node of last word found in the phrase)
            if(nextIndex < wordCnt){
                //an exact match for the phase not found so add the extra words to the tree.
                newNode = this.createNode(words[nextIndex]);
                if (lastCheckedNode === parent) {
                    //node needs to be inserted as the first (maybe only) child
                    newNode.sibling = parent.firstChild;
                    parent.firstChild = newNode;
                }
                else {
                    //insert the node after a sibling
                    newNode.sibling = lastCheckedNode.sibling;
                    lastCheckedNode.sibling = newNode;
                }
                node = this.addWordNodes(words, nextIndex + 1, newNode);
                node.to = output;
            }
            else{
                //found a match for the entire phrase so just set/update the translation (there might be a phrase with more words)
                parent.to = output;
            }
        }
        else {
            //no translation for the first word so create it
            newNode = this.createNode(words[0]);
            this.firstWords[words[0]] = newNode;
            node = this.addWordNodes(words, 1, newNode);
            node.to = output;
        } 
    }


    //add the list of phrases
    addPhrases(translations) {
        for (let i = 0; i < translations.length; i++) {
            const el = translations[i];
            this.addPhrase(el.from, el.to);
        }
    }


    //rest of the words in the phase are to be added starting at the specified parent (node for the previous word)
    addWordNodes(words, wordIndex, parent){
        var newNode = parent;   //returns parent if already at end of the words
        for (let i = wordIndex; i < words.length; i++) {
            newNode = this.createNode(words[i]);
            parent.firstChild = newNode;
            parent = newNode;
        }
        return newNode;  //the last node in the chain
    }

    //initialise a new node
    createNode(word){
        return {word: word};
    }

    //reset the tree and add the phrases
    initTranslations(translations) {
        this.firstWords = {};
        this.addPhrases(translations);
    }



    //find the best (most words) phrase starting the the specified word and return the position in the lookup
    //tree for that node.
    //Input parameters: 
    //  words: the full list of words
    //  nextIndex: index into the words array for the next word to be looked up
    //  parent: the start node from which to start looking for a match (starting from the nextIndex word)
    //Returns an object with the following:
    //  node: the node of the last word that was found in the tree.
    //  nextIndex:  index to the word after the last matched word (also indicates the number of words processed so far)
    //  lastCheckedNode: the last node checked in determining that there were no more matched words. This would be the node after which
    //      the next word would have been located if it had been in the tree (or if it is to be added to the tree)
    lookupPhrase(words, nextIndex, parent) {
        var child;
        var lastCheckedNode = parent;
        var compare;

        if (nextIndex < words.length){
            var word = words[nextIndex];
            for (child = parent.firstChild; child != null; child = child.sibling) {
                compare = word.localeCompare(child.word);
                if (compare == 0) {
                    //found a match so search for further words down this branch
                    return this.lookupPhrase(words, nextIndex + 1, child);
                }
                else if (compare < 0) {
                    //word is not in the tree so match stops with the previous node
                    return { nextIndex: nextIndex, node: parent, lastCheckedNode: lastCheckedNode };
                }
                lastCheckedNode = child;
            };
        }
        //got to the end of the children without a match
        return { nextIndex: nextIndex, node: parent, lastCheckedNode: lastCheckedNode };
    };


}

