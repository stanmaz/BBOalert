"use strict"

const MicOff = 0;
const micOn = 1;
const MicError = 2;

let m_currentSTT;       //the speechToText object using the system

    let s_recognition = new webkitSpeechRecognition();
    let s_speechRecognitionList = new webkitSpeechGrammarList();
    let s_wordList = ['points', 'pre-emptive', 'weak', 'lebensohl', 'stayman', 'herts'];

let m_inputSpeech = "";
    let m_transcript = "";

    let s_translations = {};
    let s_phrases = {}

function consolelog(text){
};

class SpeechToText{
    static s_initialised = false;
    static s_transObj = new Translation();

    constructor(inputEl, imgEl, imgOff, imgOn, imgError, callback, okBtnEl, okFn){
        this.inputEl = inputEl;
        this.imgEl = imgEl;
        this.imgOff = imgOff;
        this.imgOn = imgOn;
        this.imgError = imgError;
        this.state = MicOff;
        this.callback = callback;
        this.okBtnEl = okBtnEl;
        this.okFn = okFn;

        if (!SpeechToText.s_initialised) {
            SpeechToText.speechInit();
        }
    }

    static setConversions(translations){
        SpeechToText.s_transObj.initTranslations(translations);
    };

    active(){ return this.state == micOn};

    start() {
        //stop the current object if active
        if (m_currentSTT && m_currentSTT.state == micOn){
            m_currentSTT.stop();
        }
        else{
            m_currentSTT = this;
            chrome.runtime.sendMessage({ op: "MsgSpeechMicState", on: true, time: Date.now()});           
            s_recognition.start();

        }
    }

    stop() {
        s_recognition.stop();
        chrome.runtime.sendMessage({ op: "MsgSpeechMicState", on: false, time: Date.now()});           
        if (this.active) this.state = MicOff;  //leave as error
    }

    //update the state 
    setState(state) {
        switch (state) {
            case MicOff:
                this.imgEl.src = this.imgOff;
                this.state = MicOff;
                break;

            case micOn:
                this.imgEl.src = this.imgOn;
                this.state = micOn;
                break;

            default:
                this.imgEl.src = this.imgError;
                this.state = MicError;
                break;
        }
    }

    //stop speech to text if active otherwise start it
    toggleState(){
        if (this.active()) this.stop();
        else this.start();
    }



    static speechInit() {
        var event_list = ["onaudioend", "onaudiostart", "onend", "onerror", "onnomatch", "onresult", 
                          "onsoundend", "onsoundstart", "onspeechend", "onspeechstart", "onstart"];

        SpeechToText.s_initialised = true;

        if (!('webkitSpeechRecognition' in window)) consolelog("No webkitSpeechRecognition");
        if (!('webkitSpeechGrammarList' in window)) consolelog("No webkitSpeechGrammarList");
        if (!('SpeechRecognition' in window)) consolelog("No SpeechRecognition class");
        if (!('SpeechGrammarList' in window)) consolelog("No SpeechGrammarList class");


        if (!('webkitSpeechRecognition' in window)) {
            alert("Speech recognition not supported by your browser");
        }
        else {
            var grammar = '#JSGF V1.0; grammar s_wordList; public <s_wordList> = ' + s_wordList.join(' | ') + ' ;';

            //s_recognition.lang = "en-gb";
            s_recognition.maxAlternatives = 1;
            //s_speechRecognitionList.addFromString(grammar, 4);
            //s_recognition.grammars = s_speechRecognitionList;
            
            s_recognition.continuous = false;
            s_recognition.interimResults = false;

            s_recognition.onstart = function () {
                consolelog('STT start');
                m_inputSpeech = '';
                m_transcript = '';
                m_currentSTT.setState(micOn);
            }

            s_recognition.onresult = function (event) {
                for (var i = event.resultIndex; i < event.results.length; ++i) {
                    if (event.results[i].isFinal) {
                        m_inputSpeech = event.results[i][0].transcript;
                        m_transcript = SpeechToText.s_transObj.translate(m_inputSpeech);
                        consolelog("STT Input '" + m_inputSpeech + "', Output '" + m_transcript + "'");
                    }
                }
            };

            s_recognition.onnomatch = function (event) {
                consolelog("STT onnomatch:(" + m_inputSpeech + ")");
            }

            s_recognition.onerror = function (event) {
                m_currentSTT.setState(MicError);
                returnResult(false);
                console.log('STT onerror:' + event.error);
            };

            s_recognition.onend = function () {
                m_currentSTT.setState(MicOff);
                returnResult(true);
                consolelog("STT onend (" + m_inputSpeech + ")->(" + m_transcript + ")");
            }

            s_recognition.onspeechend = function () {
                m_currentSTT.setState(MicOff);
                consolelog('STT onspeechend');
            }
        }
    }

}

function returnResult(state){
    if (m_currentSTT) m_currentSTT.callback(m_currentSTT, m_transcript, m_inputSpeech);
    chrome.runtime.sendMessage({ op: "MsgSpeechMicState", on: false, time: Date.now()});           
}



