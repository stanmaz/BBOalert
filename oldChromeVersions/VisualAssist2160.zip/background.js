'use strict';



let counter = 0;
let m_debug = false;
let m_hand = {}; //the current hand

//variables to control timeout speech text
let m_speakActive = 0;
let m_speakPaused = 0;
let m_speakQ = [];
let m_speakTimer = 0;
let m_speakAborting = false; //aborting current speech
let m_speakStartTime = 0;   //time at which speech item started

//broadcast changes to the function parameters
function broadcastContextParams()
{
    chrome.tabs.query({url: BBO_URL}, function(tabs){
        var params = paramsPack();
        for (let i = 0; i < tabs.length; i++) {
            chrome.tabs.sendMessage(tabs[i].id, {op: MsgContextParams, params: params, selfAlerts: g_selfAlertBids});           
        }
    });
}

function consolelog(text){
    //m_debug = true;
    if (m_debug) console.log(text);
}


function expandAbbreviations(text){
    //handle single characters and bids <level><suit>
    var lookUp;
    var tmp = text.trim();
    var result = tmp;
    lookUp = expandBid(tmp);
    if (lookUp) result = lookUp;
    else{
        if (tmp.length <= AbbreviationChars + 2){  //allow for a couple of spaces
            lookUp = Abbreviations[tmp];
            if (lookUp) result = lookUp; 
        }
        else result = expandSuitSymbols(tmp);   
    }
    return result;
}

//translate text of the type <level><suit|N|NT><seat><+|-><tricks>
function expandBid(text){
    var suit, seat, idx, tmp;
    var result = "";
    var level = text.charAt(0);
    var len = text.length;
    if (level >= "1" && level <= "7"){
        suit = text.charAt(1);
        idx = (len > 2 && suit == "N" && text.charAt(2) == "T") ? 3 : 2;
        tmp = SuitText[suit];
        if (tmp) {
            result = saySuitBid(level, suit);
            if (len > idx){
                seat = saySeat(text.charAt(idx));
                if (seat){
                    result += " by " + seat;
                    //has the bid been doubled
                    idx++;
                    if (len > idx && (text.charAt(idx) == "X" || text.charAt(idx) == "x")){
                        idx++;
                        if (len > idx && (text.charAt(idx) == "X" || text.charAt(idx) == "x")){
                            result += ", re doubled";
                            idx++
                        } 
                        else result += ", doubled";
                    }
                }
                result += " " + text.substr(idx);
            };
        };
    };
    return result;
}

//replace any suit characters with the text
function expandSuitSymbols(text){
    var outputText = "";
    for (let i = 0; i < text.length; i++) {
        const chr = text[i];
        switch (chr) {
            case "♠":
                outputText += " spades ";
                break;
        
            case "♥":
                outputText += " hearts ";
                break;
        
            case "♦":
                outputText += " diamonds ";
                break;
        
            case "♣":
                outputText += " clubs ";
                break;

            default:
                outputText += chr;
                break;
        }
    }
    return outputText;
}


function handInitialised(){
    if (m_hand.suits == null || m_hand.suits == undefined){
        speak("Click on the board number to initialise the hand", SpeakGrpPopUp);
        return false;        
    }
    return true;
}


//Create a tab in the current window or in a detached window depending on the selected context menu
function post(path, str, ext) {
	//Setting the postParms parameters will create the tab using the POST rather than the GET request
	var tabData = {url: path, postParams: {"pbntext": str}};
    if (ext) tabData.postParams.ext = ext;
    consolelog(str);
	g_newTabDest.tabs.create(tabData, function(tab) {
	});
};

function publishSpeechToTextParams() {
    //send the speech to all tabs
    chrome.storage.local.get(["autoSaySpeech", "translations"], function (store) {
        var params = {
            "autoSaySpeech": (store.autoSaySpeech || true),
            "translations": (store.translations || {})
        };
        chrome.tabs.query({ url: BBO_URL }, function (tabs) {
            for (let i = 0; i < tabs.length; i++) {
                const el = tabs[i];
                chrome.tabs.sendMessage(el.id, { op: "MsgSpeechConversions", params: params });
            }
        });
    });
}


function sendSpeechToTextParams(tabId){
    //send the speech to text params to the requested tab
    chrome.storage.local.get(["autoSaySpeech", "translations"], function (store) {
        var params = { "autoSaySpeech": (store.autoSaySpeech || true), 
                "translations": (store.translations || {})};
        chrome.tabs.sendMessage(tabId, { op: "MsgSpeechConversions", params: params});                       
    });
}

function sortSelfAlerts(){
    var grp = 1;
    var idx = 0;
    var level = null;
    var bid = null;
    var bidDisplay = null;
    for (let i = 0; i < g_selfAlertOrdered.length; i++) {
        const el = g_selfAlertOrdered[i];
        if (el.level != level || el.bid != bid){
            grp = 1;
            level = el.level;
            bid = el.bid;
            bidDisplay = (SuitDisplay[bid] ? SuitDisplay[bid] : bid);
        };
        while (grp < el.group){
            g_selfAlertBids[idx] = {level: level, bid:bidDisplay, group: grp, brief: '', desc: ''};
            idx++;
            grp++;            
        };
        g_selfAlertBids[idx] = {level: level, bid: bidDisplay, group: grp, brief: el.brief, desc: el.desc};
        idx++;
    }
    //g_selfAlertBids.sort(function(a, b){return sortAlpha(a, b, "brief")});
}


//single is true if there should only ever be one of the specified priority at any one time, i.e. cancel any others
function speak(text, priority, single){
    priority = priority ? priority : SpeakLow;
    single = (single == undefined ? false : single);
    console.log(">>>>>>Speak Req:" + text + ", Pri:" + priority + ", Current Pri:" + m_speakActive + ", Timer:" + m_speakTimer + 
                ", Pause:" + m_speakPaused + ", single:" + single + ", Time:" + Date.now());

    //Queue(Q), abort(A) or ignore(X) the new request
    //Current | _____New_____
    //        | Pop Click Say Card
    // Pop    |  Q    Q    X    Q
    // Card   |  Q    A    Q
    // Click  |  Q    A    Q
    // Say    |  A    A    A

    if (priority == SpeakGrpRegcognition){
        //speech recognition needs to be immediately processed
        speakQueueRemove(priority);
        m_speakQ.unshift({text: text, priority: priority}); //add to the front of the queue
        if (m_speakActive > 0) speakTerminate();
        else speakPause(false);                     //make sure not paused and schedule new text
    }
    else{
        if (m_speakActive > 0 || m_speakPaused > 0){

            //currently speaking or paused so queue new request and decide whether to abort current
            if (priority == SpeakGrpMouseOver || priority == SpeakGrpUserAction || single){
                //only ever one MouseOver or user action active at any time
                speakQueueRemove(priority);
                if (text != "") speakQueue(text, priority);
            }
            else speakQueue(text, priority);
            //make sure not pause for too long
            if (m_speakPaused > 0){
                let now = Date.now();
                if (now - m_speakPaused > 20000) speakPause(false);
            }
        }
        else{
            if (m_speakQ.length != 0){
                //something gone wrong
                consolelog("Speak error Items queued:" + m_speakQ.length);
            }
            speakNow(text, priority);
        }   
    }
}

//terminate current and all queued speak requests
function speakAbort(all, time){
    consolelog("speakAbort SpeakActive:" + m_speakActive + ", SpeakTimer:" + m_speakTimer + ", Queue len:" + m_speakQ.length);
    if (m_speakActive > 0){
        if (all) m_speakQ.length = 0;
        if (time){
            //check there wasn't a race condition - abort requested just as the speech finished anyway and new speech started
            if (time - m_speakStartTime > 400){
                speakTerminate();
            }
        }
        else{
            speakTerminate();    
        }  
    }
}

function speakEnd(){
    //current speak has finished (ended or interrupted) so do next
    consolelog("speakEnd Queue len:" + m_speakQ.length);
    if (m_speakTimer != 0) clearTimeout(m_speakTimer);
    m_speakTimer = 0;
    m_speakActive = 0;
    m_speakAborting = false;
    m_speakStartTime = 0;
    if(m_speakQ.length > 0 && m_speakPaused == 0){
        var item = m_speakQ.shift();
        var text = item.text;
        var merge = 0;

        if(m_speakQ.length > 0){
            //merge played cards
            while (m_speakQ.length > 0 && item.priority == SpeakGrpCardPlayed){
                merge++;
                item = m_speakQ.shift();
                text += " " + item.text;
            }
        }

        speakNow(text, item.priority, merge);
    };
}

//remove any speech related to the previous board
function speakNewBoard(){
    speakQueueRemove(SpeakGrpPopUp);
    speakQueueRemove(SpeakGrpUserAction);
    speakQueueRemove(SpeakGrpCardPlayed);
}


function speakNow(text, priority, merged) {
    var timer = 0;
    m_speakAborting = false;

    var t1 = Date.now();
    m_speakTimer = setTimeout(speakTimeout, 20000);
    m_speakActive = priority;

    const SpeechRate = [1.0, 1.5, 1.75, 2.0];
    merged = (merged ? merged : 0);
    var rate = (m_speakQ.length >= SpeechRate.length ? SpeechRate.length - 1 : m_speakQ.length);
    if (merged > 0) rate = (merged >= SpeechRate.length ? SpeechRate.length - 1 : merged);
    consolelog(">>>SpeakNow:" + text + ", Pri:" + priority + ", rate:" + SpeechRate[rate] + ", merged:" + merged + 
            ", timer:" + timer + ", QueueLen:" + m_speakQ.length);
    m_speakStartTime = Date.now();
    chrome.tts.speak(text, {
            rate: SpeechRate[rate], 
            onEvent: function (event) {
                var t2 = Date.now();
                if (event.type != "sentence" && event.type != "word")
                    consolelog("Event:" + event.type + ", ms:" + (t2 - t1) + ", text:" + text);
                if (event.type == 'end' || event.type == 'interrupted') {
                    speakEnd();
                }
            }
        }, 
        function() {
            if (chrome.runtime.lastError) {
              consolelog('SpeakNow Error: ' + chrome.runtime.lastError.message + ", text:", + text);
            }
        }
    );
}

//pause or resume speech output
function speakPause(pause){
    consolelog("speakPauseReq:" + pause + ", SpeakActive:" + m_speakActive + ", SpeakTimer:" + m_speakTimer + ", Queue len:" + m_speakQ.length);
    m_speakPaused = (pause ? Date.now() : 0);
    if(pause){
        if (m_speakActive > 0) speakTerminate();
    }
    else{
        if (m_speakActive == 0) speakEnd();     //resume speech if not active
    }
}


//speech is currently active so queue the new item
function speakQueue(text, priority){
    var len = m_speakQ.length;
    if (len > 10){      //bit too many queued items!
            m_speakQ.length = 0; 
    };

    m_speakQ.push({text: text, priority: priority});
    consolelog("Queued NewLen:" + m_speakQ.length + ", PrevLen:" + len);

}

//remove all items of the specified priority from the speech queue
function speakQueueRemove(priority){
    let cnt = 0;
    let len = m_speakQ.length;
    for (let i = 0; i < len; i++) {
        const el = m_speakQ[i];
        if (m_speakQ[i].priority != priority){
            //shift item down if one or more items of specified priority skipped
            if (i != cnt) m_speakQ[cnt] = el;
            cnt++;
        }    
    }
    m_speakQ.length = cnt;
    if (len != cnt) consolelog("speakQ reduced from:" + len + " to:" + cnt);
    if (m_speakActive == priority) speakTerminate();
}

function speakTerminate() {
    //terminate the current speech
    consolelog("speakTerminate AbortState:" + m_speakAborting + ", Queue len:" + m_speakQ.length);
    if (!m_speakAborting) chrome.tts.stop();  //protect against multiple terminates
    m_speakAborting = true;
}

//current speech has had its minimum time so abort it if something else in the queue
function speakTimeout(){
    consolelog("Timeout Queue len:" + m_speakQ.length);
    m_speakTimer = 0;
    if(m_speakQ.length > 0){
        //cut short the current speech
        speakTerminate();
    };
}

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse){
    var btn;
    var speech = "";
    var priority;
    switch (request.op) {
        case MsgEcho:
            //send back the message
            chrome.tabs.sendMessage(sender.tab.id, request.msg);    
            break;                   

        case MsgRequestParams: //request for parameters from a starting context
            var params = paramsPack();
            chrome.tabs.sendMessage(sender.tab.id, {op: MsgContextParams, params: params, selfAlerts: g_selfAlertBids});                       
            sendSpeechToTextParams(sender.tab.id);
            break;

        case MsgParamUpdate: //Main parameters updated
            paramsUnpack(request.params);
            broadcastContextParams();
            break;

        case MsgNewBoard: //new board displayed
            speakNewBoard();    //terminate speech from a previous board
            if (g_describeBoard) speech = "Board " + request.board + ", ";
            priority = SpeakNewBoard;
            //no break so contine below
        case MsgBoardNumberClicked: //the board number was clicked (not a new board)
            m_hand = request.hand;
            //send the convention card used with the current partner.
            chrome.tabs.sendMessage(sender.tab.id, {op: MsgSelfAlertCard, card: {title: "Benji ACOL Plus", bids: g_selfAlertBids}});
            if (g_shape) speech += sayHandShape(m_hand) + ", ";
        case MsgTableClicked:
            if (priority != SpeakNewBoard) priority = SpeakHandDetails;
            if (g_hcp) speech += m_hand.hcp + (m_hand.hcp == 1 ? " point " : " points ");
            if (g_ltc) speech += m_hand.ltc;
            if (speech != "") speak(speech, priority);
            break; 
            
        case MsgSayText:
            let text = expandAbbreviations(request.text);
            speak(text, request.priority, request.single);
            break;

        case MsgKeepAlive: //msg to keep this background task alive
            break;

        case "MsgPost":
            post(request.url, request.params, request.ext);
            break;

        case "MsgSpeechMicState": 
            consolelog("MsgPauseSpeech:" + request.pause + ", time:" + request.time);
            speakPause(request.on);
            break;           

        case MsgPauseSpeech: 
            consolelog("MsgPauseSpeech:" + request.pause + ", time:" + request.time);
            //speakPause(request.pause);
            break;

        case MsgAbortSpeech: //user clicked the mouse so abort text
            consolelog("MsgAbortSpeech - all:" + request.all + ", time:" + request.time);
            speakAbort(request.all, request.time);
            break;


    };
});

var now = new Date;
consolelog("Startup:" + now.toLocaleString());
//initial the module to create a separate window
g_newTabDest.initialise("BVA", false);

getParams(function(){
    //sort the self alerts as required
    sortSelfAlerts();
    broadcastContextParams();
});

publishSpeechToTextParams();
