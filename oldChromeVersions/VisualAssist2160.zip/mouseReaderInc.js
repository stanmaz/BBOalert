"use strict"

//include htmlInc.html in the html file

let m_sayMouseOver = false;

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    switch (request.op) {
        case MsgContextParams: //Main parameters updated
        case MsgParamUpdate:
            var store = request.params;
            m_sayMouseOver = store.sayMouseOver;
            g_mouseReader.enable(store.sayMouseOver);
            break;
    };
});

chrome.runtime.sendMessage({ op: MsgRequestParams });

setInterval(function () { chrome.runtime.sendMessage({ op: MsgKeepAlive }); }, 3000);

g_mouseReader.init(m_sayMouseOver);
