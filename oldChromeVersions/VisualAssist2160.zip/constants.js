'use strict';

//Constants that are common to more than one module

//messages
const MsgSpare00 = 0;          //a bid has just been submitted
const MsgSpare01 = 1;        
const MsgParamUpdate = 2;           //one or more parameters updated by the user
const MsgSubmitBid = 3;             //Request from background for the bid to be submitted
const MsgBoardNumberClicked = 4;
const MsgNewBoard = 5;
const MsgSayText = 6;               //mouse over text event
const MsgSelfAlertCard = 7;         //data for the self alert
const MsgKeepAlive = 8;             //keep the background alive while the content is active
const MsgTableClicked = 9;          //table cloth clicked
const MsgPauseSpeech = 10;          //pause or resume speech output
const MsgRequestParams = 11;        //request for parameters from a context
const MsgContextParams = 12;        //params to be used by the context
const MsgAbortSpeech = 13;          //abort the current speech and maybe all queued speech
const MsgEcho = 14;
const MsgSpare15 = 15;      
const MsgSpare16 = 16;         //bid button clicked on or off
const MsgSpare17 = 17;           
const MsgEchoTest = 18;             //echo to ensure a bid explanation is read out

//grouping of speech text
const SpeakGrpPopUp = 100;             //text was a pop-up or unsolcitited - not user initiated
const SpeakGrpChatMessage = 90;             //a chat message
const SpeakGrpBidInfo = 80;             //a chat message
const SpeakGrpCardPlayed = 60;              //speech due to a user clicking something 
const SpeakGrpUserAction = 30;              //speech due to a user clicking something 
const SpeakGrpRegcognition = 10;                //text can be repeated if user takes an action
const SpeakGrpMouseOver = 1;                //text can be repeated if user takes an action

const SpeakClaimUndoRequest = SpeakGrpPopUp;   //a player has made a claim or an undo requesst
const SpeakOtherBid = SpeakGrpBidInfo;           //a bid made by another player. Will be followed by its BidExplanation if self alerted
const SpeakBidExplanation = SpeakGrpBidInfo;     //popup giving the self-alerted explanation
const SpeakContract = SpeakGrpPopUp;           //the contract to be played
const SpeakExplainBid = SpeakGrpPopUp;         //another player has requested you explain one of your bids
const SpeakRejectedAccepted = SpeakGrpPopUp;   //indicates if a claim or undo has been rejected or accepted
const SpeakChat = SpeakGrpChatMessage;         //a new chat message
const SpeakBidExplainedOK = SpeakGrpUserAction;     //says "OK" when you have responded to a request to explain one of your bids
const SpeakTopLevelPopup = SpeakGrpPopUp;      //a high level pop-up such as a game invitation
const SpeakCardPlayed = SpeakGrpCardPlayed;         //describes the card played in a trick
const SpeakRecognitionReadback = SpeakGrpRegcognition;  //read back of your detected speech
const SpeakChatEnterPressed = SpeakGrpRegcognition;   //the [enter] key just preseed to submit your recognised speech input
const SpeakWarnDonaldSuitLength = SpeakGrpPopUp; //special message indicating the bid being made isn't in the longest suit
const SpeakSuitNTBidClick = SpeakGrpUserAction;     //a suit or NT bid button has been clicked
const SpeakNonSuitNTBidClick = SpeakGrpUserAction;  //a bid level, Dbl, Pass or Rdbl was clicked
const SpeakInfo = SpeakGrpPopUp;              //an error was detected by the code or something to report
const SpeakBidOK = SpeakGrpUserAction;              //a bid is being submitted - says OK
const SpeakMouseOver = SpeakGrpMouseOver;                   //mouse has been moved over a new node so read it or not (if empty)
const SpeakSelfAlert = SpeakGrpUserAction;          //one of the self-alert descriptions has been selected - speak it
const SpeakNewBoard = SpeakGrpPopUp;           //a new board has been started
const SpeakHandDetails = SpeakGrpUserAction;        //describes the hand (points and LTC)
const SpeakLow = SpeakGrpMouseOver;

//button types
const BtnOK = 0;
const BtnAlert = 1;
const BtnLevel = 2;
const BtnSuit = 3;
const BtnSubmit = 4;

const Seats = {"N": "north",  "S": "south",  "E": "east",  "W": "west"};

const SuitText = {
    "♠": "Spade", "♥": "Heart", "♦": "Diamond", "♣": "Club", 
    S: "Spade", H: "Heart", D: "Diamond", C: "Club", NT: "No trump", N: "No trump",
};

const SuitIndex = {S: 0, H: 1, D: 2, C: 3, NT:-1};
const NonSuitText = {"Pass": "Pass", "Dbl": "Double", "Rdbl": "Re-double", };
const bidText = ["♠", "♥", "♦", "♣", "NT", "Dbl", "Rdbl", "Pass"];

const OKBtnText = "OK";
const NTBtnText = "NT";
const biddingBtns = [
    {text: OKBtnText, type: BtnOK, speak: "OK"},
    {text: "Pass", type: BtnSubmit, speak: "Pass", abbrev: "Pass"},
    {text: "Dbl", type: BtnSubmit, speak: "Double", abbrev: "Dbl"},
    {text: "Rdbl", type: BtnSubmit, speak: "Re-double", abbrev: "Rdbl"},
    {text: "Alert", type: BtnAlert, speak: "Alert"},
    {text: "1", type: BtnLevel, speak: "1"},
    {text: "2", type: BtnLevel, speak: "2"},
    {text: "3", type: BtnLevel, speak: "3"},
    {text: "4", type: BtnLevel, speak: "4"},
    {text: "5", type: BtnLevel, speak: "5"},
    {text: "6", type: BtnLevel, speak: "6"},
    {text: "7", type: BtnLevel, speak: "7"},
    {text: "♣", type: BtnSuit, speak: "Club", abbrev: "C"},
    {text: "♦", type: BtnSuit, speak: "Diamond", abbrev: "D"},
    {text: "♥", type: BtnSuit, speak: "Heart", abbrev: "H"},
    {text: "♠", type: BtnSuit, speak: "Spade", abbrev: "S"},
    {text: NTBtnText, type: BtnSuit, speak: "No trump", suit: "NT", abbrev: "NT"}];


    const SuitDisplay = {
        "C": "♣"
       ,"D": "♦"
       ,"H": "♥"
       ,"S": "♠"
       ,"NT": "NT"
  };
  
const Suits = ["♠","♥","♦","♣"];
const Cards = ["A","K","Q","J","10","9","8","7","6","5","4","3","2"];

const CardText = {
    "A": "ace"
   ,"K": "king"
   ,"Q": "queen"
   ,"J": "jack"
   ,"10": "ten"
   ,"9": "nine"
   ,"8": "eight"
   ,"7": "seven"
   ,"6": "six"
   ,"5": "five"
   ,"4": "four"
   ,"3": "three"
   ,"2": "two"
   ,"T": "ten"
};


//cards are order by suit (SHDC) and then ace, king down to 2.
function getCardindex(num, suit){
    const SuitSeq = {"♠": "0", "♥": "1", "♦": "2", "♣": "3"};
    const CardSeq = {"A": 0, "K": 1, "Q": 2, "J": 3, "10": 4, "9": 5, "8": 6, "7": 7, "6": 8, "5": 9, "4": 10, "3": 11, "2": 12};
    return SuitSeq[suit] * 13 + CardSeq[num];
}

//card is either suit followed by card or the opposite
function parseCard(text){
    var len = text.length;
    var suit, card;
    if (SuitText[text.charAt(0)]){
        suit = text.charAt(0);
        card = text.substr(1);
    }
    else{
        suit = text.charAt(len - 1);
        card = text.substr(0, len - 1);
    }
    return {card: card, suit: suit};
}

//search a string to see if it contains a bid and, if so, returns the bid
function findBid(text){
    var pos;
    var result;
    var len;
    for (let i = 0; i < bidText.length; i++) {
        const el = bidText[i];
        pos = text.indexOf(el);
        if (pos > 0){
            len = el.length;
            if (len <= 2)
                result = {level: text.substr(pos - 1, 1), suit: text.substr(pos, len)};
            else
                result = {level: "", suit: text.substr(pos, len)};
            return result;
        }
    }
    return null;
}

//split a bid into it's level and suit
function parseBidText(bidText){
    var text = bidText.trim();
    var level = 0;
    var suit;
    if (text.charAt(0) >= "1" && text.charAt(0) <= "7" ){
        level = text.charAt(0);
        suit = text.substr(1);
    }
    else{
        level = 0;
        suit = text;
    }
    return {level: level, suit: suit};
}


//bid text may be a suit/NT bid, Pass, DBK or RDBL
function sayBid(text){
    var bidObj = parseBidText(text);
    if (bidObj.level > 0) return saySuitBid(bidObj.level, bidObj.suit);
    else return NonSuitText[bidObj.suit];
}

//text for a playing card
function sayCard(num, suit){
    var suitText = SuitText[suit] + "s";
    var card = CardText[num];
    if (card) return card + " of " + suitText;
    else return num + " of " + suitText;
}

function sayCardCnt(hand, suit) {
    if (hand.suits == undefined) return "";
    if (suit == "NT") return sayHandShape(m_hand);

    var cnt = m_hand.suits[SuitIndex[suit]].length;
    return "You have " + saySuitBid(cnt, suit);
}

function sayHandShape(hand) {
    return (hand.balanced ? "Balanced " : "Shape ") + hand.shape;
}


//text for a playing seat
function saySeat(seat){
    return Seats[seat];
}


//return the text for a suit bid
function saySuitBid(cnt, suit){
    var suitText = SuitText[suit];
    if (cnt == "" || cnt < 0 || suitText == undefined) return suit;
    else if (cnt == 0) return "No " + suitText + "s";
    else if (cnt == 1) return "1 " + suitText;
    else return cnt + " " + suitText + "s";
}

//search a string to see if it contains a bid and, if so, replace the bid with full text
function translateBid(text){
    var pos;
    var result;
    var len;
    for (let i = 0; i < bidText.length; i++) {
        const el = bidText[i];
        pos = text.indexOf(el);
        if (pos > 0){
            len = el.length;
            if (len <= 2)
                result = text.substr(0, pos - 1) + sayBid(text.substr(pos - 1, len + 1)) + text.substr(pos + len);
            else
                result = text.substr(0, pos) + sayBid(text.substr(pos, len)) + text.substr(pos + len);
            return result;
        }
    }
    return text;
}