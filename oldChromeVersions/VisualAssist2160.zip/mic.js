'use strict';

const BBO_URL = "https://www.bridgebase.com/v3/*";

let m_translations = [
  {from: "bed", to:"bid"},
  {from: "big", to:"bid"},
  {from: "bye", to:"Bye, thanks for the games"},
  {from: "for clubs", to:"4 clubs"},
  {from: "for diamonds", to:"4 diamonds"},
  {from: "for hearts", to:"4 hearts"},
  {from: "for spades", to:"4 spades"},
  {from: "fsf", to:"Fourth Suit Forcing"},
  {from: "herts", to:"hearts"},
  {from: "intro bob", to:"Hi, it's Bob and John. We play standard ACOL, weak NT (12-14), 3 weak 2s HELD"},
  {from: "intro donald", to:"Hi, it's Donald and John. We play Benji ACOL, weak NT (12-14), McKenny discards."},
  {from: "lb", to:"Lebensohl, partner to bid 3C"},
  {from: "lemon sole", to:"Lebensohl"},
  {from: "next week", to:"next week"},
  {from: "owners", to:"honours"},
  {from: "readable", to:"re-double"},
  {from: "stamen", to:"stayman"},
  {from: "this week", to:"this week"},
  {from: "week", to:"weak"}
];

let m_transTree;

//////////////////////////////////////////////////////////////////////////////////////////////////////

const ConvertRowId = "convertRow";

let m_speech;
let m_sayMouseOver = true;
let m_autoSaySpeech = true;   //read the converted text auto

let m_micEl;  //element containing the microphone image
let m_inputEl;    //input node
let m_outputEl;   //output node after translation


//add the conversion to the sorted list
function conversionAdd(from, to){
  var report = "";
  from = from.trim().toLowerCase();
  if (from == "") report = "'From' text must not be blank";
  
  if (report == ""){
    //need to check if conversion already exists and add the new one if it doesn't by shifting everything up
    //add extra slot on the assumption it's a new conversion
    var result = 0;
    var index = m_translations.length;   //add item to the end of the list if not found (first item is array empty)
    for (let i = 0; i < m_translations.length; i++) {
      const el = m_translations[i];
      result = from.localeCompare(el.from);
      if (result <= 0) {
        index = i;
        break;
      }
    }

    var words = from.split(" ");
    if (result == 0) {
      //either the list was empty or the new item is a duplicate so just replace
      report = (m_translations.length == 0 ? "Inital conversion added" : "Conversion updated");
      m_translations[index] = {from: from, to: to};
    }
    else{
      //need to insert a new row so shift everything up
      report = "New conversion added";
      for (let i = m_translations.length - 1; i >= index; i--) {
        m_translations[i + 1] = m_translations[i];
      }
      m_translations[index] = { from: from, to: to };
    };

    storageSave();
    displayConversions();
  };

  reportResult(report);
}

//deleted the specified row from the conversion array
function conversionDelete(index) {
  m_translations.splice(index, 1);
  storageSave();
  displayConversions();
  reportResult("Conversion deleted");
}


function displayConversions() {
  var el = document.querySelector("translations");
  var trans = displayTable("Word/Phrase Conversions", false, "word");

  el.innerHTML = trans;
}

function displayTable(title){
  var table = "";
  var style = '<style>table, th, td {padding-left: 10px; padding-right: 10px; border: 1px solid black; ' +
    'border-collapse: collapse; rowspan: 1; font-size: 14px;}' +
    'tr:hover td{background-color: #ffff99;}​</style>';
  
  var header = '<h2 style="text-align:center;">' + title + '</h2>';

  var rows = displayConversionRows();

  table = '<table style="width:100%;">' +
    '<tr>' + '<th>From</th>' + '<th>To</th>' + '<th width="20"></th>' + '</tr>' +
    rows + '</table><br>';

  return '<div style="overflow-y: auto; overflow-x: hidden">' +
          style + header + '<div style="overflow-y: auto;">' + table + '</div>' + '</div>';

}


function displayConversionRows() {
  //get the rows for the specified level and suit. 
  var html = "";
  for (let i = 0; i < m_translations.length; i++) {
      html += "<tr>" +
        "<td id='" + ConvertRowId + "F" + i + "'>" + m_translations[i].from + "</td>" +
        "<td id='" + ConvertRowId + "T" + i + "'>" + m_translations[i].to + "</td>" +
        "<td>" + '<img id="' + ConvertRowId + "D" + i + 
          '"del_img" src="images\\delete.png" alt="Delete" title="Delete" style="vertical-align:middle;" ></img>' +
        "</td>" +
        "</tr>";
  }
  return html;
}


function reportResult(text){
  document.getElementById("report").innerText = text;
}

function publishSpeechToTextParams() {
  //send the speech to all tabs
  chrome.tabs.query({ url: BBO_URL }, function (tabs) {
    var params = {"translations": m_translations};
    for (let i = 0; i < tabs.length; i++) {
      const el = tabs[i];
      chrome.tabs.sendMessage(el.id, { op: "MsgSpeechConversions", params: params });
    }
  });
}


function speechResult(micObj, output, input){
    m_inputEl.value = input;
    m_outputEl.value = output;
    if(m_autoSaySpeech){
      speakText(output, SpeakRecognitionReadback);
    }
}

//read out a bid explanation. Node is a callExplanationClass
function speakText(text, priority) {
  priority = priority || SpeakGrpUserAction;
  chrome.runtime.sendMessage({ op: MsgSayText, text: text, priority: priority });
}


function storageRead(callback) {
  chrome.storage.local.get(["sayMouseOver", "autoSaySpeech", "translations"], function (store) {
    m_sayMouseOver = (store.sayMouseOver == undefined ? m_sayMouseOver : store.sayMouseOver);
    m_autoSaySpeech = (store.autoSaySpeech == undefined ? m_autoSaySpeech : store.autoSaySpeech);
    if (store.translations) m_translations = store.translations;
    else storageSave();
    SpeechToText.setConversions(m_translations);
    if (callback) callback(store);
  });
}

function storageSave(callback) {
  SpeechToText.setConversions(m_translations);
  chrome.storage.local.set({"translations": m_translations}, function () {
    publishSpeechToTextParams();
    if (callback) callback();
  });
}


/////////////////////////////////////events
function onBeforeUnload(ev) {
  var dims = { top: window.screenTop, left: window.screenLeft, width: window.outerWidth, height: window.outerHeight };
  chrome.storage.local.set({ "micDocDims": dims });
  speakText("", SpeakRecognitionReadback);
}

function onKeyDown(ev) {
  if (ev.code == "Enter") {
    //route the enter to the last input field used by the speech to text
        conversionAdd(m_inputEl.value, m_outputEl.value);
  }
  else {
    if (ev.code == "Escape") {
      m_inputEl.value = "";
      m_outputEl.value = "";
    };
    reportResult("");
  };
}


function onMessageHandler(request, sender, sendResponse) {
  switch (request.op) {
    case MsgParamUpdate: //Main parameters updated
        var store = request.params;
        m_sayMouseOver = store.sayMouseOver;
        m_autoSaySpeech = store.autoSaySpeech;
        g_mouseReader.enable(store.sayMouseOver);
        break;
  };
};

function onMouseClick(ev) {
  //see if a delete row button was clicked
  var clickEl = ev.path[0];   //save last button clicked
  speakText("", SpeakRecognitionReadback);

  if (clickEl.id.includes(ConvertRowId)) {
    //conversion row button was clicked so get the row number
    let index = parseInt(clickEl.id.substr(ConvertRowId.length + 1));
    if (!m_speech.active()) {
      m_inputEl.value = m_translations[index].from;
      m_outputEl.value = m_translations[index].to;
    }
    if (clickEl.tagName == "IMG") {
      conversionDelete(index);
    };
  }
};


function initialise(){
  m_inputEl = document.getElementById("input");
  m_outputEl = document.getElementById("output");
  m_micEl = document.getElementById("mic");
  storageRead(function () {
    g_mouseReader.init(m_sayMouseOver);
    displayConversions();
    m_speech = new SpeechToText(m_inputEl, m_micEl, 'images/micOff.png', 'images/micPulse.gif', 'images/micError.png', speechResult);
  })
  window.addEventListener('beforeunload', onBeforeUnload);
  SpeechToText.speechInit();

}


////////////////////////////////////init

chrome.runtime.onMessage.addListener(onMessageHandler);
document.addEventListener("click", onMouseClick, true);
document.addEventListener("keydown", onKeyDown, true);  //keydown rather than keypress to detect ESC key

//can only access the html after it has been loaded
window.onload = function () { // same as window.addEventListener('load', (event) => {
    initialise();

  $('#add').click(function () {
    conversionAdd(m_inputEl.value, m_outputEl.value);
  });

  $('#help').click(function () {
    var url = chrome.runtime.getURL("SpeechRecognition.htm");
    chrome.tabs.query({ url: url }, function (tabs) {
        if (tabs.length == 0) {
            chrome.windows.create({ url: url, type: "popup" });
        }
        else {
            chrome.windows.update(tabs[0].windowId, { focused: true });
        }
    });
});


  function testTrans(text) {
    var now, mid, end;
    const loops = 1000;
    now = Date.now();
    for (let i = 0; i < loops; i++) {
      translate(text);
    }
    mid = Date.now();
    for (let i = 0; i < loops; i++) {
      m_transTree.translate(text);
    }
    end = Date.now();

    return "Simple (" + loops + "):" + (mid - now) + ", Full:" + (end - mid);

  }

  $('#default').click(function () {
    //display the page to set the microphone
    var url = "chrome://settings/content/microphone";
    chrome.windows.create({ url: url, type: "popup"});
  });

  $('#mic').click(function () {
    if (m_speech.active()){
      m_speech.stop();
    }
    else {
      m_speech.start();
      m_inputEl.value = "";
      m_outputEl.value = "";
    }
    reportResult(" ");
  });

};



